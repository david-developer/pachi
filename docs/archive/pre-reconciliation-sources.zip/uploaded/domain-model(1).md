# Pachi — Core Domain Model

> **Status:** Approved  
> **Last Updated:** 2026-09-24  
> **Owner:** Project  
> **Authority:** Canonical overview of Pachi's domain entities, relationships, ownership boundaries, and major lifecycle concepts. Specialized domain documents remain authoritative for detailed rules.

---

## 1. Purpose

This document defines the core Pachi domain model.

It establishes:

- primary entities;
- entity relationships;
- stable identity concepts;
- ownership boundaries;
- trust and verification concepts;
- lifecycle relationships;
- audit boundaries.

It intentionally avoids database-specific implementation detail unless the detail is required to preserve a domain invariant.

---

## 2. Domain Principles

### 2.1 One user, multiple marketplace capacities

A Pachi user is not assigned one mutually exclusive marketplace role.

The same account may:

- seek housing;
- act as an individual provider;
- belong to organizations.

Authorization is derived from account state, provider state, organization membership, resource scope, verification, lifecycle state, and moderation restrictions.

### 2.2 Identity is separate from authorization

External authentication identity maps to a Pachi `User`.

External identity does not own Pachi roles or permissions.

### 2.3 Verification is subject-specific

There is no canonical global `is_verified`.

Verification belongs to a subject/type and has its own case/result lifecycle.

### 2.4 Property is not listing

A `Property` represents the real-world asset.

A `Listing` represents a marketplace offer for that property during a period of time.

### 2.5 Interaction is the basis of marketplace reputation

A qualifying completed `Interaction` creates directional `ReviewEligibility`.

Reviews do not arise from arbitrary contact.

### 2.6 Trust-impacting history is durable

Verification, moderation, interaction, review, and privileged administrative history should not be silently overwritten.

---

# 3. Core Entity Map

```text
User
├── AuthIdentity
├── IndividualProviderProfile
├── OrganizationMembership ──────► Organization
├── InteractionParticipant
├── Review
├── VerificationSubject/Case
├── Notification
└── AuditActor

Organization
├── OrganizationMembership
├── VerificationCase
├── PropertyAuthority
├── ListingProvider
└── ReviewTarget

Property
├── PropertyLocation
├── PropertyAuthority
├── PropertyMedia
└── Listing

Listing
├── ListingMedia
├── Interaction
├── ModerationCase
└── Report

Interaction
├── participants
├── completion/dispute state
├── ReviewEligibility
├── Review
└── ModerationCase
```

---

# 4. User

Represents a Pachi account at the application/domain level.

Conceptual fields:

```text
User
- id
- account_state
- preferred_locale
- created_at
- updated_at
- closed_at
```

`id` is an immutable application-owned identifier.

Do not use email or phone number as the canonical user identity.

---

## 4.1 Account State

Possible application-level states may include:

```text
ACTIVE
RESTRICTED
SUSPENDED
CLOSED
```

Fine-grained capability restrictions should normally be represented separately rather than overloading this state.

---

# 5. AuthIdentity

Maps an external authentication identity to a Pachi user.

Conceptual fields:

```text
AuthIdentity
- id
- user_id
- issuer
- subject
- provider
- linked_at
- unlinked_at
```

Identity uniqueness:

```text
issuer + subject
```

The current architecture baseline uses Cognito as the identity issuer, with local and federated sign-in identities.

Email equality must not be used as the sole identity-linking key.

---

# 6. Contact Methods

Conceptually, Pachi may maintain user contact data such as:

```text
EmailContact
PhoneContact
```

Contact records may track:

- value;
- normalized value;
- verification state;
- primary status;
- deliverability state.

Authentication-provider contact attributes and Pachi domain verification must not be conflated.

---

# 7. IndividualProviderProfile

Represents an individual user's provider capacity.

Conceptual fields:

```text
IndividualProviderProfile
- id
- user_id
- provider_state
- public_profile_fields
- created_at
```

A provider profile does not itself prove that the person is verified or authorized to represent a property.

Verification is separate.

---

# 8. Organization

Represents an organization acting as a property provider.

Conceptual fields:

```text
Organization
- id
- name
- organization_state
- public_profile_fields
- created_at
```

Organization verification is separate from organization existence.

---

# 9. OrganizationMembership

Connects a user to an organization.

Conceptual fields:

```text
OrganizationMembership
- id
- organization_id
- user_id
- role
- state
- invited_at
- activated_at
- removed_at
```

Roles:

```text
OWNER
ADMIN
AGENT
```

Lifecycle:

```text
INVITED
ACTIVE
SUSPENDED
REMOVED
DECLINED
EXPIRED
```

Membership permission is scoped to the organization.

---

# 10. Organization Ownership

An active organization should have one active owner unless an explicit transfer process is active.

Ownership transfer must be an explicit domain operation with audit history.

The owner is not removed through an ordinary membership-removal action.

---

# 11. Property

Represents the real-world housing asset.

Conceptual fields:

```text
Property
- id
- property_type
- physical_attributes
- created_by
- created_at
- updated_at
```

A property may exist without an active public listing.

A property may have multiple historical listings.

---

# 12. PropertyLocation

Represents Pachi's canonical property geography.

Conceptual fields:

```text
PropertyLocation
- property_id
- country_code
- region_id
- city_id
- neighborhood_id
- latitude
- longitude
- location_precision
- public_location_mode
- display_address
- landmark
- directions
- external_provider
- external_place_id
- confirmed_by_user
- confirmed_at
```

Coordinates and canonical Pachi locality relationships are authoritative for Pachi search.

External provider data is assistance/provenance, not marketplace identity.

---

# 13. Region

Canonical geographic region.

Conceptual fields:

```text
Region
- id
- country_code
- canonical_name
- status
```

Display translations/aliases may be stored separately.

---

# 14. City

Canonical city/locality.

Conceptual fields:

```text
City
- id
- region_id
- canonical_name
- centroid
- status
```

---

# 15. Neighborhood

Canonical marketplace neighborhood.

Conceptual fields:

```text
Neighborhood
- id
- city_id
- canonical_name
- centroid
- boundary_geometry
- status
```

External geocoder results must not automatically create a canonical neighborhood.

---

# 16. NeighborhoodAlias

Maps alternative/localized names to a canonical neighborhood.

Conceptual fields:

```text
NeighborhoodAlias
- id
- neighborhood_id
- alias
- normalized_alias
- language
```

---

# 17. PropertyAuthority

Represents a provider/organization's authority to represent a property.

Conceptually:

```text
PropertyAuthority
- id
- property_id
- subject_type
- subject_id
- verification_result_id
- authority_state
- valid_from
- valid_until
```

An `A2` result is required for publication under the current product baseline.

Authority is distinct from property creation and property ownership claims in the UI.

---

# 18. Listing

Represents a marketplace offer for a property.

Conceptual fields:

```text
Listing
- id
- property_id
- provider_subject_type
- provider_subject_id
- state
- offering_fields
- published_at
- paused_at
- closed_at
- archived_at
- created_at
```

Provider subject may be:

- individual provider;
- organization.

---

# 19. Listing Lifecycle

States:

```text
DRAFT
PENDING_REVIEW
PUBLISHED
PAUSED
UNDER_MODERATION
CLOSED
ARCHIVED
```

Transitions are domain operations.

The database/API should not expose unrestricted state patching.

---

# 20. ListingProvider Context

A listing must identify who is responsible for the offer.

For an organization listing, the organization is the provider/reputation target while an individual membership may represent the acting agent.

This distinction is necessary for:

- authorization;
- audit;
- review targeting;
- support.

---

# 21. MediaAsset

Represents application metadata for stored media.

Conceptual fields:

```text
MediaAsset
- id
- classification
- owner_type
- owner_id
- storage_ref
- processing_state
- moderation_state
- visibility
- checksum
- created_at
- deleted_at
```

Large binary content belongs in object storage, not PostgreSQL.

---

# 22. ListingMedia

Associates listing/property media with ordering.

Conceptual fields:

```text
ListingMedia
- listing_id
- media_asset_id
- sort_order
- is_cover
```

Ordering is domain/database state rather than S3 object naming.

---

# 23. VerificationSubject

Verification applies to a subject.

Subject examples:

```text
USER
INDIVIDUAL_PROVIDER
ORGANIZATION
ORGANIZATION_REPRESENTATIVE
PROPERTY_AUTHORITY
```

A normalized model may represent subject type and ID explicitly.

---

# 24. VerificationCase

Represents one verification attempt/review process.

Conceptual fields:

```text
VerificationCase
- id
- verification_type
- subject_type
- subject_id
- state
- submitted_at
- decided_at
- expires_at
- created_at
```

Lifecycle:

```text
DRAFT
SUBMITTED
UNDER_REVIEW
ACTION_REQUIRED
VERIFIED
REJECTED
EXPIRED
REVOKED
CANCELLED
```

---

# 25. VerificationEvidence

Private evidence attached to a verification case.

Conceptual fields:

```text
VerificationEvidence
- id
- verification_case_id
- evidence_type
- private_media_asset_id
- submitted_by
- submitted_at
- retention_state
```

Evidence access is not a normal public-media operation.

---

# 26. VerificationResult

Represents the trust result of a completed verification process.

Conceptual fields:

```text
VerificationResult
- id
- verification_case_id
- subject_type
- subject_id
- level_or_result
- verified_at
- expires_at
- revoked_at
- decision_metadata
```

Reverification produces new history rather than mutating prior history into a new fact.

---

# 27. Interaction

Represents a structured marketplace interaction.

Conceptual fields:

```text
Interaction
- id
- listing_id
- type
- state
- seeker_user_id
- provider_subject_type
- provider_subject_id
- acting_provider_user_id
- scheduled_for
- completed_at
- created_at
```

Initial interaction types:

```text
INQUIRY
CONTACT_REQUEST
VIEWING
```

Viewing is the initial review-qualifying interaction type.

---

# 28. Interaction Lifecycle

Baseline viewing states:

```text
REQUESTED
ACCEPTED
SCHEDULED
COMPLETED
DECLINED
CANCELLED
NO_SHOW
EXPIRED
```

A state transition should record who performed it and relevant timestamp/reason metadata.

---

# 29. InteractionEvent

Recommended durable event/history concept for significant interaction changes.

Conceptual fields:

```text
InteractionEvent
- id
- interaction_id
- event_type
- actor_id
- occurred_at
- metadata
```

This may record:

- requested;
- accepted;
- rescheduled;
- cancelled;
- completion proposed/confirmed;
- no-show report;
- dispute.

Exact implementation may use explicit columns plus audit events instead of a dedicated table if equivalent durability is preserved.

---

# 30. NoShowRecord

Where modeled separately, a no-show record may contain:

```text
NoShowRecord
- interaction_id
- reported_by
- responsibility
- evidence_status
- moderation_case_id
- created_at
```

Responsibility:

```text
SEEKER_NO_SHOW
PROVIDER_NO_SHOW
BOTH_UNCONFIRMED
DISPUTED
```

No-show is not an ordinary star review.

---

# 31. ReviewEligibility

Represents directional permission to submit a review.

Conceptual fields:

```text
ReviewEligibility
- id
- interaction_id
- reviewer_user_id
- target_type
- target_id
- direction
- state
- created_at
- revoked_at
```

Directions include:

```text
SEEKER_TO_PROVIDER
PROVIDER_TO_SEEKER
```

For organization interactions, provider target is the organization in the initial model.

---

# 32. Review

Conceptual fields:

```text
Review
- id
- review_eligibility_id
- interaction_id
- reviewer_user_id
- target_type
- target_id
- rating
- text
- state
- submitted_at
- published_at
- withdrawn_at
```

Rating baseline:

```text
integer 1–5
```

---

# 33. Review Lifecycle

```text
DRAFT
SUBMITTED
PUBLISHED
UNDER_MODERATION
HIDDEN
REMOVED
WITHDRAWN
```

Only eligible published reviews contribute to reputation aggregates.

---

# 34. Reputation Aggregate

Public reputation should be derived from eligible review state rather than treated as independently editable truth.

Possible conceptual projection:

```text
ReputationAggregate
- target_type
- target_id
- rating_average
- rating_count
- updated_at
```

This may be materialized for performance but remains derivable.

---

# 35. Report

Represents a user report.

Conceptual fields:

```text
Report
- id
- reporter_user_id
- target_type
- target_id
- category
- description
- created_at
- moderation_case_id
```

---

# 36. ModerationCase

Conceptual fields:

```text
ModerationCase
- id
- category
- state
- target_type
- target_id
- assigned_staff_id
- opened_at
- resolved_at
```

Lifecycle:

```text
OPEN
TRIAGED
UNDER_REVIEW
ACTION_REQUIRED
RESOLVED
CLOSED
```

---

# 37. ModerationAction

Represents an action taken as part of moderation.

Conceptual fields:

```text
ModerationAction
- id
- moderation_case_id
- action_type
- actor_staff_id
- target_type
- target_id
- created_at
- effective_until
- metadata
```

Actions include:

```text
NO_ACTION
WARNING
CONTENT_HIDDEN
CONTENT_REMOVED
LISTING_PAUSED
LISTING_UNDER_MODERATION
INTERACTION_INVALIDATED
REVIEW_ELIGIBILITY_REVOKED
REVIEW_HIDDEN
REVIEW_REMOVED
VERIFICATION_REVIEW_REQUIRED
VERIFICATION_REVOKED
ACCOUNT_CAPABILITY_RESTRICTED
ACCOUNT_SUSPENDED
ORGANIZATION_RESTRICTED
ESCALATED
```

---

# 38. CapabilityRestriction

Represents fine-grained restrictions.

Conceptual fields:

```text
CapabilityRestriction
- id
- subject_type
- subject_id
- capability
- reason
- starts_at
- ends_at
- moderation_case_id
```

Examples:

```text
CANNOT_PUBLISH_LISTING
CANNOT_REQUEST_VIEWING
CANNOT_REVIEW
CANNOT_ADMINISTER_ORGANIZATION
```

This is preferred to a single generic ban flag where the product needs narrower enforcement.

---

# 39. Dispute

A dispute may belong to an interaction or another trust-sensitive operation.

Interaction dispute lifecycle:

```text
OPEN
UNDER_REVIEW
RESOLVED_UPHELD
RESOLVED_OVERTURNED
RESOLVED_PARTIAL
CLOSED
```

Disputed completion may suspend related review eligibility until resolution.

---

# 40. Notification

Represents durable user-facing notification state.

Conceptual fields:

```text
Notification
- id
- recipient_user_id
- category
- event_type
- entity_type
- entity_id
- priority
- locale
- created_at
- read_at
- archived_at
```

---

# 41. NotificationDelivery

Tracks delivery through an external channel.

Conceptual fields:

```text
NotificationDelivery
- id
- notification_id
- channel
- provider
- status
- attempt_count
- provider_message_id
- delivered_at
- failed_at
```

A notification may exist even when external delivery fails.

---

# 42. NotificationPreference

Conceptual fields:

```text
NotificationPreference
- user_id
- category
- email_enabled
- push_enabled
- sms_enabled
- updated_at
```

Mandatory security communications may override ordinary optional preferences.

---

# 43. PushEndpoint

Represents a mobile installation eligible for push delivery.

Conceptual fields:

```text
PushEndpoint
- id
- user_id
- platform
- installation_id
- push_token
- enabled
- last_seen_at
- invalidated_at
```

One user may have multiple devices.

---

# 44. Session / Security Session Record

Pachi may maintain an application session/security registry in addition to the external identity provider.

Conceptually:

```text
Session
- id
- user_id
- platform
- created_at
- expires_at
- revoked_at
- device_label
- provider_session_reference
```

This supports:

- session listing;
- sign-out;
- recovery;
- investigation.

---

# 45. AuditEvent

Represents durable trust/security/privileged history.

Conceptual fields:

```text
AuditEvent
- id
- event_type
- actor_type
- actor_id
- target_type
- target_id
- occurred_at
- request_id
- metadata
```

Audit events should not contain secrets such as:

- passwords;
- OTPs;
- tokens;
- raw verification documents.

---

# 46. Domain Relationship Summary

```text
User 1 ── * AuthIdentity

User 1 ── 0..1 IndividualProviderProfile

User * ── * Organization
       through OrganizationMembership

Property 1 ── * Listing

Property 1 ── 1 PropertyLocation

Property 1 ── * PropertyAuthority

Listing 1 ── * Interaction

Interaction 1 ── * ReviewEligibility

ReviewEligibility 1 ── 0..1 Review

VerificationCase * ── 1 VerificationSubject

VerificationCase 1 ── * VerificationEvidence

Report * ── 0..1 ModerationCase

ModerationCase 1 ── * ModerationAction

User 1 ── * Notification

Notification 1 ── * NotificationDelivery

User 1 ── * PushEndpoint
```

---

# 47. Permission Boundaries

Domain entities do not grant access merely because they can be referenced by ID.

Authorization depends on context.

Examples:

### Property

A user may read a public property representation but may edit only when they control the property through an approved provider/organization scope.

### Organization

Membership is necessary but role determines allowed actions.

### VerificationEvidence

Only authorized verification/staff workflows may access it.

### Review

Reviewer controls only allowed user-editable review actions; moderation state remains privileged.

### ModerationCase

Ordinary users may create reports but cannot administer cases.

---

# 48. Lifecycle Coupling Rules

Some state changes affect other entities.

Examples:

```text
provider verification expires
→ related published listings may PAUSE
```

```text
provider verification revoked
→ related listings may enter UNDER_MODERATION
```

```text
interaction invalidated
→ review eligibility revoked
→ related review contribution reevaluated
```

```text
organization membership removed
→ member loses organization-scoped capability
```

```text
listing CLOSED
→ no new viewing request
```

These effects should be implemented through explicit domain services/events rather than implicit client behavior.

---

# 49. External-System Boundaries

Pachi uses external providers for capabilities, not domain ownership.

| Concern | External Capability | Pachi Authority |
|---|---|---|
| Authentication credentials | Cognito | User identity mapping, account state, authorization |
| Maps/geocoding | Google Maps Platform | Canonical property geography and neighborhoods |
| Email | SES | Notification intent/preferences/history |
| SMS | AWS End User Messaging SMS | OTP validity and notification intent |
| Push | Expo Push Service | Device relationship and notification history |
| Binary storage | S3 | Media ownership, classification, moderation, retention |

---

# 50. Domain Model and Database Schema

This document does not require a one-table-per-entity implementation.

The database design may:

- normalize;
- merge supporting records;
- materialize projections;
- use event/audit tables;

provided the domain invariants remain clear.

Database schema decisions must not erase distinctions such as:

- property vs listing;
- authentication vs authorization;
- verification type vs global verified state;
- review vs review eligibility;
- public media vs verification evidence.

---

# 51. Domain Model Authority

Detailed rules are owned by specialized documents:

- roles and permissions → `roles-and-permissions.md`;
- lifecycle transitions → `lifecycle-states.md`;
- verification → `verification-model.md`;
- reviews → `review-system.md`;
- interaction/moderation rules → `interaction-and-moderation-rules.md`.

If this overview conflicts with a specialized approved domain document, the specialized domain document wins.

Architecture documents may define implementation mechanisms but must not silently redefine these entities or rules.
