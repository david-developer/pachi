# Pachi — Verification Model

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document is the primary source of truth for verification subjects, verification levels, evidence requirements, review outcomes, permission gates, revocation rules, and verification audit requirements.  
> **Related Documents:**  
> - `docs/00-product/product-specification.md`
> - `docs/01-domain/domain-model.md`
> - `docs/01-domain/roles-and-permissions.md`
> - `docs/01-domain/lifecycle-states.md`
> - `docs/01-domain/review-system.md`
> - `docs/03-engineering/authentication.md`
> - `docs/03-engineering/authorization.md`
> - `docs/03-engineering/security.md`
> - `docs/04-business-rules/listing-rules.md`
> - `docs/04-business-rules/fraud-prevention.md`
> - `docs/04-business-rules/moderation-rules.md`

---

## 1. Purpose

This document defines how Pachi establishes and represents trust through verification.

Verification exists to reduce impersonation, fraudulent listings, false provider identities, unauthorized property representation, and other marketplace abuse.

Verification must answer specific questions such as:

- Is this contact method controlled by the user?
- Has this user's identity been verified?
- Is this provider allowed to act as a provider on Pachi?
- Does this organization appear to be a real operating entity?
- Is this user authorized to act for this organization?
- Is there sufficient evidence that a provider may represent a specific property?
- Is the verification still valid?

Verification does **not** mean Pachi guarantees that a person, organization, property, transaction, or legal claim is risk-free.

The meaning of every verification indicator must remain narrow and explicit.

---

## 2. Verification Principles

### 2.1 Verification is subject-specific

Pachi must not use one global `is_verified` field to represent all trust decisions.

Verification applies to a specific subject.

Examples:

- user account;
- person identity;
- individual provider;
- organization;
- organization representative;
- property representation authority.

### 2.2 Verification is evidence-based

A verification decision must be supported by documented evidence or an approved trusted verification source.

The system must retain enough information to explain why a verification was granted, rejected, expired, or revoked.

### 2.3 Verification is not permanent by default

Verification may become invalid because:

- evidence expires;
- identity information changes;
- organization status changes;
- authority to represent a property ends;
- fraud is discovered;
- submitted information was materially incorrect;
- moderation or security review invalidates the previous decision.

### 2.4 Permissions depend on current verification

A permission that requires verification must check the **current valid verification state**, not whether the user was verified at some point in the past.

### 2.5 Verification and authorization are separate

Verification establishes trust or eligibility.

Authorization determines whether the actor may perform a requested action.

An actor may be verified but still lack permission because:

- the resource belongs to another provider;
- the actor lacks the required organization role;
- the listing state does not permit the action;
- the account is restricted;
- the verification applies to a different subject.

### 2.6 Verification and moderation are separate

A verified account can still violate marketplace rules.

A moderation restriction may block an action even when verification requirements are satisfied.

### 2.7 Minimize sensitive data

Pachi should collect only the evidence reasonably required for the verification purpose.

Sensitive evidence must have stricter access controls and retention rules than ordinary marketplace profile data.

### 2.8 Public verification indicators must be precise

Public-facing badges or labels must communicate exactly what Pachi verified.

Avoid broad labels that could incorrectly imply:

- legal ownership;
- government endorsement;
- guaranteed safety;
- guaranteed property condition;
- guaranteed transaction legitimacy.

---

# 3. Verification Architecture

Pachi should model verification using three concepts:

```text
Verification Subject
        ↓
Verification Case
        ↓
Verification Result
```

### Verification Subject

The person, organization, provider, property-authority relationship, or other entity being verified.

### Verification Case

A specific verification attempt containing:

- submitted evidence;
- review state;
- reviewer activity;
- decision;
- timestamps;
- reasons;
- related risk signals.

### Verification Result

The effective trust outcome used by authorization and user-facing trust indicators.

A subject may have multiple historical verification cases but only one currently effective result of a given verification type.

---

# 4. Verification Types

Pachi initially defines the following verification types.

| Code | Verification Type | Subject | Primary Question |
|---|---|---|---|
| `CONTACT_EMAIL` | Email verification | User | Does the user control this email address? |
| `CONTACT_PHONE` | Phone verification | User | Does the user control this phone number? |
| `IDENTITY_PERSON` | Personal identity verification | Person/User | Has the person's identity been sufficiently verified? |
| `PROVIDER_INDIVIDUAL` | Individual provider verification | Individual Provider | Is this person eligible to act as a property provider? |
| `ORGANIZATION_ENTITY` | Organization verification | Organization | Is there sufficient evidence that this organization exists and operates as represented? |
| `ORGANIZATION_REPRESENTATIVE` | Organization representative verification | User + Organization | Is this user authorized to act for this organization? |
| `PROPERTY_AUTHORITY` | Property representation authority | Provider + Property | Is there sufficient evidence that this provider may represent this property? |

Additional verification types require an update to this document.

---

# 5. Verification Levels

Pachi uses **subject-specific verification levels** rather than one universal global level.

This avoids incorrect assumptions such as:

> "This account is Level 3, therefore every property the account posts is verified."

Verification levels describe assurance for one subject.

---

## 5.1 User Assurance Levels

### `U0 — Account Created`

The user has created an account but has not completed required contact verification.

Typical permissions:

- manage basic account setup;
- complete verification steps;
- access public browsing where authentication is not required.

Must not unlock trust-sensitive provider actions.

### `U1 — Contact Verified`

At least the required primary contact method has been verified.

Minimum requirement:

- verified email and/or verified phone according to current authentication policy.

Typical permissions unlocked:

- normal authenticated-user functionality;
- save listings;
- initiate allowed contact or interaction flows;
- report content;
- begin provider onboarding;
- begin organization onboarding.

Whether both email and phone are required for `U1` is an open product/security decision.

### `U2 — Identity Verified`

The user's personal identity has been reviewed and approved.

Requirements:

- valid `IDENTITY_PERSON` verification;
- required contact verification remains valid.

Typical permissions unlocked:

- eligibility for higher-trust provider workflows;
- eligibility to become a verified individual provider;
- eligibility to become a verified organization representative;
- access to verification-dependent marketplace functions.

`U2` alone does not prove property authority.

---

## 5.2 Individual Provider Assurance Levels

### `P0 — Provider Profile Created`

The user has created provider information but has not yet satisfied provider verification requirements.

Typical permissions:

- edit provider profile;
- create permitted draft resources;
- submit verification evidence.

Must not be publicly represented as a verified provider.

### `P1 — Identity-Backed Provider`

The provider has a valid identity verification and meets basic provider eligibility requirements.

Typical permissions:

- maintain provider profile;
- create properties and listing drafts, subject to business rules;
- participate in provider onboarding flows.

Publication rights may remain restricted until stronger requirements are satisfied.

### `P2 — Verified Individual Provider`

The individual provider has satisfied all required provider verification requirements.

Expected requirements:

- `U2 — Identity Verified`;
- approved `PROVIDER_INDIVIDUAL` verification;
- no active disqualifying moderation restriction.

Typical permissions unlocked:

- publish eligible listings when property-authority requirements are also satisfied;
- appear publicly with a provider-verification indicator;
- receive provider-facing marketplace interactions;
- use provider operational features.

`P2` does not automatically verify every property represented by the provider.

---

## 5.3 Organization Assurance Levels

### `O0 — Organization Draft`

Organization record exists but organization verification has not been completed.

Typical permissions:

- owner/admin may complete organization setup;
- submit organization evidence;
- manage limited onboarding settings.

The organization must not be publicly represented as verified.

### `O1 — Organization Submitted`

The organization has submitted sufficient evidence for review but has not been approved.

Typical permissions:

- continue verification workflow;
- resolve requested evidence issues;
- configure permitted draft resources.

Publication should remain restricted unless a specific business rule permits otherwise.

### `O2 — Verified Organization`

The organization has an approved `ORGANIZATION_ENTITY` verification.

Expected requirements:

- required organization identity/registration evidence accepted;
- at least one authorized organization representative verified;
- no active disqualifying restriction.

Typical permissions unlocked:

- public verified-organization indicator;
- organization-level publication eligibility, subject to property authority and member permissions;
- organization onboarding completion;
- access to verified-organization operational features.

`O2` does not automatically verify every employee, agent, property, or listing.

---

## 5.4 Property Authority Levels

### `A0 — Authority Not Established`

A provider has associated themselves with a property but authority to represent the property has not been accepted.

Typical permissions:

- maintain a private property draft if otherwise allowed;
- submit authority evidence.

Must not unlock public listing publication for that property.

### `A1 — Authority Under Review`

Required evidence has been submitted and is under review.

Typical permissions:

- respond to evidence requests;
- update supporting information where allowed.

Must not be publicly described as verified authority.

### `A2 — Authority Verified`

Pachi has accepted the submitted evidence as sufficient to establish marketplace representation authority for the property.

Typical permissions unlocked:

- provider may publish an eligible listing for that property, subject to all other requirements;
- property/listing may show an appropriately worded authority indicator if product policy permits.

`A2` means Pachi accepted evidence of representation authority according to its verification policy.

It must **not** be described as a legal guarantee of ownership.

---

# 6. Evidence Requirements

Evidence requirements should be proportionate to risk and verification purpose.

The exact providers, document types, and automated checks may change over time without changing the conceptual verification model.

---

## 6.1 Email Verification Evidence

Required evidence:

- successful possession challenge to the submitted email address.

Examples:

- one-time verification link;
- one-time code.

Evidence stored:

- email address;
- verification timestamp;
- challenge outcome;
- provider/system metadata where needed.

Do not store verification secrets after they are no longer needed.

---

## 6.2 Phone Verification Evidence

Required evidence:

- successful possession challenge to the submitted phone number.

Examples:

- SMS one-time code;
- approved alternative phone verification mechanism.

Evidence stored:

- normalized phone number;
- verification timestamp;
- challenge outcome;
- provider/system metadata where needed.

---

## 6.3 Personal Identity Verification Evidence

Expected evidence may include one or more of:

- government-issued identity document;
- passport;
- national identity card;
- residence document where accepted;
- selfie/liveness check if required;
- trusted identity-verification provider result.

The final accepted document set must be defined before implementation.

Evidence review should consider:

- document validity;
- document expiration;
- identity information consistency;
- evidence tampering indicators;
- duplicate identity risk where technically and legally appropriate.

Public users must never have access to submitted identity documents.

---

## 6.4 Individual Provider Verification Evidence

Provider verification may require:

- valid personal identity verification;
- verified contact details;
- provider profile information;
- declarations required by Pachi;
- additional supporting documents for provider category where applicable.

Provider verification should answer:

> Is this person sufficiently identified and eligible to act as a provider on Pachi?

It does not answer:

> Does this person own every property they list?

That is handled by `PROPERTY_AUTHORITY`.

---

## 6.5 Organization Verification Evidence

Expected evidence may include:

- organization legal or registered name;
- registration or incorporation evidence where applicable;
- business registration identifier where applicable;
- registered or operating address;
- official contact information;
- organization representative details;
- evidence linking the representative to the organization;
- additional documentation required by organization type.

Where an organization is not formally incorporated but legitimately operates in a recognized provider capacity, Pachi must define a separate accepted evidence path before supporting that category.

---

## 6.6 Organization Representative Evidence

Expected evidence may include:

- verified personal identity;
- organization invitation or owner confirmation;
- employment/agency evidence where required;
- corporate authorization document where required for high-privilege roles;
- owner/admin approval;
- other trusted evidence of authority.

Higher-risk roles may require stronger evidence than ordinary agent membership.

For example:

- organization owner;
- ownership-transfer recipient;
- administrator with member-management authority.

---

## 6.7 Property Authority Evidence

Accepted evidence depends on how the provider is authorized to represent the property.

Potential evidence categories include:

### Owner representation

Examples:

- ownership/title documentation;
- legally recognized property documentation;
- other accepted ownership evidence.

### Authorized agent representation

Examples:

- property management agreement;
- agency agreement;
- owner authorization;
- landlord authorization;
- signed representation agreement;
- other accepted authorization evidence.

### Organization representation

Examples:

- property assigned to a verified organization;
- organization-level management agreement;
- verified owner/manager authorization;
- property portfolio evidence.

Evidence should establish a plausible chain:

```text
Verified Provider / Organization
        ↓
Accepted authority evidence
        ↓
Specific Property
```

Property authority must be scoped to a specific property or defined property portfolio.

---

# 7. Verification Review States

Verification cases use the state machine defined in `lifecycle-states.md`.

The authoritative states are:

```text
DRAFT
SUBMITTED
UNDER_REVIEW
ACTION_REQUIRED
VERIFIED
REJECTED
EXPIRED
REVOKED
CANCELLED
```

## 7.1 `DRAFT`

Evidence collection has begun but the case is not ready for review.

No verification permission is unlocked.

## 7.2 `SUBMITTED`

Applicant declares the verification submission ready.

System should validate minimum required evidence before allowing this transition.

No verification permission is unlocked merely because a case was submitted.

## 7.3 `UNDER_REVIEW`

Automated and/or manual verification is actively occurring.

No final verification permission is unlocked.

## 7.4 `ACTION_REQUIRED`

Additional or corrected evidence is required.

The system should record:

- request reason;
- evidence requested;
- deadline if applicable;
- reviewer/system actor.

## 7.5 `VERIFIED`

Evidence has been accepted.

A verification result becomes effective only if:

- the case decision is valid;
- the subject still satisfies applicable conditions;
- the verification has not expired or been revoked;
- no higher-priority restriction blocks the relevant permission.

## 7.6 `REJECTED`

Evidence was insufficient or failed verification requirements.

A rejection reason must be recorded.

Public-facing rejection messaging may be less detailed than internal review reasons where fraud controls or security require confidentiality.

## 7.7 `EXPIRED`

A previously valid verification reached its expiry condition.

The verification must immediately stop satisfying permissions that require a currently valid result.

## 7.8 `REVOKED`

A previously valid verification was invalidated before normal expiry.

Revocation requires:

- authorized actor or trusted automated control;
- reason code;
- timestamp;
- audit entry;
- downstream permission update.

## 7.9 `CANCELLED`

The applicant withdrew the case or the case was administratively cancelled before a final decision.

No verification permission is unlocked.

---

# 8. Permission Gates

Verification must be evaluated together with role, ownership, lifecycle state, and moderation status.

## 8.1 Permission Matrix

| Capability | Minimum Verification |
|---|---|
| Browse public listings | None |
| Create account | None |
| Save listings | `U1` |
| Contact provider | `U1`, subject to product policy |
| Request viewing | `U1`, subject to product policy |
| Submit reports | `U1` |
| Begin provider onboarding | `U1` |
| Create provider profile | `U1` |
| Create private provider draft resources | `P0` or higher, subject to authorization |
| Create individual property draft | `P1` |
| Publish individual listing | `P2` + `A2` for represented property |
| Act as organization agent | `U1` + active membership; stronger verification may be required |
| Act as organization admin | Active membership + required representative verification |
| Act as organization owner | `U2` + required representative verification |
| Publish organization listing | `O2` + `A2` + actor authorization |
| Display verified individual-provider badge | `P2` |
| Display verified-organization badge | `O2` |
| Display property-authority indicator | `A2`, if product policy exposes it |

This matrix is the baseline domain model.

More restrictive rules may be defined by business rules or security policy.

---

# 9. Publication Eligibility

A listing must not be published solely because the provider account is verified.

For an individual provider:

```text
can_publish =
    user_contact_verified
    AND individual_provider == P2
    AND property_authority == A2
    AND actor_controls_listing
    AND listing_state_allows_publication
    AND no_blocking_restriction
```

For an organization:

```text
can_publish =
    organization == O2
    AND actor_has_active_membership
    AND actor_role_allows_publication
    AND required_representative_verification_satisfied
    AND property_authority == A2
    AND listing_state_allows_publication
    AND no_blocking_restriction
```

This model intentionally separates:

- provider trust;
- organization trust;
- property authority;
- user authorization.

---

# 10. Public Verification Indicators

Public verification indicators must be derived from current effective verification results.

Possible labels include:

- **Identity Verified**
- **Verified Provider**
- **Verified Organization**
- **Property Authority Verified**

Final wording should be reviewed for legal and product clarity.

Avoid labels such as:

- "Pachi Approved Property";
- "Guaranteed Owner";
- "Safe Property";
- "Guaranteed Provider";

unless Pachi actually performs the level of due diligence required to support such claims.

---

# 11. Expiration Rules

Verification types may have different expiry behavior.

## 11.1 Contact Verification

Email or phone verification may remain valid until:

- the contact value changes;
- suspicious account recovery occurs;
- security policy requires re-verification.

## 11.2 Identity Verification

Identity verification may expire when:

- the underlying document expires;
- a defined re-verification interval is reached;
- material identity information changes;
- security review requires re-verification.

## 11.3 Provider Verification

Provider verification may require periodic renewal.

Triggers may include:

- underlying identity verification expiry;
- material profile change;
- prolonged inactivity;
- fraud review;
- policy-driven renewal interval.

## 11.4 Organization Verification

Organization verification may expire or require revalidation when:

- registration evidence expires;
- organization ownership changes;
- legal identity changes;
- organization becomes inactive;
- a defined re-verification interval is reached;
- fraud or moderation concerns arise.

## 11.5 Property Authority Verification

Property authority should normally have stronger expiry controls than identity verification because representation authority can change.

Potential triggers:

- authorization agreement expires;
- listing/property relationship ends;
- owner revokes authority;
- organization loses management rights;
- property changes ownership;
- a defined revalidation period is reached.

The exact expiry interval is an open policy decision.

---

# 12. Revocation Rules

A valid verification may be revoked when Pachi has sufficient reason to conclude that the verification should no longer be trusted.

## 12.1 Revocation Grounds

Possible grounds include:

- fraudulent evidence;
- forged or altered documents;
- impersonation;
- false organization identity;
- materially false verification information;
- loss of authority to represent a property;
- compromised account;
- duplicate or conflicting identity evidence;
- verification granted in error;
- legal or regulatory requirement;
- serious moderation investigation establishing invalid verification;
- trusted external verification source retracting or invalidating a result.

## 12.2 Revocation Authority

Revocation may be initiated only by:

- an authorized verification reviewer;
- an authorized moderator where policy grants that power;
- a platform administrator;
- a trusted automated system rule approved for the verification type.

Applicants must not be able to remove a revocation by editing profile data.

## 12.3 Required Revocation Data

Every revocation must record:

```text
verification_result_id
verification_type
subject_id
previous_state
new_state = REVOKED
revoked_at
revoked_by
reason_code
internal_reason
evidence_reference
affected_permissions
related_case_or_report_id
```

Where appropriate, the user-facing explanation may differ from the internal fraud/security explanation.

## 12.4 Downstream Effects

Revocation must trigger reevaluation of dependent permissions.

Examples:

### Individual provider revoked

Potential effects:

- remove verified-provider indicator;
- block new listing publication;
- move affected published listings to the policy-defined restricted state;
- restrict provider onboarding actions;
- create moderation/review tasks if required.

### Organization verification revoked

Potential effects:

- remove organization verification indicator;
- block new organization listing publication;
- restrict organization-level trust actions;
- reevaluate active listings.

### Property authority revoked

Potential effects:

- immediately block publication for that property;
- apply policy to existing active listings for that property;
- preserve historical interactions;
- create moderation/audit records where required.

---

# 13. Re-Verification

Revoked, expired, or rejected verification must not be silently restored.

A new verification attempt should normally create a new verification case.

The new case may reference the previous one for history.

Conceptually:

```text
Previous Case: VERIFIED → EXPIRED
        ↓
New Case: DRAFT → SUBMITTED → ...
```

This preserves the audit trail.

---

# 14. Verification Evidence Storage

Verification evidence is sensitive.

The engineering implementation must ensure:

- private storage;
- access control;
- encryption in transit;
- encryption at rest where supported and appropriate;
- short-lived access URLs where object storage is used;
- no public object URLs;
- malware/file validation where applicable;
- file-type and size validation;
- audit logging for privileged evidence access;
- retention policy;
- secure deletion when retention expires.

Verification documents must never be stored in the same public-access pattern used for listing photos.

---

# 15. Evidence Access Rules

### Applicant

May view their own submitted evidence where product design permits.

### Organization Owner/Admin

May access only organization evidence explicitly intended for their role.

They must not automatically gain access to another user's personal identity documents.

### Verification Reviewer

May access evidence required for assigned verification work.

### Moderator

May access verification summaries by default.

Access to raw identity evidence should require explicit moderation/security authorization.

### Platform Administrator

Access should remain controlled and auditable even for administrators.

"Administrator" must not mean unrestricted silent access to all sensitive evidence.

---

# 16. Audit Requirements

Verification operations are high-trust events and require durable auditability.

## 16.1 Events That Must Be Audited

At minimum:

- verification case created;
- evidence uploaded;
- evidence removed;
- case submitted;
- review started;
- additional evidence requested;
- applicant responded;
- case approved;
- case rejected;
- verification expired;
- verification revoked;
- verification restored through a new approved case;
- sensitive evidence viewed by privileged staff;
- sensitive evidence downloaded by privileged staff, if downloads are allowed;
- reviewer reassigned;
- decision overridden by administrator.

## 16.2 Audit Record Fields

A verification audit event should contain, where relevant:

```text
event_id
verification_case_id
verification_result_id
verification_type
subject_type
subject_id
actor_id
actor_role
action
previous_state
new_state
reason_code
timestamp
request_id
ip_or_security_context
metadata
```

Audit records must not duplicate sensitive document contents unnecessarily.

## 16.3 Audit Immutability

Ordinary users and reviewers must not be able to rewrite or delete historical verification audit events.

Correction should occur through a new event rather than modification of prior history.

## 16.4 Evidence Access Audit

Access to high-risk evidence should record:

- who accessed it;
- when;
- verification case;
- purpose or workflow context where practical.

Repeated or unusual access patterns should be available for security investigation.

---

# 17. Review Assignment and Separation of Duties

Pachi should support separation between:

- applicant;
- reviewer;
- escalation reviewer;
- administrator.

A user must never review their own verification.

An organization member must not approve the organization's own platform verification unless explicitly allowed under a trusted external verification process.

High-risk decisions may require escalation or a second reviewer later, even if MVP initially uses one reviewer.

---

# 18. Fraud and Risk Signals

Verification may consider risk signals in addition to submitted documents.

Examples:

- duplicate identity indicators;
- repeated failed verification attempts;
- reused property evidence across unrelated accounts;
- suspicious account creation patterns;
- conflicting organization information;
- repeated revoked authority;
- evidence tampering indicators;
- account compromise signals.

Risk signals should inform review.

They should not be exposed publicly as accusations without a completed policy process.

Detailed fraud logic belongs in `fraud-prevention.md`.

---

# 19. Appeals and Disputes

A rejected or revoked verification may be eligible for appeal if Pachi supports appeals.

An appeal should not directly mutate the original decision.

Preferred model:

```text
Original Verification Decision
        ↓
Appeal / Review Case
        ↓
New Decision
```

If an appeal succeeds, the system should create a new auditable decision that supersedes the previous effective status.

The original decision remains historically visible to authorized staff.

---

# 20. Verification and Listing Lifecycle

Verification changes may affect listing state.

The baseline rule is:

```text
Required verification no longer valid
        ↓
Listing must no longer remain normally publishable
```

The exact transition should be finalized in the listing and moderation rules.

Recommended baseline:

### Expired verification

```text
PUBLISHED → PAUSED
```

Reason:

- expiry is often administrative rather than fraudulent;
- provider can complete re-verification;
- listing history remains intact.

### Revoked verification

```text
PUBLISHED → UNDER_MODERATION
```

Reason:

- revocation may indicate fraud, false authority, or trust risk;
- moderator review may be required before restoration.

This recommendation should be approved before implementation.

---

# 21. Verification and Organization Membership

Organization verification and membership verification must remain separate.

Examples:

- a verified organization may contain an unverified invited member;
- an identity-verified user may belong to an unverified organization;
- an active organization agent may require representative verification before gaining higher-risk permissions.

For sensitive organization actions, authorization may require:

```text
ACTIVE membership
AND sufficient organization role
AND required user assurance
AND required representative verification
```

---

# 22. Verification and Account Recovery

Sensitive account recovery may invalidate or require rechecking verification.

Examples:

- verified phone number changed;
- identity-linked account recovery;
- suspected account takeover;
- recovery performed by staff.

The security model should define when account recovery:

- preserves verification;
- temporarily restricts verification-dependent actions;
- requires re-verification.

---

# 23. API and Service Requirements

Verification must be represented through explicit domain operations.

Examples:

```text
createVerificationCase()
uploadVerificationEvidence()
submitVerificationCase()
startVerificationReview()
requestVerificationAction()
approveVerification()
rejectVerification()
revokeVerification()
```

Avoid unrestricted endpoints that allow arbitrary updates such as:

```text
PATCH /verification/{id}
{
  "status": "VERIFIED"
}
```

without domain-specific permission and transition checks.

---

# 24. Concurrency and Idempotency

Verification operations must be safe under retries and concurrent review.

Examples:

- applicant submits twice;
- two reviewers attempt conflicting decisions;
- revocation occurs while a new publication request is processed;
- expiration job and manual reviewer act at the same time.

Decision operations should use transactional or optimistic concurrency controls.

A verification case must not become both `VERIFIED` and `REJECTED` due to competing requests.

---

# 25. Minimum Testing Requirements

Automated tests should cover at least the following.

## Contact verification

- correct challenge verifies contact;
- invalid or expired challenge fails;
- changing verified contact removes or re-evaluates verification as required.

## Identity verification

- valid submission enters review;
- applicant cannot approve own verification;
- rejected identity does not satisfy `U2`;
- expired identity no longer satisfies dependent permissions.

## Individual provider

- `P0` provider cannot publish;
- `P1` provider cannot publish where `P2` is required;
- `P2` provider still cannot publish property without `A2`;
- revoked provider loses provider-verification dependent permissions.

## Organization

- unverified organization cannot use `O2` permissions;
- verified organization can act only through authorized members;
- organization verification does not grant membership;
- revocation removes organization-verification dependent permissions.

## Property authority

- provider cannot publish property at `A0`;
- provider cannot publish property at `A1`;
- provider may become publication-eligible at `A2` if all other rules pass;
- authority revocation blocks future publication immediately;
- provider cannot use authority verification for a different property.

## Audit

- every approval creates an audit event;
- every rejection creates an audit event;
- every revocation creates an audit event;
- privileged evidence access creates an audit event;
- ordinary users cannot modify audit history.

---

# 26. Open Decisions

The following decisions must be resolved before implementation of the affected verification flows.

### VM-OD-001 — Required contact methods

Does `U1` require:

- verified email only;
- verified phone only;
- either one;
- both?

**Current status:** Open.

### VM-OD-002 — Identity verification provider

Will Pachi use:

- manual document review;
- a third-party identity provider;
- a hybrid model?

**Current status:** Architecture/vendor decision.

### VM-OD-003 — Accepted identity documents

Which identity documents are accepted for the initial target market?

**Current status:** Open.

### VM-OD-004 — Provider verification requirements

What additional requirements, if any, beyond identity verification are necessary for `P2`?

**Current status:** Open.

### VM-OD-005 — Organization evidence

What organization evidence is mandatory for `O2` across supported organization types?

**Current status:** Open.

### VM-OD-006 — Property authority evidence

Which evidence types are accepted for:

- property owner;
- landlord;
- agent;
- property manager;
- organization;
- other provider categories?

**Current status:** Open.

### VM-OD-007 — Property authority expiry

How long may `A2` remain valid without revalidation?

**Current status:** Open.

### VM-OD-008 — Listing behavior after verification expiry

Should expired required verification move listings to `PAUSED` automatically?

**Current recommendation:** Yes.

### VM-OD-009 — Listing behavior after verification revocation

Should revoked required verification move listings to `UNDER_MODERATION` automatically?

**Current recommendation:** Yes.

### VM-OD-010 — Public verification badges

Which verification results are visible publicly, and what exact labels are shown?

**Current status:** Open.

### VM-OD-011 — Appeals

Will verification rejection and revocation have a formal appeal workflow in MVP or post-MVP?

**Current status:** Open.

---

# 27. Decisions Established by This Document

Unless changed through an approved product update, this document establishes the following baseline decisions:

1. Pachi must not represent verification with one global `is_verified` flag.
2. Verification is scoped to a specific subject and verification type.
3. User, provider, organization, and property-authority assurance are separate.
4. Individual listing publication requires both provider verification and property-authority verification.
5. Organization listing publication requires organization verification, actor authorization, and property-authority verification.
6. Verification approval does not override authorization, lifecycle, or moderation restrictions.
7. Verification may expire or be revoked.
8. Revocation requires an auditable reason and immediate downstream permission reevaluation.
9. Sensitive verification evidence is private and must use stricter access controls than public marketplace media.
10. Privileged evidence access must be auditable.
11. Re-verification should normally create a new verification case rather than rewriting historical decisions.
12. Public verification wording must not imply guarantees beyond the evidence actually reviewed.

---

# 28. Definition of Done

This document may move from **Draft for Review** to **Approved** when:

- required contact verification is decided;
- accepted personal identity evidence is defined;
- individual provider requirements for `P2` are defined;
- organization evidence requirements are defined;
- property-authority evidence categories are approved;
- verification expiry periods are defined where needed;
- listing behavior after expiry and revocation is approved;
- public badge wording is approved;
- appeal behavior is decided;
- verification rules are consistent with `roles-and-permissions.md`;
- verification lifecycle behavior is consistent with `lifecycle-states.md`;
- no known conflicts remain with the product specification or core domain model.
