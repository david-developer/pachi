# Pachi — Interaction and Moderation Rules

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document is the primary source of truth for qualifying marketplace interactions, cancellations, no-shows, disputes, review eligibility triggers, and moderation workflows.  
> **Related Documents:**  
> - `docs/00-product/product-specification.md`
> - `docs/01-domain/domain-model.md`
> - `docs/01-domain/roles-and-permissions.md`
> - `docs/01-domain/lifecycle-states.md`
> - `docs/01-domain/verification-model.md`
> - `docs/01-domain/review-system.md`
> - `docs/04-business-rules/listing-rules.md`
> - `docs/04-business-rules/review-rules.md`
> - `docs/04-business-rules/fraud-prevention.md`
> - `docs/04-business-rules/moderation-rules.md`
> - `docs/03-engineering/authorization.md`
> - `docs/03-engineering/security.md`

---

## 1. Purpose

This document defines how structured marketplace interactions operate in Pachi and how interaction outcomes connect to:

- cancellations;
- no-shows;
- disputes;
- review eligibility;
- trust signals;
- moderation cases;
- enforcement actions.

The goal is to ensure that marketplace history is reliable enough to support reputation, moderation, fraud prevention, and dispute resolution.

Interactions are not merely chat threads.

They are structured business records representing meaningful marketplace events between seekers and providers.

---

## 2. Interaction Principles

### 2.1 Interactions are explicit domain records

A qualifying marketplace interaction must exist as a structured record.

Messages may support an interaction, but messages alone do not prove that a qualifying event occurred.

---

### 2.2 Interaction state changes require authorization

Only participants or authorized staff may perform state transitions.

A user must not be able to change another party's interaction state arbitrarily.

---

### 2.3 Completion must be meaningful

An interaction must not become `COMPLETED` merely because time passed.

Completion must be based on an explicit event or confirmation rule.

---

### 2.4 Interaction history is durable

Once an interaction has meaningful marketplace consequences, its history must be preserved.

Examples:

- cancellation;
- no-show;
- completed viewing;
- review eligibility;
- moderation dispute.

---

### 2.5 Trust outcomes must not depend on client input alone

Clients may request state transitions.

The backend must validate:

- actor;
- resource scope;
- current state;
- eligibility;
- timing;
- related listing state;
- restrictions.

---

### 2.6 Moderation is not a substitute for normal workflow

Normal provider/seeker disagreement should first follow interaction rules.

Moderation is used when:

- platform policy may have been violated;
- fraud is suspected;
- harassment or abuse is reported;
- a trust-impacting record is disputed;
- an exceptional override is required.

---

# 3. Interaction Types

Pachi initially recognizes the following interaction types.

## 3.1 Inquiry

A seeker expresses interest in a listing or property.

Examples:

- asks for additional information;
- asks whether the property is still available;
- requests clarification.

An inquiry alone does not create review eligibility.

---

## 3.2 Contact Request

A seeker requests direct contact with the provider through a structured platform action.

This may be used where Pachi controls or gates provider contact information.

A contact request alone does not create review eligibility.

---

## 3.3 Viewing Request

A seeker requests an in-person or supported remote viewing of a property.

This is the primary interaction type for trust-qualified marketplace activity.

A viewing request can progress through:

```text
REQUESTED
→ ACCEPTED
→ SCHEDULED
→ COMPLETED
```

with alternative terminal outcomes such as:

```text
DECLINED
CANCELLED
NO_SHOW
EXPIRED
```

---

## 3.4 Viewing Appointment

A confirmed scheduled viewing between a seeker and provider.

This may be implemented as part of the interaction record or as a related schedule record.

A viewing appointment should capture:

- date and time;
- timezone;
- location or meeting method;
- seeker;
- provider/organization;
- listing/property;
- status;
- cancellation history;
- no-show information where applicable.

---

# 4. Qualifying Interactions

A qualifying interaction is an interaction that can create review eligibility or another trust-relevant outcome.

Baseline rule:

```text
qualifying_interaction =
    interaction.type == VIEWING
    AND interaction.state == COMPLETED
```

Other interaction types must not create review eligibility unless explicitly added to this document.

---

## 4.1 Non-Qualifying Examples

The following must not create ordinary review eligibility:

- viewing a listing page;
- saving a listing;
- sending a message;
- sending an inquiry;
- requesting contact;
- receiving a provider reply;
- having a viewing request declined;
- cancelling before the viewing occurs;
- letting a request expire.

---

## 4.2 Qualifying Completion Requirements

A completed interaction must satisfy:

```text
valid_interaction
AND valid_participants
AND interaction_was_scheduled_or_accepted
AND completion_rule_satisfied
AND interaction_not_invalidated
AND no_active_fraud_override
```

---

# 5. Interaction Participants

Every structured interaction must identify:

- seeker;
- provider actor;
- provider subject;
- organization, where applicable;
- listing;
- property;
- interaction type.

For organization listings, distinguish between:

- the user who handled the interaction;
- the organization represented by that user.

This allows the system to support:

- organization reviews;
- agent accountability;
- audit history.

---

# 6. Interaction Lifecycle

The lifecycle states are defined in `lifecycle-states.md`.

Expected states:

```text
REQUESTED
ACCEPTED
SCHEDULED
IN_PROGRESS
COMPLETED
DECLINED
CANCELLED
NO_SHOW
EXPIRED
```

`IN_PROGRESS` may be omitted from MVP if not operationally required.

---

# 7. Viewing Request Rules

## 7.1 Creating a Request

A seeker may request a viewing only when:

```text
authenticated
AND contact_requirements_satisfied
AND listing.state == PUBLISHED
AND listing_accepts_interactions
AND seeker_not_blocked
AND provider_not_blocked
AND no_applicable_policy_restriction
```

---

## 7.2 Provider Response

An authorized provider may:

- accept;
- schedule;
- decline.

A provider must not be required to accept every request.

Declining a viewing request alone must not create a negative reputation event.

---

## 7.3 Expiration

A viewing request may move to `EXPIRED` if the provider does not respond within a configured response period.

The timeout should be configurable.

Expiration should not automatically penalize either party unless future trust policy explicitly defines a responsiveness metric.

---

# 8. Scheduling Rules

A viewing becomes `SCHEDULED` only when a valid appointment exists.

Required scheduling data should include:

```text
scheduled_start
timezone
location_or_meeting_method
participants
```

Optional data may include:

```text
scheduled_end
special_instructions
meeting_point
contact_preferences
```

---

## 8.1 Rescheduling

Rescheduling must preserve history.

The system should not overwrite the previous scheduled time without recording the change.

Recommended data:

```text
previous_start
new_start
changed_by
changed_at
reason
```

---

## 8.2 Scheduling Conflicts

The system may warn about conflicts but does not initially need to guarantee conflict-free calendars unless calendar functionality becomes part of the product.

---

# 9. Cancellations

## 9.1 Cancellation Eligibility

An authorized participant may cancel an interaction before completion according to cancellation policy.

Possible actors:

- seeker;
- provider;
- organization representative;
- moderator/admin in exceptional cases.

---

## 9.2 Cancellation Metadata

Every cancellation should record:

```text
cancelled_by
cancelled_at
cancellation_reason_code
cancellation_note
previous_state
```

---

## 9.3 Cancellation Reason Codes

Recommended baseline codes:

```text
NO_LONGER_INTERESTED
PROPERTY_UNAVAILABLE
SCHEDULE_CONFLICT
RESCHEDULE_REQUESTED
PROVIDER_UNAVAILABLE
SEEKER_UNAVAILABLE
SAFETY_CONCERN
DUPLICATE_REQUEST
OTHER
```

Reason codes should be used carefully.

They are operational signals, not automatic proof of misconduct.

---

## 9.4 Cancellation and Reviews

Baseline policy:

```text
CANCELLED → no ordinary review eligibility
```

Cancellation history may contribute to internal trust signals if patterns become significant.

---

## 9.5 Late Cancellation

Pachi may later distinguish between:

- normal cancellation;
- late cancellation.

If introduced, late-cancellation thresholds must be configurable.

Late cancellation should not automatically become a star-rated review event.

A structured reliability signal is preferable.

---

# 10. No-Shows

## 10.1 Definition

A no-show occurs when a participant fails to attend a scheduled interaction and does not cancel according to the applicable rules.

No-show status must not be inferred only because the scheduled time passed.

---

## 10.2 No-Show Responsibility

Where possible, the system should identify:

```text
SEEKER_NO_SHOW
PROVIDER_NO_SHOW
BOTH_UNCONFIRMED
DISPUTED
```

---

## 10.3 No-Show Evidence

No-show confirmation may rely on:

- participant report;
- confirmation by both parties;
- check-in data if introduced later;
- location or operational evidence if product policy supports it;
- moderator review in disputed cases.

The system must not pretend a no-show is objectively verified when it is based only on one party's claim.

---

## 10.4 No-Show Review Eligibility

Recommended baseline:

```text
NO_SHOW → no ordinary star-rating review eligibility
```

Instead, Pachi should represent no-shows as structured trust events.

Reason:

- star ratings may encourage retaliation;
- the event has a narrow meaning;
- structured reliability signals are easier to moderate and audit.

---

## 10.5 Repeated No-Shows

Repeated confirmed no-shows may contribute to internal trust/risk signals.

Potential future consequences:

- warning;
- temporary interaction restrictions;
- lower scheduling priority;
- additional confirmation requirement;
- moderation review.

Detailed thresholds should live in `fraud-prevention.md` or moderation policy.

---

# 11. Completion Rules

## 11.1 Completion Authority

A viewing may become `COMPLETED` only through an approved confirmation model.

Possible models:

- seeker confirmation;
- provider confirmation;
- either-party confirmation;
- two-party confirmation;
- automatic completion after scheduled time plus dispute window;
- staff confirmation in exceptional cases.

Recommended baseline for MVP:

```text
either participant may mark the viewing as completed
AND the other participant receives a short dispute window
```

This avoids requiring synchronous dual confirmation while still allowing challenge.

---

## 11.2 Completion Metadata

Record:

```text
completed_at
completion_recorded_by
completion_method
confirmation_status
```

---

## 11.3 Disputed Completion

If the other party disputes the completion within the permitted window:

```text
COMPLETED
→ trust_effects temporarily suspended
→ moderation/dispute review
```

The system should not destroy the original completion event.

---

# 12. Review Eligibility

Review eligibility is governed jointly by this document and `review-system.md`.

Baseline rule:

```text
COMPLETED interaction
        ↓
review eligibility created
```

Each eligible direction should create its own eligibility record.

Example:

```text
Interaction #123

Seeker → Provider review eligibility
Provider → Seeker review eligibility
```

if reciprocal reviews are enabled.

---

## 12.1 Eligibility Conditions

Eligibility may be created only when:

```text
interaction.state == COMPLETED
AND interaction.valid == true
AND participants_match
AND no_fraud_invalidation
AND no_active_dispute_block
```

---

## 12.2 Eligibility Suspension

Review eligibility may be temporarily suspended when:

- completion is disputed;
- interaction is under fraud review;
- one participant is under a relevant restriction.

---

## 12.3 Eligibility Revocation

Eligibility may be revoked when:

- interaction was fraudulent;
- interaction was created only to manufacture reviews;
- completion was invalid;
- participants were not genuinely involved;
- moderator determines that the interaction record is unreliable.

Revocation must be auditable.

---

# 13. Disputes

A dispute is a structured challenge to a trust-impacting marketplace record.

Possible disputed events include:

- completion;
- cancellation reason;
- no-show;
- review;
- moderation action;
- provider conduct;
- seeker conduct.

---

## 13.1 Dispute Principles

A dispute:

- does not automatically prove misconduct;
- does not automatically erase the underlying record;
- must identify the disputed event;
- must have an initiator;
- must preserve evidence;
- must have a resolution.

---

## 13.2 Dispute States

Recommended states:

```text
OPEN
UNDER_REVIEW
RESOLVED_UPHELD
RESOLVED_OVERTURNED
RESOLVED_PARTIAL
CLOSED
```

---

## 13.3 Dispute Record

A dispute should include:

```text
dispute_id
interaction_id
review_id
report_id
opened_by
target_actor
dispute_type
description
evidence_refs
state
assigned_moderator
opened_at
resolved_at
resolution_code
resolution_note
```

Not every field applies to every dispute.

---

# 14. Moderation Workflow

Moderation should be case-based.

A report or system trigger creates a moderation case rather than directly mutating marketplace data without history.

---

## 14.1 Moderation Case Sources

Cases may originate from:

- user report;
- review report;
- listing report;
- provider report;
- organization report;
- disputed no-show;
- disputed completion;
- verification issue;
- automated fraud signal;
- staff observation.

---

## 14.2 Moderation Case States

Recommended states:

```text
OPEN
TRIAGED
UNDER_REVIEW
ACTION_REQUIRED
RESOLVED
CLOSED
```

---

## 14.3 `OPEN`

Case created but not yet classified.

---

## 14.4 `TRIAGED`

Case has been categorized and prioritized.

Possible categories:

```text
FRAUD
IMPERSONATION
HARASSMENT
LISTING_MISREPRESENTATION
REVIEW_ABUSE
NO_SHOW_DISPUTE
VERIFICATION_ISSUE
PRIVACY
SPAM
SAFETY
OTHER
```

---

## 14.5 `UNDER_REVIEW`

An authorized moderator is actively investigating.

The moderator may inspect only the information permitted by role and case scope.

---

## 14.6 `ACTION_REQUIRED`

Additional information is needed from:

- reporter;
- accused party;
- provider;
- seeker;
- organization;
- verification team.

---

## 14.7 `RESOLVED`

A moderation decision has been made.

A resolution must record:

- outcome;
- actions;
- reason;
- actor;
- timestamp.

---

## 14.8 `CLOSED`

The case is operationally complete.

Historical information remains available for audit and appeal.

---

# 15. Moderation Actions

Moderation actions must be explicit and proportionate.

Potential actions include:

```text
NO_ACTION
WARNING
CONTENT_HIDDEN
CONTENT_REMOVED
LISTING_PAUSED
LISTING_UNDER_MODERATION
INTERACTION_INVALIDATED
REVIEW_ELIGIBILITY_REVOKED
REVIEW_HIDDEN
REVIEW_REMOVED
VERIFICATION_REVIEW_REQUIRED
VERIFICATION_REVOKED
ACCOUNT_CAPABILITY_RESTRICTED
ACCOUNT_SUSPENDED
ORGANIZATION_RESTRICTED
ESCALATED
```

Not every moderator should necessarily have permission for every action.

---

# 16. Interaction Invalidation

A moderator may invalidate an interaction when reliable evidence shows it should not be treated as a genuine marketplace interaction.

Possible reasons:

- fabricated interaction;
- duplicate interaction created for review manipulation;
- collusion;
- wrong participants;
- mistaken completion;
- account compromise;
- test/fake data in production.

Invalidation must:

- preserve original history;
- stop the interaction from creating new review eligibility;
- revoke unconsumed eligibility;
- trigger review reevaluation where necessary.

---

# 17. Existing Reviews After Interaction Invalidation

If an interaction that created reviews is later invalidated:

```text
interaction invalidated
        ↓
related reviews require reevaluation
```

Possible outcomes:

- review hidden pending investigation;
- review removed;
- review remains if independent policy permits.

Baseline recommendation:

```text
invalidated interaction
→ related review becomes UNDER_MODERATION
→ reputation contribution suspended
```

until a decision is made.

---

# 18. Reports

A user may report:

- listing;
- review;
- provider;
- seeker;
- organization;
- interaction;
- message, where messaging exists.

---

## 18.1 Report Fields

Recommended fields:

```text
report_id
reporter_id
target_type
target_id
category
description
evidence_refs
created_at
state
moderation_case_id
```

---

## 18.2 Abuse of Reporting

Repeated false or malicious reporting may itself become a trust/moderation issue.

The system should not automatically punish users merely because reports are dismissed.

Pattern-based abuse requires evidence.

---

# 19. Evidence Handling

Moderation evidence may include:

- interaction history;
- timestamps;
- messages;
- listing revisions;
- review history;
- verification summaries;
- uploaded user evidence;
- staff notes;
- audit records.

Evidence access must follow least-privilege rules.

Raw identity verification evidence should not be exposed to general moderators unless explicitly authorized.

---

# 20. Moderation and Listing State

Moderation may move listings into:

```text
UNDER_MODERATION
```

The previous operational state should be preserved.

Example:

```text
previous_state = PUBLISHED
moderation_state = UNDER_MODERATION
```

If restored, the listing should return to the appropriate prior state only if current publication requirements are still satisfied.

---

# 21. Moderation and Verification

Moderators may flag verification for review.

They should not automatically revoke high-trust verification unless their role explicitly permits it.

Recommended separation:

```text
Moderator
→ flag / restrict / escalate

Verification Reviewer or Authorized Admin
→ revoke verification
```

unless Pachi intentionally grants revocation authority to moderators.

---

# 22. Moderation and Account Restrictions

Pachi should support capability-specific restrictions.

Examples:

```text
CAN_CONTACT_PROVIDERS = false
CAN_REQUEST_VIEWINGS = false
CAN_CREATE_LISTINGS = false
CAN_PUBLISH_LISTINGS = false
CAN_SUBMIT_REVIEWS = false
CAN_MANAGE_ORGANIZATION = false
```

This is preferable to using only:

```text
is_banned = true
```

for every enforcement scenario.

---

# 23. Appeals

Moderation decisions may be appealable.

An appeal must not overwrite the original decision.

Preferred model:

```text
Moderation Decision
        ↓
Appeal Case
        ↓
Upheld / Reversed / Modified
```

All steps must remain auditable.

---

# 24. Trust Signals

Interaction outcomes may produce internal trust signals.

Examples:

- repeated confirmed no-shows;
- repeated late cancellations;
- unusually high dispute rate;
- repeated invalidated interactions;
- high rate of removed reviews;
- repeated listing moderation;
- suspicious interaction/review patterns.

Trust signals are not equivalent to public ratings.

They should be used carefully for:

- fraud detection;
- moderation prioritization;
- safety controls;
- internal risk assessment.

---

# 25. Audit Requirements

Interaction and moderation events have direct trust consequences and require durable auditability.

---

## 25.1 Interaction Events to Audit

At minimum:

- interaction created;
- request accepted;
- request declined;
- viewing scheduled;
- viewing rescheduled;
- interaction cancelled;
- no-show recorded;
- completion recorded;
- completion disputed;
- interaction invalidated;
- review eligibility created;
- review eligibility suspended;
- review eligibility revoked.

---

## 25.2 Moderation Events to Audit

At minimum:

- report created;
- moderation case opened;
- case triaged;
- moderator assigned;
- evidence accessed;
- moderation action applied;
- action reversed;
- interaction invalidated;
- listing restricted;
- review hidden or removed;
- verification escalation;
- account restriction applied;
- account restriction removed;
- appeal opened;
- appeal resolved.

---

## 25.3 Audit Fields

Where applicable:

```text
event_id
entity_type
entity_id
interaction_id
moderation_case_id
actor_id
actor_role
action
previous_state
new_state
reason_code
timestamp
request_id
metadata
```

Audit logs must avoid unnecessarily duplicating sensitive evidence.

---

## 25.4 Audit Integrity

Users, providers, and moderators must not be able to rewrite historical audit events.

Corrections must be represented by new events.

---

# 26. Authorization Rules

## 26.1 Seekers

May:

- create eligible requests;
- cancel own eligible interactions;
- dispute trust-impacting outcomes involving them;
- report policy violations.

May not:

- mark arbitrary interactions completed;
- edit provider records;
- perform moderation.

---

## 26.2 Providers

May:

- respond to interactions for resources they control;
- schedule/reschedule supported viewings;
- cancel according to policy;
- record completion where permitted;
- report seeker misconduct.

May not:

- manipulate interaction history after terminal outcomes;
- revoke reviews directly;
- perform moderation.

---

## 26.3 Organization Members

Interaction permissions depend on:

- active organization membership;
- role;
- resource scope;
- listing/property assignment.

An organization member must not manage interactions belonging to unrelated organizations.

---

## 26.4 Moderators

May perform only moderation actions granted to their role.

Moderator access does not automatically include unrestricted sensitive verification evidence.

---

## 26.5 Platform Administrators

May perform exceptional actions defined by platform policy.

Privileged overrides must be auditable.

---

# 27. API Design Guidance

Interaction actions should be explicit domain operations.

Examples:

```text
requestViewing()
acceptViewing()
scheduleViewing()
rescheduleViewing()
cancelInteraction()
recordNoShow()
completeInteraction()
disputeInteractionOutcome()
```

Moderation operations should similarly be explicit:

```text
createReport()
openModerationCase()
triageCase()
assignModerator()
applyModerationAction()
invalidateInteraction()
resolveDispute()
appealDecision()
```

Avoid unrestricted state mutation.

---

# 28. Concurrency and Idempotency

The system must protect against competing interaction transitions.

Examples:

- seeker cancels while provider accepts;
- provider marks completed while seeker disputes;
- moderator invalidates interaction while review is submitted;
- two moderators resolve the same case differently.

Use:

- transactional checks;
- versioning/optimistic concurrency;
- unique constraints;
- idempotency where clients may retry.

---

# 29. Minimum Testing Requirements

## Interaction creation

- unauthenticated user cannot create protected interaction;
- seeker can request viewing on eligible published listing;
- seeker cannot request viewing on archived listing;
- unauthorized provider cannot respond to another provider's interaction.

## Scheduling

- accepted request can be scheduled;
- invalid time rejected;
- reschedule preserves history;
- cancelled interaction cannot be rescheduled without new workflow.

## Cancellation

- seeker can cancel own eligible interaction;
- provider can cancel controlled interaction;
- unrelated user cannot cancel;
- cancellation does not create ordinary review eligibility.

## Completion

- eligible actor can record completion;
- invalid transition to `COMPLETED` rejected;
- completion creates review eligibility;
- duplicate completion does not create duplicate eligibility.

## No-show

- no-show cannot be created from unscheduled interaction;
- responsible party is recorded where known;
- no-show does not create ordinary star-review eligibility;
- disputed no-show can enter moderation workflow.

## Disputes

- participant can dispute relevant trust event;
- unrelated user cannot open participant dispute;
- resolution preserves original history;
- reversed decision generates audit event.

## Moderation

- ordinary user cannot perform moderation;
- moderator can triage assigned case;
- unauthorized moderator action rejected;
- interaction invalidation revokes unused eligibility;
- related review moves into moderation when required;
- restricted listing cannot bypass moderation state.

## Audit

- trust-impacting transitions generate events;
- moderator actions generate events;
- audit history cannot be edited by ordinary actors.

---

# 30. Open Decisions

### IM-OD-001 — Completion confirmation model

Should completion use:

- either-party confirmation with dispute window;
- two-party confirmation;
- provider confirmation;
- seeker confirmation;
- automatic completion after time?

**Current recommendation:** Either-party confirmation with a short dispute window.

---

### IM-OD-002 — Completion dispute window

How long may the other participant challenge a recorded completion?

**Current status:** Open.

---

### IM-OD-003 — No-show confirmation

What evidence is sufficient to mark a no-show as confirmed?

**Current status:** Open.

---

### IM-OD-004 — Late cancellation

Does MVP distinguish ordinary cancellations from late cancellations?

**Current recommendation:** Not unless there is a clear product need.

---

### IM-OD-005 — Interaction expiry

How long may a provider leave a viewing request unanswered before it expires?

**Current status:** Open.

---

### IM-OD-006 — Reciprocal review eligibility

Does a completed viewing create review eligibility for:

- seeker reviewing provider only;
- both seeker and provider?

**Current status:** Open.

---

### IM-OD-007 — Moderation power boundaries

Which actions may moderators perform directly versus escalate to platform administrators or verification reviewers?

**Current status:** Open.

---

### IM-OD-008 — Appeal support

Are moderation appeals included in MVP?

**Current status:** Open.

---

### IM-OD-009 — Messaging evidence

If Pachi implements messaging, under what circumstances may moderators access message content during an investigation?

**Current status:** Security/privacy decision.

---

# 31. Decisions Established by This Document

Unless changed through an approved product update, this document establishes the following baseline decisions:

1. Structured interactions are separate from ordinary messages.
2. A completed viewing is the baseline qualifying interaction for review eligibility.
3. Inquiry, contact, cancellation, decline, and expiration do not create ordinary review eligibility.
4. No-shows should be represented as structured trust events rather than ordinary star-rating eligibility.
5. Interaction completion must be explicitly established and must not be inferred only from elapsed time.
6. Interaction disputes preserve the original record and create a separate dispute workflow.
7. Moderation is case-based and auditable.
8. Invalidating an interaction may revoke related review eligibility.
9. Reviews created from invalidated interactions must be reevaluated.
10. Capability-specific restrictions are preferred over a single universal ban flag.
11. Moderation actions must preserve history rather than silently rewriting marketplace records.
12. Trust-impacting interaction and moderation changes require durable audit events.

---

# 32. Definition of Done

This document may move from **Draft for Review** to **Approved** when:

- completion confirmation behavior is decided;
- dispute-window duration is defined;
- no-show confirmation policy is defined;
- viewing-request expiry duration is defined;
- reciprocal review eligibility is decided;
- moderator authority boundaries are defined;
- appeal support is decided;
- messaging evidence access is aligned with privacy/security policy;
- review eligibility is fully aligned with `review-system.md`;
- interaction transitions are aligned with `lifecycle-states.md`;
- verification-related moderation is aligned with `verification-model.md`;
- no known conflicts remain with the product specification, domain model, roles-and-permissions model, or trust policies.
