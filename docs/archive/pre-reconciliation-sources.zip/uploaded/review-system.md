# Pachi — Review System

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document is the primary source of truth for review eligibility, review lifecycle states, rating rules, moderation actions, trust effects, and review-related audit requirements.  
> **Related Documents:**  
> - `docs/00-product/product-specification.md`
> - `docs/01-domain/domain-model.md`
> - `docs/01-domain/roles-and-permissions.md`
> - `docs/01-domain/lifecycle-states.md`
> - `docs/01-domain/verification-model.md`
> - `docs/04-business-rules/interaction-rules.md`
> - `docs/04-business-rules/review-rules.md`
> - `docs/04-business-rules/moderation-rules.md`
> - `docs/04-business-rules/fraud-prevention.md`
> - `docs/03-engineering/authorization.md`
> - `docs/03-engineering/security.md`

---

## 1. Purpose

This document defines how reviews work in Pachi.

The review system exists to create trustworthy marketplace reputation based on real platform interactions.

It must prevent or reduce:

- reviews from users who never meaningfully interacted;
- duplicate reviews for the same interaction;
- retaliatory or manipulated ratings;
- reviews targeting the wrong person or organization;
- review tampering after publication;
- moderation actions that silently rewrite trust history;
- artificial reputation inflation through fake accounts or coordinated behavior.

Reviews are a trust signal.

They are not a guarantee of future behavior, property condition, legal compliance, transaction safety, or provider quality.

---

## 2. Review Principles

### 2.1 Reviews require eligibility

A user must not be able to review another party merely because:

- they viewed a listing;
- they sent a message;
- they know the provider;
- they have the provider's profile URL.

Review eligibility must be created by a qualifying marketplace interaction.

---

### 2.2 Reviews are interaction-scoped

Every review must be traceable to a specific qualifying interaction.

Conceptually:

```text
Reviewer
   ↓
Qualifying Interaction
   ↓
Review Target
   ↓
Review
```

The review system must be able to explain why the reviewer was eligible.

---

### 2.3 Review direction must be explicit

A review must define:

- reviewer;
- review target;
- target type;
- qualifying interaction;
- role of reviewer in that interaction.

A provider review of a seeker is a different trust direction from a seeker review of a provider.

---

### 2.4 Reputation is derived

Public reputation values must be calculated from eligible review records.

They must not be stored or manually edited as an arbitrary profile number without an auditable source.

---

### 2.5 Moderation and editing are separate

A user editing their own review is different from a moderator hiding or removing a review.

Moderation must preserve the historical review record.

---

### 2.6 Review history must be durable

Trust-impacting events must remain auditable.

Examples:

- review submitted;
- review edited;
- review hidden;
- moderation decision reversed;
- rating excluded from aggregate;
- account later determined to be fraudulent.

---

### 2.7 One interaction must not create unlimited reputation

A single qualifying interaction must have bounded review eligibility.

The default model is one review per reviewer-target pair per qualifying interaction.

---

# 3. Review Subjects

Pachi initially supports reviews of the following subject types.

## 3.1 Individual Provider

A seeker may review an individual provider after a qualifying interaction.

The review concerns the provider's conduct in the marketplace interaction.

---

## 3.2 Organization

A seeker may review an organization where the interaction was conducted on behalf of that organization.

The review concerns the organization's marketplace service and conduct.

---

## 3.3 Seeker

A provider or authorized organization representative may review a seeker after a qualifying interaction if seeker reviews are enabled.

The review concerns marketplace conduct such as:

- communication;
- attendance;
- respectful behavior;
- reliability.

Seeker reviews must not be used to discriminate based on protected or irrelevant personal characteristics.

---

## 3.4 Listing or Property

Pachi should distinguish between reviewing a provider and reviewing the property itself.

A property review could concern:

- accuracy of listing representation;
- viewing experience;
- condition observed;
- location accuracy.

Whether property-specific reviews exist in MVP is an open product decision.

The system must not merge provider reputation and property reputation into one ambiguous score.

---

# 4. Review Eligibility

## 4.1 Eligibility Source

A review may be created only when a qualifying interaction produces review eligibility.

A completed interaction is the baseline qualifying event.

The interaction lifecycle is defined in `lifecycle-states.md`.

---

## 4.2 Minimum Eligibility Conditions

A review is eligible only when all applicable conditions are satisfied:

```text
authenticated_reviewer
AND qualifying_interaction_exists
AND reviewer_participated_in_interaction
AND review_target_participated_in_interaction
AND interaction_state_is_review_eligible
AND review_window_is_open
AND duplicate_review_rule_passes
AND reviewer_not_restricted
AND target_relationship_matches_review_direction
```

---

## 4.3 Interaction States and Eligibility

Baseline policy:

| Interaction State | Review Eligible? | Notes |
|---|---|---|
| `REQUESTED` | No | No completed marketplace interaction |
| `ACCEPTED` | No | Interaction not completed |
| `SCHEDULED` | No | Interaction not completed |
| `IN_PROGRESS` | No | Interaction not completed |
| `COMPLETED` | Yes | Primary qualifying state |
| `DECLINED` | No | No completed interaction |
| `CANCELLED` | No | No completed interaction |
| `EXPIRED` | No | No completed interaction |
| `NO_SHOW` | Open decision | May support a separate conduct review model |

The review system must not infer completion merely because a scheduled time passed.

---

## 4.4 Review Window

Reviews should be submitted within a defined period after eligibility begins.

The exact duration is an open policy decision.

Possible example:

```text
review_window_opens = interaction.completed_at
review_window_closes = interaction.completed_at + configured_duration
```

The review window should be configurable rather than hard-coded across the application.

---

## 4.5 Duplicate Review Rules

Default rule:

```text
one review
per reviewer
per review target
per qualifying interaction
```

The database should enforce an equivalent uniqueness constraint where practical.

A user must not create additional reviews by retrying the API or using another client.

---

## 4.6 Multiple Interactions

If the same seeker and provider complete multiple legitimate interactions, each qualifying interaction may independently create review eligibility.

However, anti-abuse rules may limit reputation manipulation from repetitive low-value interactions.

Potential controls include:

- minimum spacing;
- weighted aggregation;
- duplicate-pattern detection;
- limiting multiple reviews related to the same property within a short period.

Detailed abuse rules belong in `fraud-prevention.md`.

---

## 4.7 Self-Review

A user must never review themselves.

A user must also not indirectly review themselves through an organization relationship where the review would create a false independent reputation signal.

---

## 4.8 Organization Conflict Rules

A user should not create a consumer-style review of an organization if they are currently an active member of that organization.

Former member behavior should be governed by moderation and conflict-of-interest rules.

---

# 5. Review Lifecycle States

Pachi defines the following review states.

```text
DRAFT
SUBMITTED
PUBLISHED
UNDER_MODERATION
HIDDEN
REMOVED
WITHDRAWN
```

---

## 5.1 `DRAFT`

The reviewer has started composing a review but has not submitted it.

Typical characteristics:

- visible only to the reviewer;
- editable;
- does not affect reputation;
- may expire when eligibility closes, depending on product policy.

---

## 5.2 `SUBMITTED`

The review has been submitted and is awaiting publication processing or required checks.

This state may be brief.

Possible checks include:

- eligibility validation;
- duplicate prevention;
- automated abuse detection;
- prohibited-content checks.

No public reputation effect should occur until publication.

---

## 5.3 `PUBLISHED`

The review is publicly visible according to product visibility rules.

Typical characteristics:

- contributes to reputation unless specifically excluded;
- visible on the relevant public profile or review surface;
- may be reported;
- may be edited only according to edit policy.

---

## 5.4 `UNDER_MODERATION`

The review is being evaluated because of:

- a report;
- automated trust signal;
- staff-initiated review;
- account fraud investigation.

Depending on moderation policy, the review may remain visible or be temporarily hidden while under review.

Visibility during `UNDER_MODERATION` must be explicit in moderation rules.

---

## 5.5 `HIDDEN`

The review remains stored but is not publicly visible.

Typical reasons:

- temporary moderation action;
- unresolved dispute;
- suspected manipulation;
- safety or legal concern.

A hidden review should normally be excluded from public reputation aggregates.

---

## 5.6 `REMOVED`

The review has been removed from public use following a moderation decision.

Typical characteristics:

- not publicly visible;
- excluded from reputation aggregates;
- original record retained for audit and appeal;
- removal reason recorded.

`REMOVED` is normally terminal for public reputation purposes.

---

## 5.7 `WITHDRAWN`

The reviewer voluntarily withdrew their own published or submitted review where product policy allows.

Typical characteristics:

- review no longer appears publicly;
- review no longer contributes to public reputation;
- audit history remains.

The system should not physically delete the historical review record merely because the reviewer withdraws it.

---

# 6. Review State Diagram

```text
              ┌─────────┐
              │  DRAFT  │
              └────┬────┘
                   │ submit
                   ▼
             ┌───────────┐
             │ SUBMITTED │
             └─────┬─────┘
                   │ validation
                   ▼
             ┌───────────┐
             │ PUBLISHED │
             └─────┬─────┘
                   │
          ┌────────┼───────────────┐
          │        │               │
        report   withdraw       moderation
          │        │               │
          ▼        ▼               ▼
UNDER_MODERATION WITHDRAWN   UNDER_MODERATION
          │
      ┌───┴───────────┐
      │               │
    clear           restrict
      │               │
      ▼               ├──────────▶ HIDDEN
  PUBLISHED            │
                      └──────────▶ REMOVED
```

---

# 7. Allowed Review Transitions

| From | To | Trigger | Minimum Conditions |
|---|---|---|---|
| `DRAFT` | `SUBMITTED` | Reviewer submits | Eligibility valid; content valid |
| `DRAFT` | `WITHDRAWN` | Reviewer abandons | Reviewer authorized |
| `SUBMITTED` | `PUBLISHED` | Validation succeeds | Eligibility and content checks pass |
| `SUBMITTED` | `UNDER_MODERATION` | Trust/content check triggers | Moderation workflow created |
| `SUBMITTED` | `WITHDRAWN` | Reviewer withdraws | Policy permits |
| `PUBLISHED` | `UNDER_MODERATION` | Report or moderation trigger | Valid moderation workflow |
| `PUBLISHED` | `WITHDRAWN` | Reviewer withdraws | Policy permits |
| `UNDER_MODERATION` | `PUBLISHED` | Review cleared | Moderator authorized |
| `UNDER_MODERATION` | `HIDDEN` | Temporary restriction | Moderator authorized |
| `UNDER_MODERATION` | `REMOVED` | Removal decision | Moderator authorized; reason recorded |
| `HIDDEN` | `PUBLISHED` | Restriction reversed | Moderator authorized |
| `HIDDEN` | `REMOVED` | Removal confirmed | Moderator authorized |

---

# 8. Rating Model

## 8.1 Rating Scale

Recommended baseline:

```text
1 to 5 stars
```

Where:

```text
1 = Very poor
2 = Poor
3 = Fair
4 = Good
5 = Excellent
```

The exact user-facing wording may vary by review subject.

---

## 8.2 Integer Ratings

MVP ratings should use whole numbers only.

Allowed:

```text
1
2
3
4
5
```

Not allowed in review submission:

```text
3.7
4.5
```

Aggregate averages may be decimal values.

---

## 8.3 Rating Requiredness

A published review should require a rating where the target type supports ratings.

Whether written text is mandatory is an open product decision.

Recommended baseline:

- rating required;
- written review optional but encouraged.

---

## 8.4 Subject-Specific Dimensions

Pachi may later support structured category ratings.

Examples for providers:

- communication;
- professionalism;
- accuracy;
- reliability.

Examples for seekers:

- communication;
- reliability;
- attendance;
- conduct.

Examples for property/listing experience:

- listing accuracy;
- property condition;
- location accuracy.

MVP should avoid excessive rating dimensions unless they provide clear product value.

A single overall rating is simpler and less prone to sparse data.

---

# 9. Reputation Aggregation

## 9.1 Eligible Reviews Only

Only reviews that are:

```text
state == PUBLISHED
AND reputation_eligible == true
```

should contribute to public aggregate ratings.

---

## 9.2 Basic Aggregate

A simple baseline aggregate is:

```text
average_rating =
    sum(eligible_review_ratings)
    / count(eligible_reviews)
```

Public surfaces should display both:

- average rating;
- review count.

Example:

```text
4.7 · 38 reviews
```

A rating without review count is potentially misleading.

---

## 9.3 No Rating Before Sufficient Data

Pachi may choose to display no aggregate score until a minimum review count is reached.

This is an open product decision.

If a minimum is used, the threshold should be consistent and documented.

---

## 9.4 Hidden and Removed Reviews

`HIDDEN`, `REMOVED`, and `WITHDRAWN` reviews must not contribute to the public aggregate.

If such a review previously contributed, the aggregate must be recalculated.

---

## 9.5 Historical Aggregate Integrity

The system should be capable of explaining changes in reputation caused by:

- new reviews;
- withdrawn reviews;
- moderation removals;
- fraud exclusions;
- restored reviews.

---

# 10. Review Content Rules

Reviews must relate to the qualifying marketplace interaction.

Content may be restricted when it contains:

- threats;
- harassment;
- hate or abusive content;
- personal information;
- unrelated accusations;
- spam;
- advertising;
- impersonation;
- prohibited illegal content;
- demonstrably irrelevant content;
- manipulated or coordinated review content.

Detailed content policy belongs in `moderation-rules.md`.

---

# 11. Review Editing

## 11.1 Reviewer Editing

Pachi may allow the reviewer to edit their own published review.

Recommended baseline:

- rating may be edited within the review window;
- written content may be edited within the review window;
- edit history must be preserved;
- editing must not reset eligibility.

---

## 11.2 Edit History

For every edit, retain:

```text
review_id
revision_number
previous_rating
new_rating
previous_text
new_text
edited_at
edited_by
```

Sensitive storage details may vary, but the system must preserve enough history for moderation and disputes.

---

## 11.3 Moderators Must Not Rewrite User Reviews

Moderators should not silently rewrite review text to make it compliant.

Preferred actions:

- leave published;
- hide;
- remove;
- request user correction where product design supports it.

This preserves authorship integrity.

---

# 12. Reviewer and Target Visibility

A review should identify the reviewer to the target and public audience according to privacy policy.

The review system should avoid anonymous public reviews unless there is a strong product and abuse-control rationale.

Possible public identity display:

- first name;
- profile name;
- account badge;
- completed-interaction indicator.

The system must not expose private contact information.

---

# 13. Reciprocal Review Behavior

Pachi must consider retaliation risk when two parties may review one another.

Possible models include:

### Immediate publication

Each review becomes visible as soon as submitted.

Simple, but may encourage retaliatory reviews.

### Double-blind publication

A review remains hidden until:

- both parties submit; or
- the review window closes.

This reduces retaliation and strategic rating behavior.

### Hybrid model

Rating may be locked before the other party's review becomes visible.

**Recommended baseline:** Use a double-blind or delayed-reveal model where both sides can review each other.

This should be approved before implementation.

---

# 14. Review Eligibility Token or Record

Review eligibility should be represented explicitly rather than recalculated only from client input.

Conceptually:

```text
ReviewEligibility
- id
- interaction_id
- reviewer_id
- target_type
- target_id
- opens_at
- closes_at
- consumed_at
- status
```

Possible statuses:

```text
OPEN
CONSUMED
EXPIRED
REVOKED
```

This model reduces duplicate reviews and improves auditability.

---

# 15. Eligibility Revocation

Review eligibility may be revoked before submission when:

- interaction completion was reversed as erroneous;
- interaction was determined fraudulent;
- account was confirmed to be part of review manipulation;
- underlying interaction was invalidated;
- moderation policy requires revocation.

Revocation must be auditable.

---

# 16. Trust-Related Review Controls

Review data may affect trust and marketplace visibility.

Pachi should distinguish between:

- raw review history;
- public review state;
- aggregate reputation;
- internal trust signals.

Internal trust signals must not automatically become public accusations.

---

## 16.1 Potential Internal Trust Signals

Examples:

- high cancellation rate;
- repeated no-shows;
- unusually high review velocity;
- reciprocal review rings;
- repeated five-star reviews from newly created accounts;
- repeated reviews tied to suspicious interactions;
- repeated moderation removals;
- unusual account linkage.

These belong primarily in `fraud-prevention.md`.

---

# 17. Moderation Actions

Moderators may take the following review-related actions where policy permits.

## 17.1 Clear Review

Return a review from `UNDER_MODERATION` to `PUBLISHED`.

Requires:

- moderator authorization;
- decision record.

---

## 17.2 Hide Review

Move a review to `HIDDEN`.

Used when:

- investigation is ongoing;
- temporary restriction is appropriate;
- public visibility creates immediate risk.

The reason must be recorded.

---

## 17.3 Remove Review

Move a review to `REMOVED`.

Possible reasons:

- fabricated interaction;
- harassment;
- prohibited content;
- spam;
- review manipulation;
- conflict of interest;
- impersonation;
- fraud;
- privacy violation;
- duplicate review;
- legal requirement.

Removal must record a reason code and actor.

---

## 17.4 Restore Review

A previously hidden review may be restored to `PUBLISHED`.

A removed review should only be restored through a formal reversal or appeal workflow.

Restoration must be auditable.

---

## 17.5 Exclude From Reputation

In exceptional cases, a review may remain visible but be excluded from aggregate reputation.

This should be rare.

The preferred model is generally to align visibility and reputation eligibility unless a clear policy reason exists.

---

# 18. Appeals and Disputes

The review target may report or dispute a review.

A dispute must not automatically remove the review.

Possible flow:

```text
PUBLISHED
   ↓ report/dispute
UNDER_MODERATION
   ↓
PUBLISHED / HIDDEN / REMOVED
```

A moderation decision may itself be appealable according to platform policy.

Original moderation history must remain preserved.

---

# 19. Review Fraud Controls

The system should monitor for review manipulation.

Examples:

- multiple accounts tied to the same actor;
- repeated reviews without meaningful interaction;
- synthetic interaction completion;
- coordinated account clusters;
- provider reviewing own organization;
- organization members reviewing their own organization;
- suspicious device/IP overlap where legally and operationally appropriate;
- repeated identical or near-identical review content;
- unusual review bursts.

Detection should generate internal risk signals, not automatic public accusations.

---

# 20. Account and Review Relationship

## 20.1 Account Suspension

When an account is suspended, existing reviews should not automatically be deleted.

Their treatment depends on the suspension reason.

Examples:

- unrelated account-security suspension: reviews may remain;
- confirmed fraudulent review network: reviews may be hidden or removed;
- identity impersonation: associated reviews may require reevaluation.

---

## 20.2 Account Deletion

Deleting or closing an account should not automatically destroy review integrity.

Possible approach:

- remove public reviewer profile link;
- retain review content according to policy;
- display anonymized reviewer label where appropriate;
- preserve internal audit linkage.

Privacy and retention requirements must be aligned with legal policy.

---

# 21. Audit Requirements

Review operations affect public reputation and require durable audit history.

## 21.1 Events That Must Be Audited

At minimum:

- review eligibility created;
- review eligibility expired;
- review eligibility revoked;
- review draft created where persisted;
- review submitted;
- review published;
- review edited;
- review withdrawn;
- review reported;
- moderation started;
- review hidden;
- review restored;
- review removed;
- removal reversed;
- review excluded from reputation;
- review restored to reputation;
- reviewer or target account later flagged for review manipulation.

---

## 21.2 Audit Record Fields

A review audit event should contain where applicable:

```text
event_id
review_id
interaction_id
review_eligibility_id
reviewer_id
target_type
target_id
actor_id
actor_role
action
previous_state
new_state
previous_rating
new_rating
reason_code
timestamp
request_id
metadata
```

Do not unnecessarily copy full review text into every audit record.

---

## 21.3 Audit Immutability

Ordinary users and moderators must not be able to rewrite historical audit events.

Corrections must be represented by new events.

---

## 21.4 Aggregate Reputation Audit

Changes to a public aggregate should be traceable to source review changes.

The system should be able to explain:

```text
Why did this profile's average rating change?
```

through review and moderation history.

---

# 22. Authorization Requirements

Review actions require server-side authorization.

Examples:

### Create review

Requires:

- authenticated reviewer;
- valid open eligibility;
- reviewer owns eligibility;
- target matches eligibility;
- duplicate constraint passes.

### Edit review

Requires:

- reviewer owns review;
- review state allows editing;
- edit window permits change.

### Moderate review

Requires:

- moderator or administrator permission;
- valid moderation action;
- reason where required.

---

# 23. API Design Guidance

Review actions should be represented as explicit domain operations.

Examples:

```text
createReviewDraft()
submitReview()
editReview()
withdrawReview()
reportReview()
startReviewModeration()
hideReview()
removeReview()
restoreReview()
```

Avoid unrestricted status mutation such as:

```text
PATCH /reviews/{id}
{
  "status": "REMOVED"
}
```

without domain-specific authorization and transition validation.

---

# 24. Concurrency and Idempotency

The system must protect review integrity during retries and concurrent actions.

Examples:

- mobile client submits the same review twice;
- reviewer edits while moderator hides the review;
- two moderators make conflicting decisions;
- review submission and eligibility expiry occur simultaneously.

Controls should include:

- unique review constraints;
- transactions;
- optimistic concurrency where appropriate;
- idempotency for submit operations.

---

# 25. Minimum Testing Requirements

Automated tests should cover at least the following.

## Eligibility

- unrelated user cannot review;
- requested interaction does not create eligibility;
- scheduled interaction does not create eligibility;
- completed qualifying interaction creates eligibility;
- expired eligibility cannot be used;
- revoked eligibility cannot be used;
- eligibility cannot be consumed twice.

## Review creation

- valid reviewer can submit one review;
- reviewer cannot target different user than eligibility permits;
- user cannot review self;
- organization member cannot create prohibited self-interested organization review;
- duplicate API retries do not create duplicate reviews.

## Ratings

- rating below 1 rejected;
- rating above 5 rejected;
- non-integer rating rejected if MVP uses integer ratings;
- published eligible review affects aggregate;
- hidden review does not affect aggregate;
- removed review does not affect aggregate;
- restored review recalculates aggregate correctly.

## Editing

- reviewer can edit only own review;
- unauthorized user cannot edit review;
- revision history is preserved;
- edit outside allowed window is rejected.

## Moderation

- ordinary user cannot hide or remove review;
- moderator can start review moderation;
- moderator action records reason;
- removal excludes review from aggregate;
- restoration recreates expected aggregate state;
- moderation history remains auditable.

## Trust

- confirmed duplicate/fraudulent review can be excluded;
- removing one review changes aggregate deterministically;
- account deletion does not corrupt historical review references.

---

# 26. Open Decisions

### RS-OD-001 — Review window duration

How long after a qualifying interaction may a review be submitted?

**Current status:** Open.

---

### RS-OD-002 — Written review requirement

Should a rating be publishable without written text?

**Current recommendation:** Yes. Require rating; make written text optional.

---

### RS-OD-003 — Reciprocal review reveal model

Should provider/seeker reviews use:

- immediate publication;
- double-blind publication;
- delayed publication until the review window closes?

**Current recommendation:** Double-blind or delayed reveal where reciprocal reviews are enabled.

---

### RS-OD-004 — Seeker reviews

Can providers review seekers in MVP?

**Current status:** Open.

---

### RS-OD-005 — Property-specific reviews

Does MVP include reviews of the property/listing experience separately from provider reviews?

**Current status:** Open.

---

### RS-OD-006 — No-show reviews

Does `NO_SHOW` create:

- no review eligibility;
- conduct-only review eligibility;
- a separate no-show trust event instead of a review?

**Current recommendation:** Use a structured no-show trust event rather than normal star-rating eligibility.

---

### RS-OD-007 — Review editing window

For how long may a reviewer change rating or text after submission?

**Current status:** Open.

---

### RS-OD-008 — Minimum review count for public average

Should aggregate ratings be hidden until a target has a minimum number of reviews?

**Current status:** Open.

---

### RS-OD-009 — Withdrawal policy

May reviewers withdraw a published review at any time, or only within a defined period?

**Current status:** Open.

---

### RS-OD-010 — Moderation visibility

Should `UNDER_MODERATION` reviews remain public until a moderator hides them, or become temporarily hidden automatically?

**Current status:** Open.

---

# 27. Decisions Established by This Document

Unless changed through an approved product update, this document establishes the following baseline decisions:

1. Reviews require a qualifying marketplace interaction.
2. `COMPLETED` is the baseline interaction state that creates review eligibility.
3. Review eligibility is scoped to a specific reviewer, target, and interaction.
4. One qualifying interaction does not create unlimited reviews.
5. Self-reviews are prohibited.
6. Organization members must not create ordinary consumer reviews of their own organization.
7. Pachi uses a 1–5 whole-star baseline rating scale.
8. Public reputation is derived only from eligible published reviews.
9. Hidden, removed, and withdrawn reviews do not contribute to public aggregate ratings.
10. Moderators do not silently rewrite user review content.
11. Trust-impacting review actions require durable audit history.
12. Reputation changes must be traceable back to source reviews and moderation actions.

---

# 28. Definition of Done

This document may move from **Draft for Review** to **Approved** when:

- review window duration is decided;
- reciprocal review reveal behavior is decided;
- seeker-review support is decided;
- property-review support is decided;
- no-show handling is decided;
- review edit and withdrawal windows are decided;
- minimum public review-count behavior is decided;
- moderation visibility behavior is decided;
- review eligibility is aligned with `interaction-rules.md`;
- moderation actions are aligned with `moderation-rules.md`;
- no known conflicts remain with the product specification, domain model, roles-and-permissions model, or lifecycle states.
