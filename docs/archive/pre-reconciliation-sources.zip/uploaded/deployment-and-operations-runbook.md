# Pachi — Deployment and Operations Runbook

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document defines the operational procedures for deploying, monitoring, restoring, and responding to incidents in Pachi environments. Architecture decisions remain authoritative in their ADRs.  
> **Related Documents:**  
> - `docs/02-architecture/system-architecture.md`
> - `docs/02-architecture/adr/0001-technology-stack.md`
> - `docs/02-architecture/adr/0002-authentication-and-session-strategy.md`
> - `docs/02-architecture/adr/0003-aws-region-and-environment-topology.md`
> - `docs/02-architecture/adr/0005-media-processing-and-storage-policy.md`
> - `docs/02-architecture/adr/0006-notification-email-sms-strategy.md`
> - `docs/01-domain/lifecycle-states.md`
> - `docs/01-domain/verification-model.md`
> - `docs/01-domain/review-system.md`

---

## 1. Purpose

This runbook defines how Pachi is operated safely across:

- local development;
- staging;
- production.

It covers:

- environment boundaries;
- continuous integration;
- continuous deployment;
- database migrations;
- secrets;
- backups;
- restore procedures;
- monitoring;
- alerting;
- incident response;
- rollback;
- post-incident review.

The goal is to make production operations repeatable and auditable rather than dependent on memory or ad hoc console actions.

---

# 2. Operating Principles

Pachi operations follow these principles:

1. **Production changes are deliberate.**
2. **Staging should rehearse production behavior.**
3. **Infrastructure is defined in code.**
4. **Database changes are treated as high-risk operations.**
5. **Secrets never live in source control.**
6. **Backups are not trusted until restored successfully.**
7. **Monitoring must detect user-impacting failures.**
8. **Rollback paths are prepared before deployment.**
9. **Incidents preserve evidence and audit history.**
10. **Emergency changes are reconciled back into code and documentation.**

---

# 3. Environment Model

Pachi initially uses:

```text
local
staging
production
```

---

## 3.1 Local

Primary development environment:

```text
Windows
+ WSL2 Ubuntu
+ Docker Desktop
+ VS Code
```

Expected local services:

```text
PostgreSQL + PostGIS
NestJS API
Next.js web
Expo mobile development app
```

Cloud integrations should use:

- development resources;
- mocks;
- sandbox environments;
- console adapters;

where production access is unnecessary.

Local development must not require production credentials.

---

## 3.2 Staging

Staging is the primary pre-production integration environment.

It should use the same major service families as production:

- ECS Fargate;
- RDS PostgreSQL/PostGIS;
- S3;
- SQS;
- Cognito;
- Secrets Manager;
- CloudWatch.

Staging may use:

- smaller task sizes;
- fewer ECS tasks;
- Single-AZ RDS;
- lower retention;
- reduced NAT redundancy.

Staging must not contain uncontrolled copies of production personal or verification data.

---

## 3.3 Production

Production hosts live Pachi users and marketplace data.

Production requires:

- separate AWS account;
- separate credentials;
- Multi-AZ database before public launch;
- protected backups;
- stricter IAM;
- controlled deployment;
- monitoring and alerting;
- auditability;
- documented recovery procedures.

---

# 4. Environment Isolation Rules

Staging and production must not share:

```text
RDS databases
Cognito user pools
S3 buckets
SQS queues
KMS keys
application secrets
OAuth client secrets
SMS credentials
production email configuration
```

Cross-environment access must be exceptional and documented.

---

# 5. Source Control and Branching

The Git repository is the source of truth for:

- application code;
- infrastructure code;
- migrations;
- documentation;
- deployment configuration.

Recommended branch model:

```text
main
feature/*
fix/*
docs/*
```

`main` represents releasable code.

Production deployment should only use code reachable from an approved commit on `main` or an explicitly approved release tag.

---

# 6. Pull Request Requirements

Before merge, a pull request should pass:

```text
format check
lint
type check
unit tests
integration tests where applicable
build validation
migration validation
security/dependency checks where configured
```

High-risk changes should also include:

- deployment notes;
- rollback notes;
- database migration notes;
- infrastructure impact.

---

# 7. CI Platform

Pachi uses:

```text
GitHub Actions
```

CI must not use permanent AWS access keys.

AWS access from GitHub uses:

```text
OpenID Connect
+ short-lived IAM role assumption
```

---

# 8. Deployment Roles

Use separate deployment roles for:

```text
staging
production
```

Production role permissions should be narrowly scoped.

The GitHub OIDC trust policy should restrict:

- repository;
- branch or environment;
- workflow context;

as tightly as practical.

---

# 9. Staging Deployment Flow

Recommended staging flow:

```text
merge to main
    ↓
GitHub Actions
    ↓
CI checks
    ↓
build application image
    ↓
push image to ECR
    ↓
run migration validation
    ↓
deploy staging
    ↓
run health checks
    ↓
run smoke tests
```

Staging may deploy automatically after successful CI.

---

# 10. Production Deployment Flow

Production should require explicit approval.

Recommended flow:

```text
approved main commit
    ↓
GitHub Actions
    ↓
full CI
    ↓
build immutable image
    ↓
push image to ECR
    ↓
production deployment approval
    ↓
migration gate
    ↓
approved migration task
    ↓
deploy ECS service
    ↓
ALB health checks
    ↓
smoke tests
    ↓
monitor deployment
```

Production deployment should never rebuild the application from a different source after approval.

The deployed image must be traceable to a Git commit SHA.

---

# 11. Deployment Preconditions

Before production deployment, verify:

- CI is green;
- staging is healthy;
- migration plan reviewed;
- rollback path understood;
- no unresolved critical incident;
- backup status healthy;
- monitoring dashboards available;
- required secrets exist;
- third-party provider changes are complete;
- relevant feature flags/configuration are ready.

---

# 12. Deployment Windows

Routine deployments should occur when:

- an operator can monitor the result;
- rollback can be performed immediately;
- dependent providers are operational;
- no conflicting infrastructure maintenance is underway.

Avoid unnecessary high-risk deployments immediately before periods with no operational coverage.

---

# 13. Immutable Releases

Production application artifacts should be immutable.

Recommended image naming:

```text
pachi-api:<git-sha>
pachi-worker:<git-sha>
```

Release metadata should record:

```text
git_sha
build_time
image_digest
deployment_time
environment
```

---

# 14. ECS Deployment Strategy

Initial production strategy:

```text
ECS rolling deployment
```

Before public launch, production API should normally maintain at least:

```text
2 running tasks
```

across multiple Availability Zones.

Deployment configuration should preserve sufficient healthy capacity during rollout.

---

# 15. Health Checks

The API must expose at least:

```text
/liveness
/readiness
```

Conceptual behavior:

### Liveness

Confirms the process is running.

Should not depend on every external provider.

### Readiness

Confirms the task is ready to receive traffic.

May verify critical dependencies such as:

- database connectivity;
- required configuration.

Do not make readiness dependent on optional providers such as push notification service availability.

---

# 16. Post-Deployment Smoke Tests

After staging or production deployment, validate at least:

- homepage/web loads;
- API health;
- authenticated request;
- database read;
- basic listing query;
- critical static/media delivery;
- queue worker health if changed.

For auth-related releases, additionally verify:

- login;
- token/session flow;
- logout.

For media releases, verify:

- upload authorization;
- processing;
- public delivery.

---

# 17. Database Migration Policy

Database migrations are version-controlled application artifacts.

Production schema changes must not be performed manually through an SQL console except for an approved emergency.

---

## 17.1 Migration Principles

Prefer:

```text
expand
migrate
contract
```

over destructive one-step changes.

---

## 17.2 Expand/Contract Example

Instead of:

```text
rename column immediately
```

prefer:

```text
1. add new column
2. deploy app that supports old + new
3. backfill
4. switch reads/writes
5. verify
6. remove old column in later release
```

---

## 17.3 Migration Classification

Classify migrations as:

```text
LOW
MEDIUM
HIGH
```

### Low Risk

Examples:

- additive nullable column;
- non-blocking index using approved strategy;
- new table.

### Medium Risk

Examples:

- data backfill;
- uniqueness constraint;
- larger index;
- column type transition.

### High Risk

Examples:

- destructive column/table removal;
- large blocking rewrite;
- major data transformation;
- irreversible migration;
- migration touching critical auth/trust data.

---

# 18. High-Risk Migration Checklist

Before a high-risk migration:

- test against staging;
- estimate runtime;
- review lock behavior;
- verify free storage;
- create explicit recovery point where appropriate;
- confirm PITR healthy;
- prepare rollback/forward-fix plan;
- ensure operator monitoring;
- avoid combining unrelated schema changes.

---

# 19. Migration Execution

Migrations should run through an approved one-off task or controlled CI/CD job.

Do not let every application container race to run production migrations on startup.

Preferred model:

```text
deploy pipeline
   ↓
single migration task
   ↓
migration succeeds
   ↓
application rollout continues
```

---

# 20. Migration Failure

If migration fails:

1. stop application rollout if compatibility is uncertain;
2. preserve logs;
3. determine whether migration partially committed;
4. do not blindly rerun destructive SQL;
5. restore or forward-fix depending on failure;
6. use PITR only when necessary.

---

# 21. Secrets Management

Production secrets live in:

```text
AWS Secrets Manager
```

or:

```text
AWS Systems Manager Parameter Store
```

where appropriate.

Examples:

- database credentials;
- Cognito/social-provider secrets;
- SMS credentials;
- API keys;
- signing keys;
- third-party service credentials.

---

# 22. Secrets Rules

Never store secrets in:

```text
Git
committed .env files
Docker images
frontend bundles
mobile bundles
logs
documentation examples containing real values
```

---

# 23. Local Secrets

Local development may use:

```text
.env.local
.env
```

only when:

- ignored by Git;
- populated with development credentials;
- not copied from production unnecessarily.

---

# 24. Secret Rotation

Secrets should be rotated when:

- compromised;
- exposed;
- staff/access model changes;
- provider requires rotation;
- scheduled security policy requires it.

Rotation should avoid unnecessary downtime.

Where possible:

```text
create new credential
deploy support
switch usage
revoke old credential
```

---

# 25. Production Access

Production console/CLI access requires:

- named individual identity;
- MFA;
- least privilege;
- short-lived credentials where possible.

Shared administrator credentials are prohibited.

Root-account credentials are for exceptional account-level recovery only.

---

# 26. Backups

Backups protect against:

- accidental deletion;
- bad migration;
- corruption;
- infrastructure failure;
- regional outage;
- account compromise.

---

# 27. RDS Backup Policy

Production RDS:

```text
automated backups: enabled
retention: 35 days
point-in-time recovery: enabled
cross-region backup: enabled/planned
cross-account protected copy: enabled/planned
```

Production launch should not occur without a verified database backup configuration.

---

# 28. Long-Term Database Recovery Points

Proposed baseline:

```text
daily recovery points: 35 days
monthly recovery points: 12 months
```

Actual retention must remain aligned with:

- privacy policy;
- legal obligations;
- cost;
- business continuity requirements.

---

# 29. S3 Backup and Versioning

Critical media buckets should use:

- versioning;
- encryption;
- lifecycle policies;
- protected recovery copies where required.

Private verification evidence receives stronger recovery controls than disposable processing artifacts.

---

# 30. Backup Account Boundary

Critical production backup copies should exist outside the production account.

The production application must not have authority to delete backup-account recovery points.

---

# 31. Backup Immutability

Where operationally appropriate, use:

```text
AWS Backup Vault Lock
```

or equivalent controls.

Immutability configuration must be reviewed carefully because incorrect retention policies can become expensive or operationally difficult to reverse.

---

# 32. Restore Testing

Backups must be restored periodically.

Minimum initial cadence:

```text
quarterly
```

A restore test should verify:

- recovery point exists;
- restore completes;
- application can connect;
- schema is valid;
- key tables are readable;
- PostGIS functionality works;
- runbook instructions are accurate.

---

# 33. Database Restore Procedure

For a controlled restore:

1. identify required recovery point/time;
2. stop writes if restoring production state;
3. create new RDS instance from snapshot/PITR;
4. validate engine/extensions;
5. validate schema;
6. run data sanity checks;
7. update application secret/endpoint if switching;
8. restart or redeploy application;
9. run smoke tests;
10. preserve old instance until confidence is established;
11. document incident/recovery.

Do not overwrite the failing database immediately if a parallel restore is possible.

---

# 34. Point-in-Time Recovery

Use PITR for incidents such as:

- accidental bulk deletion;
- destructive application bug;
- bad migration.

Before restoring, determine:

```text
last known good time
```

using:

- audit events;
- deployment timestamps;
- database logs;
- application logs.

---

# 35. Disaster Recovery

Primary region:

```text
eu-west-1
```

Backup/DR region:

```text
eu-west-3
```

The regional strategy remains subject to final ADR acceptance.

---

## 35.1 Regional DR Procedure

If the primary region is unavailable for a prolonged period:

```text
1. declare regional incident
2. stop conflicting recovery activity
3. identify latest usable cross-region recovery point
4. restore RDS in DR region
5. deploy CDK stack in DR region
6. restore/attach required private media
7. configure secrets
8. verify Cognito/authentication dependencies
9. deploy API/workers
10. run smoke tests
11. switch DNS
12. monitor closely
```

---

## 35.2 Regional Recovery Target

Initial target:

```text
RTO: under 8 hours
RPO: latest available replicated recovery point
```

These are engineering targets, not contractual guarantees.

Revise after restore exercises.

---

# 36. Monitoring Stack

Pachi uses:

```text
OpenTelemetry
CloudWatch
AWS X-Ray / ADOT
Sentry
structured JSON logs
```

---

# 37. Core Runtime Monitoring

Monitor:

```text
ALB healthy targets
API request rate
API error rate
API latency
ECS desired/running tasks
ECS CPU
ECS memory
RDS CPU
RDS storage
RDS connections
RDS failover
SQS queue depth
SQS oldest message
DLQ depth
worker errors
```

---

# 38. Provider Monitoring

Track health for:

```text
Cognito
Google Maps
SES
SMS provider
Expo Push
S3/CloudFront
```

Provider degradation should not be confused with Pachi database failure.

---

# 39. Media Monitoring

Track:

```text
upload failures
processing backlog
processing latency
malware scan failures
moderation scan failures
DLQ depth
CloudFront origin errors
storage growth
```

---

# 40. Notification Monitoring

Track:

```text
email sends
email delivery failures
bounces
complaints
SMS accepted/delivered/failed
SMS spend
OTP latency
push receipts
invalid push tokens
queue backlog
```

---

# 41. Backup Monitoring

Alert on:

- failed automated backup;
- failed cross-region copy;
- failed cross-account copy;
- backup vault error;
- restore-test failure.

Backup alerts are production-critical.

---

# 42. Logging

Backend logs should be structured JSON.

Recommended fields:

```text
timestamp
level
environment
service
request_id
trace_id
route
method
status_code
duration_ms
error_code
actor_id where appropriate
organization_id where appropriate
```

---

# 43. Sensitive Logging Rules

Never log:

- password;
- OTP;
- access token;
- refresh token;
- authorization code;
- full verification document;
- secret key;
- full private property directions without operational need.

---

# 44. Log Retention

Set explicit retention policies.

Do not leave CloudWatch logs at unlimited retention.

Retention depends on log category.

Example starting point:

```text
application logs: 30–90 days
security/audit logs: longer according to policy
debug logs: shorter
```

Final values require security/privacy approval.

---

# 45. Alerting Principles

Alerts must be:

- actionable;
- meaningful;
- severity-classified;
- routed to a monitored destination.

Avoid alerts that routinely fire without requiring action.

---

# 46. Suggested Alerts

### Critical

- production API unreachable;
- all ECS tasks unhealthy;
- production database unavailable;
- database storage near exhaustion;
- severe backup failure;
- production auth outage.

### High

- elevated 5xx rate;
- high sustained API latency;
- large SQS backlog;
- repeated worker crash;
- SMS/email failure spike;
- RDS connection saturation.

### Medium

- isolated provider degradation;
- rising media processing latency;
- non-critical queue delay;
- staging failure.

---

# 47. Incident Severity Model

Recommended severity levels:

```text
SEV-1
SEV-2
SEV-3
SEV-4
```

---

## 47.1 SEV-1 — Critical

Examples:

- production unavailable to most users;
- database unavailable;
- confirmed major security breach;
- destructive data corruption;
- authentication unavailable for most users.

Response:

- immediate incident ownership;
- stop risky deployments;
- preserve evidence;
- prioritize restoration.

---

## 47.2 SEV-2 — Major

Examples:

- major feature unavailable;
- elevated error rate affecting many users;
- media uploads broadly failing;
- viewing/interaction workflows unavailable;
- notification subsystem broadly degraded.

---

## 47.3 SEV-3 — Moderate

Examples:

- limited user segment affected;
- one provider degraded;
- workaround available;
- non-critical backlog.

---

## 47.4 SEV-4 — Minor

Examples:

- cosmetic production issue;
- low-impact operational defect;
- no significant user/business risk.

---

# 48. Incident Response Roles

At minimum, assign:

```text
Incident Lead
Operator / Investigator
Communicator
```

For a small team, one person may hold more than one role, but responsibilities should remain explicit.

---

# 49. Incident Response Workflow

```text
detect
  ↓
acknowledge
  ↓
classify severity
  ↓
assign owner
  ↓
stabilize
  ↓
diagnose
  ↓
mitigate
  ↓
recover
  ↓
verify
  ↓
close
  ↓
post-incident review
```

---

# 50. First Actions During Incident

For significant production incidents:

1. acknowledge alert;
2. determine user impact;
3. identify latest deployment/change;
4. inspect health dashboards;
5. check database;
6. check queues;
7. check provider health;
8. stop additional deployments;
9. preserve relevant logs/events.

---

# 51. Do Not During Incident

Avoid:

- multiple unrelated changes at once;
- deleting evidence;
- manually mutating production data without recording it;
- restarting everything without diagnosis;
- destroying the old database during restore;
- rotating unrelated secrets unless necessary.

---

# 52. Rollback Strategy

Rollback is preferred when:

- a new application release caused the issue;
- the previous image is compatible with the current schema;
- rollback is safer than forward-fix.

---

# 53. Application Rollback

Procedure:

```text
1. identify last known-good image digest
2. verify database compatibility
3. update ECS service/task definition
4. deploy previous image
5. wait for healthy tasks
6. run smoke tests
7. monitor error/latency metrics
8. record rollback event
```

---

# 54. Database Rollback

Database rollback is not equivalent to application rollback.

Do not automatically reverse migrations.

Use one of:

- forward fix;
- reverse migration if explicitly safe;
- point-in-time restore;
- snapshot restore.

Decision depends on:

- data loss risk;
- migration behavior;
- compatibility;
- incident severity.

---

# 55. Configuration Rollback

If an incident comes from configuration:

- restore last known-good secret/parameter/config;
- redeploy or reload if required;
- confirm dependent systems;
- audit the change.

Do not expose secret values in incident notes.

---

# 56. Infrastructure Rollback

Infrastructure is managed through CDK.

For failed infrastructure changes:

1. inspect CloudFormation/CDK deployment state;
2. avoid manual drift unless emergency;
3. rollback or deploy corrected CDK;
4. verify resource state;
5. reconcile emergency changes back into code.

---

# 57. Feature Disablement

Where practical, high-risk features should support controlled disablement.

Examples:

```text
new listing publication
media upload
SMS OTP
new verification submission
```

Feature disablement should not become a substitute for proper authorization.

---

# 58. Queue Recovery

If a worker fails:

1. stop repeated faulty processing if necessary;
2. fix worker;
3. redeploy;
4. allow SQS retry;
5. inspect DLQ;
6. replay only validated DLQ messages.

Do not bulk-replay DLQ blindly.

---

# 59. Notification Provider Incident

If email/SMS/push provider is degraded:

- keep domain transactions operational;
- queue retryable delivery;
- use alternate allowed channels where policy permits;
- do not automatically turn every push failure into SMS;
- communicate operational impact if user-facing.

---

# 60. Maps Provider Incident

If external maps/geocoding is unavailable:

- existing listing search remains operational through PostGIS;
- existing stored locations remain usable;
- new address autocomplete/geocoding may degrade;
- manual city/neighborhood/pin workflows should be preserved where possible.

---

# 61. Media Incident

If media processing is unavailable:

- keep new uploads quarantined;
- do not expose raw originals;
- prevent processing backlog from overwhelming workers;
- monitor queue depth;
- scale/recover worker;
- replay safe jobs.

---

# 62. Authentication Incident

If Cognito/social authentication is degraded:

- confirm whether existing sessions still work;
- avoid unnecessary global logout;
- communicate sign-in impact;
- do not bypass authentication manually;
- preserve session/security logs.

---

# 63. Security Incident

Examples:

- credential leak;
- unauthorized production access;
- suspicious evidence access;
- compromised user session;
- exposed storage object.

Immediate actions may include:

- revoke credential/session;
- restrict affected IAM principal;
- preserve logs;
- rotate exposed secret;
- disable vulnerable path;
- identify data/access scope;
- escalate severity.

Do not destroy forensic evidence.

---

# 64. Secret Exposure Procedure

If a secret is exposed:

```text
1. classify secret
2. disable/revoke old credential
3. create replacement
4. update Secrets Manager/config
5. redeploy affected service
6. verify
7. inspect logs for misuse
8. document incident
```

If possible, rotate before public disclosure of exact exposure details.

---

# 65. Data Corruption Incident

For suspected database corruption or bad writes:

1. stop or restrict affected writes;
2. identify start time;
3. preserve current database;
4. determine impacted tables/entities;
5. evaluate forward repair;
6. evaluate PITR;
7. restore to parallel RDS if needed;
8. compare data;
9. choose recovery path;
10. verify business invariants.

---

# 66. Operational Audit

Important operational actions should be traceable.

Examples:

- production deployment;
- production rollback;
- migration execution;
- restore;
- secret rotation;
- account/session security intervention;
- emergency production data correction.

---

# 67. Manual Production Data Changes

Manual SQL/data corrections should be exceptional.

If unavoidable:

- create incident/change record;
- review query first;
- run inside transaction where appropriate;
- use narrow predicates;
- capture affected record identifiers;
- verify result;
- document reason;
- encode permanent fix in application/migration if needed.

---

# 68. Scaling Procedures

Scale ECS tasks when metrics indicate:

- sustained CPU/memory pressure;
- request latency;
- queue backlog;
- concurrency.

Do not scale blindly without checking downstream constraints such as database connections.

---

# 69. Database Capacity

Monitor:

```text
CPU
free storage
IO
connections
replication/failover events
slow queries
```

Before increasing API task count significantly, verify connection capacity.

---

# 70. Cost Incident

Examples:

- unexpected SMS spend;
- runaway map API usage;
- S3/CloudFront growth;
- NAT cost spike.

Response:

1. identify service and source;
2. apply safe quota/rate control;
3. determine abuse versus legitimate growth;
4. preserve core functionality;
5. correct configuration;
6. add alert/guardrail.

---

# 71. Production Readiness Checklist

Before first public production launch:

- production AWS account exists;
- production VPC deployed;
- Multi-AZ RDS enabled;
- backups enabled;
- cross-account backup configured;
- restore tested;
- production Cognito configured;
- SES production access approved;
- SMS provider tested in Cameroon;
- S3 private/public separation validated;
- CloudFront configured;
- monitoring dashboards available;
- critical alerts configured;
- GitHub OIDC production role configured;
- production deploy approval configured;
- secrets stored securely;
- runbook reviewed;
- rollback tested;
- domain smoke tests passing.

---

# 72. Deployment Checklist

For each significant production release:

### Before

- CI green;
- staging healthy;
- backup status healthy;
- migration reviewed;
- rollback image known;
- operator available.

### During

- run migration if required;
- deploy immutable image;
- watch ECS/ALB;
- watch logs and error rate.

### After

- run smoke tests;
- verify key metrics;
- verify queues;
- verify providers if changed;
- record deployment result.

---

# 73. Rollback Checklist

Before rollback:

- confirm regression introduced by release;
- verify previous image compatibility;
- identify migration implications.

During rollback:

- deploy previous image;
- monitor health;
- run smoke tests.

After rollback:

- preserve failed release logs;
- create follow-up issue;
- do not re-release until root cause understood.

---

# 74. Backup Checklist

Daily/automated verification should confirm:

- latest RDS backup exists;
- cross-region copy healthy;
- backup-account copy healthy;
- no backup job failure;
- retention policy active.

Quarterly:

- restore database;
- verify application access;
- verify PostGIS;
- document result.

---

# 75. Incident Checklist

For SEV-1/SEV-2:

- declare incident;
- assign owner;
- freeze deployments;
- assess user impact;
- inspect latest changes;
- stabilize;
- communicate status where needed;
- recover;
- validate;
- close;
- schedule post-incident review.

---

# 76. Post-Incident Review

A post-incident review should record:

```text
incident summary
start time
detection time
resolution time
user impact
root cause
contributing factors
what worked
what failed
corrective actions
owners
due dates
```

Focus on system/process improvement.

Do not reduce the review to assigning blame.

---

# 77. Corrective Actions

Actions should be concrete.

Examples:

```text
add alert
add integration test
tighten IAM
improve migration gate
change retry policy
add rate limit
improve dashboard
update runbook
```

Each action should have:

- owner;
- priority;
- status.

---

# 78. Runbook Maintenance

Update this document when:

- deployment flow changes;
- new environment added;
- backup strategy changes;
- provider changes;
- incident reveals missing procedure;
- architecture ADR changes operational behavior.

Operational documentation should change with the system, not months afterward.

---

# 79. Known Open Operations Decisions

The following remain dependent on proposed ADRs or future policy:

- final primary AWS region;
- production NAT topology;
- exact privileged-session duration;
- exact verification-evidence retention;
- malware scanning provider;
- final Cameroon SMS provider;
- exact alert-routing destination;
- exact log-retention periods;
- final DR RTO/RPO;
- production maintenance/deployment window policy.

These do not prevent local/staging implementation from beginning.

---

# 80. Definition of Done

This runbook may move from **Draft for Review** to **Approved** when:

- deployment pipeline exists in staging;
- production deployment approval is defined;
- migration procedure is tested;
- secrets are managed through approved stores;
- production backup configuration is implemented;
- at least one restore test succeeds;
- monitoring dashboards exist;
- critical alerts are configured;
- rollback is tested in staging;
- incident severity/response model is accepted;
- no known conflict remains with the current architecture ADRs.
