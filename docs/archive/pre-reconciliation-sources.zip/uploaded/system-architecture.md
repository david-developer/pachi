# Pachi — System Architecture

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document is the consolidated architecture overview for Pachi. It describes runtime components, component boundaries, data flows, deployment topology, security controls, and observability. Detailed technology decisions remain authoritative in their respective ADRs.  
> **Architecture Baseline:** This document reflects the current decisions recorded in ADRs `0001` through `0006`. Where an ADR remains `Proposed`, the corresponding architecture in this document is also provisional until that ADR is accepted.  
> **Related Documents:**  
> - `docs/00-product/product-specification.md`
> - `docs/01-domain/domain-model.md`
> - `docs/01-domain/roles-and-permissions.md`
> - `docs/01-domain/lifecycle-states.md`
> - `docs/01-domain/verification-model.md`
> - `docs/01-domain/review-system.md`
> - `docs/01-domain/interaction-and-moderation-rules.md`
> - `docs/02-architecture/adr/0001-technology-stack.md`
> - `docs/02-architecture/adr/0002-authentication-and-session-strategy.md`
> - `docs/02-architecture/adr/0003-aws-region-and-environment-topology.md`
> - `docs/02-architecture/adr/0004-maps-geocoding-and-location-services.md`
> - `docs/02-architecture/adr/0005-media-processing-and-storage-policy.md`
> - `docs/02-architecture/adr/0006-notification-email-sms-strategy.md`

---

## 1. Purpose

This document defines the current target architecture for Pachi.

It exists to provide one implementation-facing view of how the product is expected to work as a complete system.

It consolidates:

- application components;
- runtime boundaries;
- data ownership;
- request flows;
- asynchronous processing;
- authentication;
- authorization;
- media handling;
- geospatial services;
- notifications;
- deployment boundaries;
- security controls;
- observability;
- failure handling.

This document defines **how the major pieces fit together**.

Detailed domain rules remain authoritative in the domain documents.

Detailed technology decisions remain authoritative in ADRs.

---

## 2. Architectural Goals

Pachi's architecture should optimize for:

- production reliability;
- straightforward implementation;
- strong domain boundaries;
- mobile and web delivery;
- trust-sensitive workflows;
- geospatial search;
- secure verification evidence;
- operational simplicity;
- controlled infrastructure cost;
- clear paths to scale.

The architecture should avoid premature complexity.

Pachi does not initially require:

- microservices;
- Kubernetes;
- active-active multi-region compute;
- a dedicated search cluster;
- a distributed cache;
- event streaming infrastructure;
- database sharding.

---

# 3. Architecture Style

## 3.1 Application Style

Pachi uses a:

```text
TypeScript monorepo
+ modular monolith backend
+ separate web and native mobile clients
+ managed cloud infrastructure
```

---

## 3.2 Backend Style

The backend is a NestJS modular monolith.

Major logical modules are expected to include:

```text
auth
users
providers
organizations
memberships
properties
listings
search
interactions
reviews
verification
moderation
media
notifications
audit
admin
```

These are logical module boundaries inside one deployable backend application initially.

Modules should not become tightly coupled merely because they share a process.

---

## 3.3 Data Style

Pachi uses PostgreSQL as its transactional system of record.

PostGIS extends PostgreSQL for geospatial storage and queries.

S3 stores binary media and evidence.

SQS carries asynchronous work.

External service providers remain supporting systems, not Pachi's authoritative marketplace database.

---

# 4. High-Level Runtime Architecture

```text
                           ┌──────────────────────────────┐
                           │          Users               │
                           │ Web / Android / iOS          │
                           └──────────────┬───────────────┘
                                          │
                     ┌────────────────────┴────────────────────┐
                     │                                         │
                     ▼                                         ▼
          ┌───────────────────────┐                 ┌───────────────────────┐
          │      Next.js Web      │                 │   Expo Mobile App     │
          │        Vercel         │                 │   Android + iOS       │
          └──────────┬────────────┘                 └──────────┬────────────┘
                     │                                         │
                     │ HTTPS                                   │ HTTPS
                     └──────────────────┬──────────────────────┘
                                        ▼
                           ┌──────────────────────────┐
                           │   Application Load       │
                           │      Balancer            │
                           └────────────┬─────────────┘
                                        ▼
                           ┌──────────────────────────┐
                           │      NestJS API          │
                           │    ECS / Fargate         │
                           │   Modular Monolith       │
                           └────────────┬─────────────┘
                                        │
         ┌──────────────────────────────┼──────────────────────────────┐
         │                              │                              │
         ▼                              ▼                              ▼
┌────────────────────┐       ┌────────────────────┐       ┌────────────────────┐
│ PostgreSQL +       │       │ Amazon S3          │       │ Amazon SQS         │
│ PostGIS on RDS     │       │ media/evidence     │       │ async work         │
└────────────────────┘       └──────────┬─────────┘       └──────────┬─────────┘
                                       │                            │
                                       ▼                            ▼
                              ┌───────────────────┐        ┌────────────────────┐
                              │ CloudFront        │        │ Worker Processes   │
                              │ public media CDN  │        │ ECS / Fargate      │
                              └───────────────────┘        └────────────────────┘
```

Supporting providers:

```text
Amazon Cognito
Google Maps Platform
Amazon SES
AWS End User Messaging SMS
Expo Push Service
Sentry
CloudWatch / X-Ray / OpenTelemetry
```

---

# 5. Repository Architecture

Proposed monorepo structure:

```text
pachi/
├── apps/
│   ├── api/
│   ├── mobile/
│   ├── web/
│   └── worker/
│
├── packages/
│   ├── api-client/
│   ├── contracts/
│   ├── database/
│   ├── eslint-config/
│   ├── typescript-config/
│   └── ui-tokens/
│
├── infrastructure/
│   └── aws/
│
├── docs/
│   ├── 00-product/
│   ├── 01-domain/
│   └── 02-architecture/
│
├── package.json
├── pnpm-workspace.yaml
└── turbo.json
```

`apps/worker/` may be introduced only when asynchronous workloads justify a separately scalable process.

---

# 6. Client Applications

## 6.1 Web Application

Technology:

```text
Next.js
TypeScript
App Router
Vercel
```

Primary responsibilities:

- public marketplace pages;
- listing search and discovery;
- listing details;
- provider and organization profiles;
- authenticated web workflows;
- server-side web session handling;
- SEO;
- deep links into product workflows.

The web application must not become the authoritative location for business rules.

All trust-sensitive rules remain enforced by the backend.

---

## 6.2 Native Mobile Application

Technology:

```text
React Native
Expo
Expo Router
TypeScript
```

Targets:

```text
Android
iOS
```

Primary responsibilities:

- native marketplace experience;
- authentication initiation;
- property discovery;
- viewing and interaction workflows;
- provider operations;
- push notifications;
- media upload;
- device location where permitted.

Mobile builds and app-store submission use Expo Application Services.

---

# 7. Backend Runtime

## 7.1 NestJS API

The API is the authoritative application boundary for:

- domain operations;
- authorization;
- lifecycle transitions;
- input validation;
- resource ownership checks;
- verification gates;
- moderation restrictions;
- signed media access;
- provider abstraction.

---

## 7.2 Modular Monolith Boundaries

Each backend module should own its own application logic.

Example:

```text
Listings Module
- create draft
- publish
- pause
- close
- enforce listing lifecycle
- call verification/authorization policy
```

Example:

```text
Interactions Module
- request viewing
- accept
- schedule
- cancel
- complete
- record no-show
- create review eligibility
```

---

## 7.3 Cross-Module Rules

Cross-module calls should occur through explicit services or domain interfaces.

Avoid:

- arbitrary imports into another module's internals;
- direct mutation of another module's tables from unrelated code;
- duplicated business rules.

---

# 8. Primary Data Store

## 8.1 PostgreSQL

PostgreSQL is authoritative for:

- users;
- external identity mappings;
- provider profiles;
- organizations;
- memberships;
- properties;
- listings;
- interactions;
- reviews;
- verification cases;
- moderation cases;
- notifications;
- audit metadata;
- media metadata.

---

## 8.2 PostGIS

PostGIS handles:

- property points;
- neighborhood polygons;
- radius search;
- bounding boxes;
- map viewport queries;
- distance ordering;
- point-in-polygon assignment.

External map providers do not own Pachi's housing inventory geography.

---

## 8.3 Database Invariants

Where practical, enforce invariants through:

- foreign keys;
- unique constraints;
- check constraints;
- transactions;
- indexes.

Examples:

```text
one review per reviewer/target/interaction
```

```text
unique external auth identity
```

```text
membership belongs to exactly one organization
```

---

# 9. Database Access Layer

Pachi uses:

```text
Drizzle ORM
+ explicit SQL where appropriate
```

Use direct SQL when necessary for:

- PostGIS;
- advanced indexes;
- database constraints;
- performance-sensitive queries;
- migrations.

The ORM must not hide required PostgreSQL capabilities.

---

# 10. Authentication Architecture

## 10.1 Identity Provider

Amazon Cognito User Pools provides:

- credential storage;
- email/password sign-in;
- Google federation;
- Apple federation;
- token issuance;
- password reset;
- MFA support.

---

## 10.2 Pachi Identity

Pachi owns its own user ID.

Conceptually:

```text
Cognito issuer + subject
        ↓
auth_identity
        ↓
users.id
```

Cognito is not the source of truth for Pachi roles or trust state.

---

# 11. Web Session Flow

```text
Browser
   │
   ▼
Next.js
   │
   ▼
Cognito Authorization Code flow
   │
   ▼
Next.js callback
   │
   ├── validates OAuth response
   ├── exchanges code
   ├── resolves Pachi user
   ├── stores server-side session
   └── returns opaque HttpOnly cookie
```

The browser should not persist Cognito refresh tokens.

---

# 12. Mobile Session Flow

```text
Expo app
   │
   ▼
system browser
   │
   ▼
Cognito Authorization Code + PKCE
   │
   ▼
mobile app
   │
   ├── access token → memory
   └── refresh credential → SecureStore
```

The mobile app sends access tokens to the API.

---

# 13. API Authentication Flow

```text
Request
   ↓
JWT signature / issuer / expiry validation
   ↓
Cognito subject resolution
   ↓
Pachi user
   ↓
Pachi authorization
```

Authentication does not equal authorization.

---

# 14. Authorization Model

Every protected operation should evaluate:

```text
authenticated user
AND account state
AND role / membership
AND resource ownership or organization scope
AND verification requirements
AND entity lifecycle state
AND moderation restrictions
```

Conceptually:

```text
Valid Access Token
        ↓
Pachi User
        ↓
Account State
        ↓
Role / Membership
        ↓
Verification
        ↓
Resource Scope
        ↓
Lifecycle
        ↓
Moderation Restrictions
        ↓
Authorization Decision
```

---

# 15. Identity and Trust Separation

The system must maintain distinct concepts:

```text
authenticated
verified email
verified phone
identity verified
verified provider
verified organization
verified property authority
authorized organization member
moderation state
```

No single `is_verified` field should represent all of them.

---

# 16. Listing Publication Flow

Conceptual flow for an individual provider:

```text
Provider submits publish action
        ↓
API authenticates user
        ↓
account active?
        ↓
P2 verified individual provider?
        ↓
A2 property authority?
        ↓
actor controls property/listing?
        ↓
listing state allows publish?
        ↓
moderation restrictions clear?
        ↓
database transaction
        ↓
listing = PUBLISHED
        ↓
outbox event
        ↓
notification / indexing / audit
```

---

# 17. Organization Publication Flow

```text
Organization member
        ↓
authenticated
        ↓
ACTIVE membership
        ↓
role permits publication
        ↓
organization O2 verified
        ↓
required representative verification
        ↓
property A2 authority
        ↓
listing lifecycle valid
        ↓
publish
```

---

# 18. Interaction Flow

Primary structured marketplace flow:

```text
Seeker
   ↓
REQUESTED
   ↓
ACCEPTED
   ↓
SCHEDULED
   ↓
COMPLETED
```

Alternative terminal outcomes:

```text
DECLINED
CANCELLED
NO_SHOW
EXPIRED
```

Completion is not inferred merely from elapsed time.

---

# 19. Review Eligibility Flow

```text
Completed qualifying interaction
        ↓
eligibility validation
        ↓
ReviewEligibility created
        ↓
review submitted
        ↓
moderation/validation
        ↓
PUBLISHED
        ↓
reputation aggregate updated
```

Invalidated interactions may revoke or suspend review eligibility.

---

# 20. Verification Flow

```text
DRAFT
  ↓
SUBMITTED
  ↓
UNDER_REVIEW
  ├── ACTION_REQUIRED
  ├── VERIFIED
  └── REJECTED
```

A verified result may later become:

```text
EXPIRED
REVOKED
```

Revocation triggers downstream permission reevaluation.

---

# 21. Moderation Flow

```text
report / fraud signal / dispute
        ↓
moderation case OPEN
        ↓
TRIAGED
        ↓
UNDER_REVIEW
        ↓
ACTION_REQUIRED if needed
        ↓
RESOLVED
        ↓
CLOSED
```

Possible actions include:

```text
warning
content hidden
content removed
listing paused
listing under moderation
interaction invalidated
review hidden
review removed
verification escalation
account capability restriction
account suspension
```

---

# 22. Geospatial Architecture

## 22.1 External Provider

Google Maps Platform provides:

- map rendering;
- place autocomplete;
- geocoding;
- reverse geocoding.

---

## 22.2 Pachi Canonical Location

Pachi stores:

```text
country
region
city
neighborhood
latitude
longitude
location precision
public location mode
display address
landmark
directions
```

The provider confirms the map pin.

Google suggestions assist but do not become authoritative automatically.

---

# 23. Neighborhood Ownership

Pachi owns its neighborhood taxonomy.

```text
Region
  ↓
City
  ↓
Neighborhood
  ↓
Aliases / optional polygon
```

External geocoder neighborhood labels do not automatically create Pachi neighborhoods.

---

# 24. Location Privacy

Exact property position and public display position are separate.

Supported public modes:

```text
EXACT
APPROXIMATE
NEIGHBORHOOD_ONLY
HIDDEN
```

Residential listings should normally avoid unnecessary public disclosure of exact coordinates.

---

# 25. Property Search Flow

```text
Seeker selects filters / viewport
        ↓
Next.js or Expo
        ↓
Pachi API
        ↓
PostgreSQL + PostGIS
        ↓
matching listings
        ↓
map/list UI
```

Google is not queried for Pachi inventory.

---

# 26. Media Architecture

## 26.1 Media Domains

Pachi separates:

```text
public marketplace media
```

from:

```text
private verification evidence
```

These must not share public delivery policies.

---

# 27. Public Media Flow

```text
Client
  ↓
request upload authorization
  ↓
Pachi API
  ↓
short-lived S3 upload URL
  ↓
direct upload to S3 quarantine
  ↓
S3 event / SQS
  ↓
media worker
  ├── validate type
  ├── malware/file checks
  ├── decode
  ├── rotate/orient
  ├── strip EXIF
  ├── resize
  ├── compress
  └── moderation scan
  ↓
processed derivative bucket/prefix
  ↓
CloudFront
  ↓
public listing UI
```

---

# 28. Verification Evidence Flow

```text
Applicant
   ↓
Pachi API authorization
   ↓
short-lived upload URL
   ↓
private S3 bucket
   ↓
quarantine / scan
   ↓
private retained original
   ↓
safe reviewer preview
```

Evidence never enters the public CloudFront path.

---

# 29. Public Image Derivatives

Initial target sizes:

```text
320 px
640 px
1280 px
1920 px
```

Preferred delivery:

```text
WebP
JPEG fallback where needed
```

Exact derivative set may change after UI performance testing.

---

# 30. Asynchronous Processing

SQS is the primary durable asynchronous queue.

Potential workloads:

- media processing;
- email;
- SMS;
- push notifications;
- verification expiry;
- review-window expiry;
- listing expiry;
- webhook handling;
- moderation jobs.

---

# 31. Worker Architecture

Workers consume jobs from SQS.

Initial topology:

```text
SQS
 ↓
ECS Fargate worker
 ↓
domain/provider operation
 ↓
result persisted
```

Workers must be:

- idempotent;
- bounded in retries;
- observable;
- DLQ-enabled.

---

# 32. Transactional Outbox

Domain-triggered asynchronous work should use a transactional outbox.

Example:

```text
database transaction
├── interaction state update
└── outbox event

commit
   ↓
outbox publisher
   ↓
SQS
```

This prevents committed domain changes from silently losing required async events.

---

# 33. Notification Architecture

Pachi owns notification intent and history.

External channels are delivery mechanisms.

```text
domain event
    ↓
notification planner
    ↓
in-app notification
    ↓
delivery records
    ↓
email / SMS / push workers
```

---

# 34. Email Delivery

Transactional email uses Amazon SES.

Uses include:

- interaction updates;
- verification updates;
- security alerts;
- organization invitations;
- moderation notices.

Email templates are application-owned and version-controlled.

---

# 35. SMS Delivery

Initial SMS provider:

```text
AWS End User Messaging SMS
```

Primary SMS use cases:

```text
phone OTP
security-sensitive phone events
selected high-priority notifications
```

SMS is not the default channel for routine marketplace activity.

---

# 36. Push Notifications

Initial mobile push:

```text
Expo Push Service
```

Push payloads must not reveal unnecessary sensitive information.

Deep links route users into the app, but server-side authorization still applies.

---

# 37. In-App Notifications

In-app notifications are stored in PostgreSQL.

They remain available even if:

- push fails;
- email bounces;
- SMS is delayed.

This is the durable notification record for normal product activity.

---

# 38. Infrastructure Topology

Primary proposed AWS region:

```text
eu-west-1
```

Backup/DR region:

```text
eu-west-3
```

Final primary-region selection remains gated by Cameroon latency testing.

---

# 39. AWS Account Boundaries

```text
AWS Organization
├── Management
├── Staging
├── Production
└── Backup / Security
```

Staging and production must not share:

- database;
- Cognito pool;
- secrets;
- queues;
- S3 buckets;
- KMS keys.

---

# 40. VPC Boundaries

Each cloud environment gets its own VPC.

Logical subnet classes:

```text
Public Subnets
Private Application Subnets
Isolated Database Subnets
```

---

# 41. Public Network Boundary

Public internet access terminates at approved ingress.

Production API:

```text
Internet
  ↓
DNS
  ↓
HTTPS
  ↓
Application Load Balancer
  ↓
private ECS tasks
```

ECS tasks are not directly exposed to the internet.

---

# 42. Database Network Boundary

Production RDS:

- no public endpoint;
- isolated subnet group;
- PostgreSQL ingress only from approved application security groups.

Direct developer access is not part of normal operation.

---

# 43. Production Compute

Production API runs in ECS Fargate.

Before public launch:

```text
minimum 2 API tasks
```

across at least two Availability Zones.

Workers may scale separately when introduced.

---

# 44. Database Availability

Staging:

```text
Single-AZ RDS
```

Production:

```text
Multi-AZ RDS PostgreSQL
```

before public launch.

---

# 45. Backup Strategy

Production RDS:

```text
automated backups
35-day retention
point-in-time recovery
cross-region replication/copy
cross-account protected backups
```

Proposed long-term recovery points:

```text
daily: 35 days
monthly: 12 months
```

---

# 46. Restore Testing

Perform:

```text
quarterly restore tests
```

after production launch.

A backup is not considered trustworthy until restore has been validated.

---

# 47. Disaster Recovery

Pachi initially uses cold/warm regional recovery.

No permanent active duplicate stack is required in the DR region.

Regional recovery:

```text
restore database
deploy infrastructure
restore required private media
switch DNS
validate authentication/integrations
resume traffic
```

Initial regional target:

```text
RTO: under 8 hours
```

subject to future testing.

---

# 48. Deployment Architecture

Backend deployment:

```text
GitHub
  ↓
GitHub Actions
  ↓
test / lint / type-check / build
  ↓
OIDC assume-role
  ↓
ECR image
  ↓
migration gate
  ↓
ECS deployment
  ↓
ALB health checks
```

No long-lived AWS deployment credentials should be stored in GitHub.

---

# 49. Production Deployment Controls

Production should use:

- protected environment;
- explicit deployment approval;
- immutable container image;
- Git revision traceability;
- health checks;
- rollback capability.

---

# 50. Database Migrations

Prefer expand/contract migration patterns.

Example:

```text
1. add new nullable field
2. deploy compatible application
3. backfill
4. switch reads/writes
5. remove old schema later
```

Do not assume destructive migration rollback is trivial.

---

# 51. Security Model

Pachi security uses defense in depth.

Primary layers:

```text
identity
session
API authentication
authorization
resource ownership
verification
lifecycle state
moderation restrictions
network isolation
IAM
encryption
audit
monitoring
```

---

# 52. Secrets

Secrets belong in:

```text
AWS Secrets Manager
or approved parameter storage
```

Never in:

- Git;
- Docker images;
- committed `.env`;
- client bundles.

---

# 53. Encryption

Required:

- HTTPS for all production public traffic;
- TLS to PostgreSQL;
- RDS encryption at rest;
- S3 encryption;
- KMS for sensitive evidence/backups where appropriate.

---

# 54. IAM

Use least privilege.

Examples:

- API role cannot arbitrarily administer all S3 buckets;
- media worker only accesses required prefixes;
- notification worker only accesses required provider secrets/queues;
- deployment role limited by environment;
- backup account protects recovery points from production application credentials.

---

# 55. Web Security

Web session controls:

```text
HttpOnly
Secure
SameSite
opaque session token
```

State-changing cookie-authenticated requests require CSRF protection.

---

# 56. Mobile Security

Mobile controls:

- OAuth Authorization Code + PKCE;
- no client secret;
- refresh credential in SecureStore;
- access token in memory;
- no tokens in logs or analytics.

---

# 57. Account Recovery Security

High-risk recovery should:

```text
re-establish identity
revoke prior sessions
notify trusted contact
audit recovery
```

Pachi does not use security questions.

---

# 58. Sensitive Evidence Access

Verification evidence access requires:

```text
authenticated actor
AND authorized role
AND case/resource scope
AND short-lived signed URL
AND audit event
```

Administrator status alone must not imply unrestricted silent evidence access.

---

# 59. Security Logging Rules

Do not log:

- passwords;
- OTP values;
- access tokens;
- refresh tokens;
- authorization codes;
- full private identity evidence;
- raw private property directions without need.

---

# 60. Audit Model

Trust-sensitive operations require durable audit history.

Examples:

- verification approval/revocation;
- listing moderation;
- review moderation;
- membership changes;
- interaction invalidation;
- privileged evidence access;
- session revocation;
- account recovery.

Audit events should be append-oriented.

Corrections create new events rather than rewriting history.

---

# 61. Observability Model

Pachi uses:

```text
structured JSON logs
OpenTelemetry
CloudWatch
AWS X-Ray / ADOT
Sentry
```

---

# 62. Logging

Backend logs should include:

```text
timestamp
level
environment
service
request_id
trace_id
route
duration
error_code
actor_id where appropriate
organization_id where appropriate
```

Sensitive information must be redacted.

---

# 63. Tracing

OpenTelemetry traces should cover:

- incoming HTTP request;
- application service calls;
- database operations where useful;
- external provider calls;
- SQS producer/consumer boundaries;
- background jobs.

---

# 64. Metrics

Core runtime metrics:

```text
request rate
error rate
latency
ECS CPU/memory
RDS CPU/storage/connections
SQS depth
SQS oldest message
worker failures
```

---

# 65. Domain Metrics

Important product-operational metrics may include:

```text
listing publication failures
verification processing latency
interaction completion rate
review eligibility creation failures
media processing failures
notification delivery failures
moderation backlog
```

Operational metrics must not replace product analytics.

---

# 66. Sentry

Sentry is used primarily for:

- web exceptions;
- mobile crashes;
- release diagnostics;
- source-map-aware debugging.

Backend Sentry may supplement, not replace, OpenTelemetry/CloudWatch.

---

# 67. Alerting

Initial alerts should focus on actionable failures.

Examples:

```text
API 5xx spike
high API latency
ALB unhealthy targets
ECS task shortage
RDS storage pressure
RDS connection pressure
SQS backlog
DLQ growth
media worker failure
notification provider failure
backup failure
deployment failure
```

Avoid alerting on low-value noise.

---

# 68. External Provider Health

Track provider health separately for:

```text
Cognito
Google Maps
SES
SMS
Expo Push
```

Providers may be:

```text
HEALTHY
DEGRADED
UNAVAILABLE
```

Application behavior should degrade gracefully where possible.

---

# 69. Failure Handling

## 69.1 Database unavailable

Expected behavior:

- fail protected operations safely;
- do not pretend writes succeeded;
- health checks should mark tasks unhealthy if database connectivity is required.

---

## 69.2 Maps provider unavailable

Existing listings remain usable using stored Pachi location data.

Impact may include:

- map tile failure;
- new geocoding unavailable.

Inventory search remains in PostGIS.

---

## 69.3 Notification provider unavailable

Core domain transaction still commits.

Notification remains queued for retry.

---

## 69.4 Media processor unavailable

Uploads remain quarantined/pending.

Do not publish raw unprocessed media.

---

## 69.5 Push unavailable

In-app notification and other selected channels remain available.

---

# 70. Idempotency

Operations vulnerable to retries must be idempotent.

Examples:

- publish listing;
- accept interaction;
- submit review;
- process media;
- deliver notification;
- complete verification transition.

Use:

- unique constraints;
- idempotency keys;
- state checks;
- transactional guards.

---

# 71. Concurrency

Concurrent state transitions must be safe.

Examples:

- provider pauses listing while moderator restricts it;
- seeker cancels while provider accepts;
- verification expires during listing publication;
- review moderation occurs during edit.

Use transactional or optimistic-concurrency mechanisms.

---

# 72. Data Ownership

Authoritative ownership by subsystem:

| Data | Authority |
|---|---|
| User identity mapping | Pachi PostgreSQL |
| Credentials | Cognito |
| Roles / memberships | Pachi PostgreSQL |
| Verification state | Pachi PostgreSQL |
| Listings | Pachi PostgreSQL |
| Geospatial inventory | PostgreSQL/PostGIS |
| Public images | S3 |
| Verification evidence | Private S3 |
| Notification history | Pachi PostgreSQL |
| Async delivery jobs | SQS |
| Public map tiles/geocoding assistance | Google Maps Platform |
| Application telemetry | CloudWatch / X-Ray / Sentry |

---

# 73. External Service Boundaries

Pachi must wrap third-party providers behind internal interfaces.

Examples:

```text
IdentityProvider
LocationProvider
EmailProvider
SmsProvider
PushProvider
MediaScanner
```

Domain modules should not depend directly on third-party response models.

---

# 74. Versioning and Compatibility

API versioning starts with:

```text
/api/v1
```

Changes should prefer backward compatibility for mobile clients because users may not upgrade immediately.

Breaking mobile API changes require explicit version-management strategy.

---

# 75. API Contract

REST + OpenAPI is the primary API style.

OpenAPI should be used to generate or validate typed client contracts where practical.

Avoid separately hand-maintaining equivalent DTO types across:

- web;
- mobile;
- backend.

---

# 76. Caching

No distributed cache is required initially.

Use:

- CDN caching;
- HTTP caching;
- database indexes;
- application-local caching only where safe.

Add Valkey/Redis later only when a measured requirement exists.

---

# 77. Search

Initial listing search uses:

```text
PostgreSQL
+ PostGIS
+ full-text search
+ trigram search where appropriate
```

Do not introduce Elasticsearch/OpenSearch until measured search requirements justify it.

---

# 78. Data Retention

Retention is domain-specific.

Examples:

- audit history retained according to audit policy;
- verification evidence retained according to verification policy;
- public media deleted after retention and holds;
- backups expire according to backup policy;
- account deletion must not blindly destroy evidence required for disputes or legal obligations.

---

# 79. Environment Boundaries

## Local

- WSL2;
- Docker Desktop;
- local PostGIS.

## Staging

- AWS staging account;
- smaller infrastructure;
- production-like service topology.

## Production

- separate AWS production account;
- Multi-AZ database;
- protected backups;
- stricter IAM;
- production monitoring.

---

# 80. Architecture Decision Hierarchy

When this architecture conflicts with an ADR:

```text
ADR wins
```

When an ADR conflicts with approved product/domain requirements:

```text
product/domain requirement must be resolved first
```

Architecture changes that are significant or difficult to reverse require a new ADR.

---

# 81. Initial Runtime Component Inventory

| Component | Runtime | Primary Responsibility |
|---|---|---|
| Web | Next.js / Vercel | Public and authenticated web UX |
| Mobile | Expo / React Native | Android/iOS UX |
| API | NestJS / ECS Fargate | Domain/API authority |
| Worker | Node/NestJS / ECS Fargate | Async jobs |
| Database | RDS PostgreSQL + PostGIS | Transactional system of record |
| Public media | S3 + CloudFront | Listing/profile media |
| Private evidence | Private S3 | Verification/moderation evidence |
| Queue | SQS | Durable async work |
| Identity | Cognito | Authentication/credentials |
| Maps | Google Maps Platform | Maps/geocoding/place search |
| Email | SES | Transactional email |
| SMS | AWS End User Messaging SMS | OTP/high-priority SMS |
| Push | Expo Push Service | Mobile push |
| Monitoring | CloudWatch/X-Ray/OTel | Logs/metrics/traces |
| Error monitoring | Sentry | Client/app exceptions |
| CI/CD | GitHub Actions | Build/test/deploy |
| IaC | AWS CDK | AWS infrastructure |

---

# 82. Architecture Invariants

The following rules should remain true unless superseded by an ADR:

1. The backend API is authoritative for business rules.
2. Authentication is not authorization.
3. Pachi owns domain roles and permissions.
4. PostgreSQL is the transactional source of truth.
5. PostGIS is authoritative for Pachi inventory geography.
6. External geocoders assist but do not own Pachi neighborhood identity.
7. Public and private media use separate security domains.
8. Verification evidence never uses the public media delivery path.
9. Async external delivery must not be required to commit the core domain transaction.
10. Production RDS is not publicly exposed.
11. Production and staging remain account-isolated.
12. Sensitive actions are auditable.
13. Clients cannot bypass lifecycle state machines.
14. Trust-impacting state transitions are server-enforced.
15. External providers are wrapped behind Pachi-owned interfaces where practical.

---

# 83. Known Open Architecture Decisions

The following remain unresolved or provisional:

- final AWS primary region after Cameroon latency testing;
- managed Cognito login UX versus custom UI;
- exact Cameroon SMS provider after benchmark;
- SMS fallback provider;
- exact production NAT topology;
- Cognito multi-region timing;
- verification evidence retention duration;
- malware scanning implementation;
- automated image moderation provider;
- exact neighborhood seed dataset;
- Google versus Mapbox benchmark result;
- privileged-session duration;
- final web authentication library.

These open decisions should not block repository scaffolding unless they directly affect the component being implemented.

---

# 84. Implementation Order

Recommended architecture implementation order:

```text
1. monorepo scaffold
2. shared TypeScript/tooling
3. local PostgreSQL + PostGIS
4. NestJS API skeleton
5. Next.js web skeleton
6. Expo mobile skeleton
7. database/migration framework
8. health checks / logging / request IDs
9. Cognito infrastructure + auth mapping
10. core users/organizations domain
11. properties/listings
12. location/PostGIS
13. media upload pipeline
14. interactions
15. reviews
16. verification
17. moderation
18. notifications
19. staging AWS deployment
20. production hardening
```

This order may change as feature sequencing becomes concrete.

---

# 85. Definition of Done

This system architecture document may move from **Draft for Review** to **Approved** when:

- ADRs `0001` through `0006` are either accepted or their provisional status is explicitly approved as the implementation baseline;
- component boundaries are accepted;
- deployment boundaries are accepted;
- authorization boundary is accepted;
- public/private media separation is accepted;
- asynchronous processing model is accepted;
- observability baseline is accepted;
- no known conflict remains with the current product and domain documents;
- implementation can begin without major unresolved structural ambiguity.
