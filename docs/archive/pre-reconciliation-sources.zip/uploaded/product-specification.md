# Pachi — Product Specification

> **Status:** Approved  
> **Last Updated:** 2026-09-24  
> **Owner:** Project  
> **Authority:** Primary product specification for Pachi. Domain documents define detailed business rules; architecture documents define implementation choices.

---

## 1. Product Summary

Pachi is a housing marketplace for Cameroon that connects property seekers with property providers while making trust, verification, structured interactions, and bilateral reputation first-class product capabilities.

Pachi supports:

- property discovery;
- individual property providers;
- organizations and agents;
- provider and property-authority verification;
- structured listing lifecycle;
- viewing interactions;
- bilateral reviews;
- moderation and disputes;
- web, Android, and iOS clients.

The product is designed around the principle that marketplace trust should be earned through verifiable identity, authority, structured interaction history, and accountable behavior.

---

## 2. Product Goals

Pachi should make it easier for users to:

1. discover legitimate housing opportunities;
2. understand who is offering a property;
3. understand whether a provider or organization has been verified;
4. confirm that a provider has authority to represent a property;
5. arrange and complete property viewings through a structured workflow;
6. develop reputation through real marketplace interactions;
7. report abuse, fraud, misrepresentation, or harmful conduct;
8. use the product safely across web and mobile.

Pachi should make it harder to:

- publish fraudulent listings;
- impersonate providers or organizations;
- create reputation without qualifying interactions;
- manipulate reviews;
- hide repeated no-show or abusive behavior;
- bypass moderation or verification controls.

---

## 3. Product Principles

### 3.1 Trust is contextual

Pachi does not use one global `verified` flag.

Trust may include:

- verified contact information;
- verified personal identity;
- verified provider capability;
- verified organization;
- verified organization representative;
- verified property authority;
- marketplace reputation.

Each trust signal must say what was actually verified.

### 3.2 Authentication is not authorization

A signed-in account does not automatically have permission to:

- publish a listing;
- administer an organization;
- represent a property;
- moderate content;
- access verification evidence.

### 3.3 Marketplace reputation is bilateral

Both sides of a qualifying interaction can affect future trust.

A seeker may review the provider or organization they interacted with.

The provider or organization may review the seeker.

This is intended to encourage responsible conduct by both sides.

### 3.4 Structured interactions matter

Messages, page views, saves, and inquiries are useful product activity but do not by themselves create review eligibility.

Viewing interactions are the primary trust-qualified interaction in the initial model.

### 3.5 Server-side rules are authoritative

Clients may improve UX, but they do not define permissions, lifecycle transitions, verification requirements, or moderation enforcement.

---

## 4. User Model

A Pachi account may participate in more than one marketplace capacity.

A single user may be:

- a property seeker;
- an individual provider;
- a member of one or more organizations.

These capacities are not mutually exclusive global roles.

Platform staff are separate from marketplace roles.

---

## 5. Marketplace Actors

### 5.1 Guest

May browse approved public marketplace content.

### 5.2 Authenticated User

Has a Pachi account and authenticated session.

### 5.3 Seeker

Can discover properties and participate in eligible interaction workflows.

### 5.4 Individual Provider

Can manage provider-owned property/listing workflows subject to verification and authority requirements.

### 5.5 Organization Member

Acts within an organization using membership-scoped permissions.

Organization roles:

- Owner;
- Admin;
- Agent.

### 5.6 Platform Staff

Includes:

- Moderator;
- Platform Administrator.

Platform roles are separate from organization roles.

---

## 6. Organizations

Pachi supports organizations that may represent properties through authorized members.

Examples may include:

- property agencies;
- property management companies;
- other approved provider organizations.

An organization has:

- organization identity;
- membership;
- roles;
- verification state;
- marketplace reputation.

### 6.1 Organization Roles

**Owner**
- controls organization ownership and highest organization-level administration.

**Admin**
- manages organization operations within granted permissions.

**Agent**
- performs provider workflows for the organization within membership scope.

The organization owner is not an ordinary removable member.

Pachi should maintain one active owner per active organization unless an explicit ownership-transfer workflow is in progress.

---

## 7. Verification Model

Verification is modeled as subject-specific verification cases and results.

Supported verification concepts include:

- contact email;
- contact phone;
- personal identity;
- individual provider;
- organization entity;
- organization representative;
- property authority.

### 7.1 User Verification Levels

```text
U0 — account exists
U1 — required contact verification completed
U2 — personal identity verified
```

### 7.2 Individual Provider Levels

```text
P0 — no provider verification
P1 — provider profile / preliminary requirements
P2 — verified individual provider
```

### 7.3 Organization Levels

```text
O0 — unverified organization
O1 — preliminary organization verification
O2 — verified organization
```

### 7.4 Property Authority Levels

```text
A0 — no authority verification
A1 — preliminary/incomplete authority
A2 — verified authority to represent property
```

### 7.5 Publication Baseline

Individual provider publication requires:

```text
authenticated
AND active account
AND P2 provider verification
AND control of the property/listing
AND A2 property authority
AND valid listing lifecycle state
AND no blocking moderation restriction
```

Organization publication requires:

```text
authenticated
AND active organization membership
AND membership role permits action
AND O2 organization verification
AND required representative authorization
AND A2 property authority
AND valid listing lifecycle state
AND no blocking moderation restriction
```

---

## 8. Verification Lifecycle

Verification cases use the following baseline lifecycle:

```text
DRAFT
SUBMITTED
UNDER_REVIEW
ACTION_REQUIRED
VERIFIED
REJECTED
EXPIRED
REVOKED
CANCELLED
```

Verification history must remain durable.

Reverification creates a new reviewable process rather than silently restoring an old result.

Loss of verification may affect marketplace capabilities.

Recommended listing effects:

```text
verification expired → listing PAUSED
verification revoked → listing UNDER_MODERATION
```

---

## 9. Property Model

A property represents the real-world housing asset.

A property is distinct from a listing.

The property contains relatively durable facts such as:

- location;
- property type;
- physical characteristics;
- authority relationships;
- media relationships.

A property may have multiple listing records over time.

---

## 10. Location

Pachi supports a location model designed for Cameroon, where complete formal street addressing may not always be available.

Canonical property location may include:

- country;
- region;
- city/locality;
- neighborhood;
- coordinates;
- display address;
- landmark;
- directions;
- location precision;
- public location mode.

The provider confirms the property location.

External maps/geocoding services may assist, but Pachi owns canonical city/neighborhood relationships and marketplace geography.

### 10.1 Public Location Privacy

Supported public modes:

```text
EXACT
APPROXIMATE
NEIGHBORHOOD_ONLY
HIDDEN
```

Stored exact location may be more precise than the public location shown to seekers.

---

## 11. Listing Model

A listing represents a marketplace offer for a property.

Listings are separate from properties so Pachi can preserve:

- listing history;
- prior publication periods;
- changing prices or offering details;
- moderation history;
- closing/archival state.

### 11.1 Listing Lifecycle

```text
DRAFT
PENDING_REVIEW
PUBLISHED
PAUSED
UNDER_MODERATION
CLOSED
ARCHIVED
```

Clients request domain operations such as `publish`, `pause`, or `close`.

The server validates whether the transition is legal.

Unrestricted arbitrary state patching is not acceptable.

---

## 12. Marketplace Discovery

Seekers should be able to discover listings through:

- city;
- neighborhood;
- map viewport;
- distance;
- property attributes;
- listing attributes;
- keyword/fuzzy search where useful.

Only eligible public listing states appear in normal public discovery.

Initial search is backed by PostgreSQL/PostGIS and PostgreSQL search capabilities rather than a dedicated search cluster.

---

## 13. Listing Media

Listings may contain multiple approved property images.

Media requirements include:

- controlled upload authorization;
- asynchronous processing;
- resizing/compression;
- removal of unnecessary public EXIF/GPS metadata;
- moderation;
- public delivery through approved CDN paths.

Private verification documents never use the public listing-media access model.

---

## 14. Interaction Types

Initial interaction concepts include:

- Inquiry;
- Contact Request;
- Viewing Request;
- Viewing Appointment.

Inquiry and Contact Request do not create normal review eligibility.

Viewing is the primary trust-qualified interaction.

---

## 15. Viewing Lifecycle

Baseline states:

```text
REQUESTED
ACCEPTED
SCHEDULED
COMPLETED
DECLINED
CANCELLED
NO_SHOW
EXPIRED
```

`IN_PROGRESS` is not required for the initial implementation.

Interaction history must be durable.

Rescheduling preserves prior history rather than rewriting it.

---

## 16. Interaction Completion

Completion is not inferred only because the scheduled time has passed.

Recommended baseline:

- either eligible participant may mark the viewing completed;
- the counterpart receives a short opportunity to dispute;
- disputed completion suspends trust effects until resolved;
- staff can resolve disputes when required.

Exact timing windows are configuration/business-rule details.

---

## 17. Cancellation

Cancellation records at least:

- actor;
- timestamp;
- reason where collected;
- previous state.

Cancelled interactions do not normally create review eligibility.

---

## 18. No-Shows

No-show responsibility may be represented as:

```text
SEEKER_NO_SHOW
PROVIDER_NO_SHOW
BOTH_UNCONFIRMED
DISPUTED
```

A no-show must not be inferred only from elapsed time.

No-shows are structured trust events, not ordinary star reviews.

Repeated confirmed no-shows may contribute to warnings, restrictions, or moderation.

---

## 19. Review Eligibility

Baseline qualifying interaction:

```text
interaction.type == VIEWING
AND interaction.state == COMPLETED
AND interaction remains valid
```

The following do not create ordinary review eligibility:

- page view;
- saved listing;
- message;
- inquiry;
- contact request;
- declined interaction;
- cancelled interaction;
- expired interaction.

---

## 20. Bilateral Reviews

After an eligible completed viewing:

- seeker may review the provider or provider organization;
- provider or provider organization may review the seeker.

This reciprocal eligibility is part of the approved product model.

The review target for organization-mediated interactions is the organization in the initial model rather than the individual agent.

---

## 21. Review Rules

Initial review baseline:

- 1–5 integer rating;
- optional review text;
- one review per reviewer / target / interaction / direction;
- no self-review;
- no review of one's own organization;
- only eligible interactions may create reviews.

Review states:

```text
DRAFT
SUBMITTED
PUBLISHED
UNDER_MODERATION
HIDDEN
REMOVED
WITHDRAWN
```

Moderators do not silently rewrite user review text.

---

## 22. Review Visibility and Reputation

Only eligible `PUBLISHED` reviews contribute to public reputation aggregates.

When a related interaction becomes disputed or invalidated, Pachi may suspend or remove its reputation contribution pending moderation.

Review removal preserves historical/audit context.

---

## 23. Reciprocal Review Reveal

Pachi should support a delayed or double-blind reciprocal reveal model where practical so one party cannot easily retaliate based on seeing the counterpart's review first.

Exact reveal timing is an implementation/business-rule decision.

---

## 24. Moderation

Users may report content, users, listings, interactions, or reviews.

Moderation cases may include categories such as:

```text
FRAUD
IMPERSONATION
HARASSMENT
LISTING_MISREPRESENTATION
REVIEW_ABUSE
NO_SHOW_DISPUTE
VERIFICATION_ISSUE
PRIVACY
SPAM
SAFETY
OTHER
```

Moderation case lifecycle:

```text
OPEN
TRIAGED
UNDER_REVIEW
ACTION_REQUIRED
RESOLVED
CLOSED
```

---

## 25. Moderation Actions

Possible actions include:

```text
NO_ACTION
WARNING
CONTENT_HIDDEN
CONTENT_REMOVED
LISTING_PAUSED
LISTING_UNDER_MODERATION
INTERACTION_INVALIDATED
REVIEW_ELIGIBILITY_REVOKED
REVIEW_HIDDEN
REVIEW_REMOVED
VERIFICATION_REVIEW_REQUIRED
VERIFICATION_REVOKED
ACCOUNT_CAPABILITY_RESTRICTED
ACCOUNT_SUSPENDED
ORGANIZATION_RESTRICTED
ESCALATED
```

Capability-specific restrictions are preferred to one undifferentiated `is_banned` flag.

---

## 26. Appeals and Reversals

Where appeals are supported, they must preserve the original moderation decision.

An appeal creates new reviewable history rather than overwriting the prior decision.

---

## 27. Authentication

Pachi's current architecture baseline proposes managed identity using Amazon Cognito User Pools.

Initial login methods:

- email/password;
- Google;
- Sign in with Apple.

Phone verification is initially a separate trust/contact-verification capability, not the primary login method.

Authentication architecture is defined by ADR 0002 and may evolve without changing the product role model.

---

## 28. Sessions

Web and mobile may use different secure session implementations while presenting the same Pachi account model.

The product requirement is:

- secure cross-platform sessions;
- logout current session;
- ability to terminate sessions;
- account recovery;
- server-side account-state enforcement.

---

## 29. Notifications

Pachi supports:

- in-app notifications;
- transactional email;
- SMS/OTP;
- mobile push.

In-app notification history is the durable product-facing record for ordinary notifications.

External channels supplement it.

Users may control optional notification channels.

Security-critical notifications remain mandatory where needed.

---

## 30. Notification Language

Pachi should support transactional communication in:

- English;
- French.

---

## 31. Security and Privacy Product Requirements

Pachi must:

- avoid exposing private verification evidence publicly;
- avoid exposing unnecessary precise residential location;
- protect authentication credentials;
- prevent client-side authorization bypass;
- preserve trust-impacting audit history;
- avoid logging secrets;
- provide controlled deletion/retention behavior;
- rate-limit abuse-prone flows such as OTP and uploads.

---

## 32. Auditability

Trust-sensitive actions require durable audit history.

Examples:

- verification decisions;
- provider/organization trust changes;
- membership/ownership changes;
- moderation;
- interaction invalidation;
- review moderation;
- privileged evidence access;
- security recovery.

---

## 33. Initial Product Scope

The initial product should support the complete core marketplace loop:

```text
account
→ provider/seeker participation
→ property
→ verified authority
→ listing
→ discovery
→ viewing interaction
→ completion
→ bilateral review
→ moderation/trust feedback
```

The implementation may ship this iteratively.

The product should not be artificially reduced to a demo that removes the trust model simply because development starts with one engineer.

---

## 34. Deferred / Later Capabilities

Capabilities may be deferred until justified by product demand or operational maturity, including:

- payments;
- advanced messaging;
- travel-time/commute search;
- advanced dedicated search infrastructure;
- web push;
- passkey-first authentication;
- multi-region active-active operation;
- complex recommendation systems.

Deferral means "not required for initial implementation," not "forbidden."

---

## 35. Analytics

Pachi should eventually measure marketplace health across:

- acquisition;
- listing supply;
- search activity;
- viewing requests;
- viewing completion;
- cancellation/no-show behavior;
- review participation;
- verification conversion;
- moderation volume;
- provider/seeker trust outcomes.

Detailed product analytics architecture is intentionally separate from operational observability.

---

## 36. Release Gates

A public production release must not occur until:

- authentication and authorization are working;
- listing lifecycle rules are enforced server-side;
- verification evidence is protected;
- database backups/restores are tested;
- public/private media separation works;
- monitoring and incident response are available;
- core end-to-end marketplace flows pass production-readiness checks.

Operational launch requirements are defined under `docs/03-operations/`.

---

## 37. Product Decision Authority

When implementation uncertainty concerns **what Pachi should do**, resolve it in:

- this product specification;
- the domain model;
- specialized domain/business-rule documents.

When uncertainty concerns **how Pachi implements it**, resolve it in:

- system architecture;
- ADRs;
- engineering specifications.

Architecture must not silently redefine approved product behavior.
