# ADR 0002: Authentication and Session Strategy

> **Status:** Proposed  
> **Date:** 2026-09-24  
> **Decision Owners:** Pachi Engineering  
> **Scope:** Identity provider, sign-in methods, web and mobile sessions, email and phone verification, social login, MFA, account linking, logout, and account recovery  
> **Supersedes:** None  
> **Superseded By:** None  
> **Related ADRs:** `0001-technology-stack.md`

---

## 1. Context

Pachi requires one identity system that can support:

- public web;
- Android;
- iOS;
- email/password authentication;
- social login;
- verified email addresses;
- verified phone numbers;
- account recovery;
- long-lived mobile sessions;
- secure browser sessions;
- privileged staff authentication;
- future MFA and passkey support;
- secure account linking;
- session revocation;
- application-owned authorization.

Authentication is security-sensitive, but Pachi's authorization model is substantially more complex than ordinary login.

Pachi must distinguish between:

- identity;
- account state;
- provider verification;
- organization membership;
- organization role;
- property authority;
- moderation restrictions;
- resource ownership.

The identity provider must therefore authenticate users without becoming the source of truth for Pachi's domain permissions.

---

## 2. Decision

Pachi will initially use **Amazon Cognito User Pools** as its managed identity provider.

Pachi will use Cognito as an OpenID Connect and OAuth 2.0 identity service for credentials and authentication.

Pachi's own PostgreSQL database remains authoritative for:

- Pachi user records;
- provider state;
- organization memberships;
- roles and permissions;
- verification levels;
- moderation restrictions;
- resource ownership;
- application sessions and security metadata where required.

The initial authentication methods will be:

1. **email + password**;
2. **Google sign-in**;
3. **Sign in with Apple**.

Phone number verification will initially be a **separate Pachi verification capability**, not a primary login method.

The initial architecture will use:

- OAuth 2.0 Authorization Code flow;
- PKCE;
- OpenID Connect;
- separate Cognito app clients for web and mobile;
- short-lived Cognito access tokens;
- refresh-token rotation;
- token revocation;
- secure web cookies;
- encrypted native secure storage;
- server-side Pachi authorization checks.

Pachi will **not** initially use Cognito Identity Pools because web and mobile clients do not need direct AWS credentials.

Access to AWS resources such as private uploads will be brokered through the Pachi backend using narrowly scoped mechanisms such as pre-signed URLs.

---

## 3. Decision Drivers

### 3.1 Do not build credential security from scratch

Password storage, OAuth federation, token issuance, token revocation, social login, MFA, and account-recovery flows are security-sensitive infrastructure.

Pachi should use a mature managed identity provider rather than implementing these primitives itself.

### 3.2 Cross-platform authentication

The same user must be able to access Pachi from:

- web;
- Android;
- iOS.

The authentication system must use standards that work consistently across those environments.

### 3.3 AWS alignment without domain lock-in

ADR 0001 proposes AWS as Pachi's primary backend cloud.

Cognito integrates naturally with that platform while still exposing standard OAuth 2.0 and OpenID Connect interfaces.

The application should depend on standard token behavior where practical rather than Cognito-specific authorization concepts.

### 3.4 Application-owned authorization

Cognito groups or custom claims must not become the canonical model for:

- provider roles;
- organization roles;
- moderation;
- verification;
- property authority.

Those values change according to Pachi domain rules and belong in Pachi's own data model.

### 3.5 Mobile security

Native applications cannot safely store client secrets.

The mobile flow must therefore support a public OAuth client using Authorization Code + PKCE.

### 3.6 Browser security

Long-lived refresh credentials should not be exposed to browser JavaScript or persisted in `localStorage`.

The web architecture should use an opaque server-side session.

### 3.7 Cameroon-specific phone delivery

Phone verification is important for Pachi, but SMS delivery, sender requirements, pricing, and reliability should be evaluated specifically for the target market.

Phone verification therefore remains behind a Pachi provider abstraction instead of becoming inseparable from Cognito authentication.

### 3.8 App-store requirements

If Pachi offers third-party social sign-in in the iOS application, the authentication design must remain compatible with Apple's current login-service requirements.

### 3.9 Recoverability

Users must be able to recover accounts without support staff casually bypassing identity controls.

### 3.10 Auditability

Trust-sensitive identity events must be traceable without storing passwords, OTP values, access tokens, or other secrets in audit logs.

---

# 4. Identity Model

## 4.1 Pachi User ID

Every Pachi user has an application-owned immutable identifier.

Example:

```text
users.id = UUID
```

This is the canonical identity used throughout Pachi's domain model.

The application must not use:

- email address;
- phone number;
- Cognito username;
- social-provider username;

as the primary application identity.

---

## 4.2 External Identity Mapping

External login identities map to a Pachi user.

Conceptually:

```text
AuthIdentity
- id
- user_id
- issuer
- subject
- provider
- created_at
- linked_at
- unlinked_at
```

A unique external identity is identified by:

```text
issuer + subject
```

For Cognito-issued identities, the `sub` claim is the stable external subject identifier.

Email addresses must not be used as external identity keys.

---

## 4.3 Multiple Login Identities

One Pachi user may eventually have multiple sign-in identities.

Example:

```text
Pachi User
├── Cognito local email/password identity
├── Google identity
└── Apple identity
```

Identity linking must be explicit and secure.

---

# 5. Cognito User Pool

## 5.1 One Primary User Pool per Environment

Each long-lived environment should have its own Cognito User Pool.

At minimum:

```text
staging
production
```

Production users must not authenticate against non-production user pools.

---

## 5.2 App Clients

Use separate Cognito app clients for different trust contexts.

Initial clients:

```text
pachi-web
pachi-mobile
```

A future privileged administration application may use a separate client.

---

## 5.3 Web Client

The web application is a server-capable client.

The OAuth exchange is completed by the Next.js server-side authentication layer.

A client secret may be used only on the trusted server.

The client secret must never be included in browser code.

---

## 5.4 Mobile Client

The mobile app is a public OAuth client.

It must:

- have no client secret;
- use Authorization Code flow;
- use PKCE with `S256`;
- authenticate through the system browser;
- return through approved application links/deep links.

---

## 5.5 Prevent Account Enumeration

Cognito app clients must enable user-existence suppression where compatible with the selected flow.

Authentication and recovery screens should avoid revealing whether a specific email address is registered.

Example user-facing response:

```text
If an account exists for this email, instructions have been sent.
```

---

# 6. Login Methods

## 6.1 Email and Password

Email/password is the baseline local login mechanism.

The user signs in using their email address.

Cognito remains responsible for:

- password hashing;
- password comparison;
- credential storage;
- credential reset.

Pachi must never store the user's password.

---

## 6.2 Password Policy

Proposed baseline:

```text
minimum length: 12 characters
no forced periodic password rotation
password history: enabled where supported
```

Pachi should support password managers and pasted passwords.

A password reset should be required after known compromise, security recovery, or authorized administrative intervention.

---

## 6.3 Google Sign-In

Google will be an initial social login provider.

Google authentication will federate through Cognito.

Pachi's clients should authenticate against Cognito rather than maintaining separate Google session semantics in the application backend.

---

## 6.4 Sign in with Apple

Sign in with Apple will be an initial social login provider.

This supports:

- iOS users;
- Apple's privacy-preserving email relay;
- compatibility with current App Store login-service rules when social login is offered.

Pachi must treat Apple's private relay address as a valid distinct email address.

It must not assume that an Apple relay email matches a user's ordinary email.

---

## 6.5 Other Social Providers

Deferred.

Additional providers should be added only when there is demonstrated user demand.

---

## 6.6 Phone-Number Login

Deferred.

Phone verification is useful as a trust signal, but phone-number login is not required for the initial authentication model.

Reasons include:

- SMS cost;
- delivery reliability;
- SIM-swap risk;
- number recycling;
- country-specific messaging requirements;
- account-linking complexity.

---

## 6.7 Passwordless Login

Deferred.

Passwordless email/SMS and passkeys may be reconsidered later.

The architecture should not prevent future passkey adoption.

---

# 7. Managed Login

## 7.1 Initial Authentication UI

The initial proposal is to use Cognito's managed login / hosted authorization flow for authentication-sensitive screens.

This includes:

- sign-in;
- sign-up;
- password reset;
- social-provider redirect;
- MFA challenge where supported.

Benefits:

- less custom security-sensitive UI;
- standard OAuth behavior;
- simpler social federation;
- faster initial implementation.

---

## 7.2 Future Custom Authentication UI

Pachi may later move selected authentication screens into custom application UI if product requirements justify it.

Changing UI must not change the underlying identity architecture.

---

# 8. OAuth and OpenID Connect Flow

The default interactive flow is:

```text
Authorization Code + PKCE
```

Required controls:

```text
PKCE S256
state
nonce where applicable
registered redirect URIs
exact redirect validation
HTTPS in production
```

The implicit OAuth flow must not be used.

---

# 9. Web Authentication Architecture

## 9.1 Browser Session Model

The browser receives a Pachi session cookie.

It does **not** receive a long-lived Cognito refresh token.

Proposed cookie:

```text
__Host-pachi_session
```

Required attributes:

```text
HttpOnly
Secure
SameSite=Lax
Path=/
no Domain attribute
```

---

## 9.2 Web Sign-In Flow

```text
Browser
   │
   ▼
Next.js authentication route
   │
   ▼
Cognito authorization endpoint
   │
   ▼
User authenticates
   │
   ▼
Next.js callback
   │
   ├── validates OAuth response
   ├── exchanges code
   ├── maps Cognito subject → Pachi user
   ├── creates Pachi web session
   └── returns opaque HttpOnly session cookie
```

---

## 9.3 Web Session Storage

Conceptually:

```text
WebSession
- id
- user_id
- created_at
- last_seen_at
- expires_at
- revoked_at
- client_metadata
- encrypted_refresh_credential
- provider_session_reference
```

Long-lived provider refresh credentials must be encrypted at rest.

The browser cookie should contain an opaque, high-entropy session identifier rather than raw Cognito tokens.

Where practical, store only a hash of the browser session identifier server-side.

---

## 9.4 Web API Calls

Preferred pattern:

```text
Browser
   ↓
Next.js server/BFF
   ↓
Pachi API
```

The Next.js server obtains or refreshes the Cognito access token and sends it to the Pachi API.

---

## 9.5 CSRF

Cookie-authenticated state-changing web operations require CSRF protection.

Controls should include:

- `SameSite` cookie policy;
- Origin/Referer validation where appropriate;
- CSRF tokens where required;
- OAuth `state` validation.

---

# 10. Mobile Authentication Architecture

## 10.1 Authentication Flow

The native application will use:

```text
Expo
+ system browser
+ OAuth Authorization Code
+ PKCE
+ Cognito
```

Authentication must not collect social-provider credentials inside a Pachi-controlled WebView.

---

## 10.2 Token Storage

Recommended model:

```text
access token  → memory
refresh token → Expo SecureStore
```

If the app restarts:

```text
SecureStore refresh credential
        ↓
token refresh
        ↓
new short-lived access token
```

Authentication tokens must not be stored in:

```text
AsyncStorage
unencrypted files
application logs
analytics events
crash-report payloads
```

---

## 10.3 Mobile API Calls

The native app sends:

```http
Authorization: Bearer <access-token>
```

to the Pachi API.

The app must use the **access token**, not the OpenID Connect ID token, as the API authorization credential.

---

## 10.4 Mobile Client Secret

The mobile application must not contain a Cognito client secret.

Anything shipped in an Android or iOS application bundle must be treated as publicly recoverable.

---

# 11. Token Policy

## 11.1 Proposed Durations

Initial proposed values:

```text
access token: 15 minutes
ID token: 15 minutes
refresh token: 30 days
```

These values are configuration, not hard-coded business logic.

---

## 11.2 Refresh Token Rotation

Refresh-token rotation must be enabled.

Recommended retry grace period:

```text
10 seconds
```

---

## 11.3 Token Revocation

Cognito token revocation must remain enabled.

Pachi must support:

- logout from current session;
- logout from all sessions;
- administrative session termination.

---

## 11.4 Residual Access-Token Lifetime

Already-issued access tokens may remain valid until expiry if the API only checks JWT signature and expiration.

Mitigations:

- short access-token lifetime;
- Pachi account-state checks;
- session/restriction checks for sensitive operations;
- optional deny-list checks when immediate revocation is required.

---

# 12. API Token Validation

The Pachi API must validate:

- JWT signature;
- trusted issuer;
- expiry;
- expected token type/use;
- approved app client;
- required scopes where used.

After validation:

```text
Cognito subject
      ↓
AuthIdentity
      ↓
Pachi User
      ↓
Pachi authorization
```

A valid Cognito token proves authentication only.

It does not by itself authorize:

- listing publication;
- organization administration;
- moderation;
- verification evidence access;
- property management.

---

# 13. Pachi Session Registry

Pachi should maintain a lightweight session/security registry.

Conceptually:

```text
Session
- id
- user_id
- platform
- created_at
- last_seen_at
- expires_at
- revoked_at
- device_label
- auth_provider
- provider_session_reference
```

Potential uses:

- display active sessions;
- sign out one device;
- sign out all devices;
- force invalidation after recovery;
- investigate suspicious access.

Raw refresh tokens must not be stored in ordinary session metadata.

---

# 14. Email Verification

## 14.1 Email as Local Login Identifier

For local accounts, email is the login identifier.

The stable Pachi identity remains the Pachi user UUID.

The stable external identity remains the Cognito subject.

---

## 14.2 Verification Requirement

A local email/password account must verify its email before receiving normal verified-account permissions.

Domain permission effects must remain aligned with:

```text
docs/01-domain/verification-model.md
```

---

## 14.3 Verification Mechanism

Cognito will perform local-account email verification using a verification link or code.

---

## 14.4 Email Delivery

Production Cognito email should use an approved Amazon SES sending configuration and authenticated domain.

The final sender/domain will be configured later.

---

## 14.5 Email Changes

Changing the primary email must require verification of the new address before it becomes trusted.

Sensitive email changes should generate a notification to the previous verified contact where possible.

---

## 14.6 Social Email Claims

A federated email may be treated as verified only when the trusted provider explicitly asserts verification.

Provider email must never be used to silently merge accounts.

---

# 15. Phone Verification

## 15.1 Separate From Authentication

Phone verification will initially be a Pachi trust/contact-verification service rather than the primary Cognito sign-in method.

This allows Pachi to choose an OTP provider based on Cameroon-specific performance.

---

## 15.2 Canonical Format

Phone numbers should be stored in normalized international format such as E.164.

---

## 15.3 Verification Flow

```text
User submits phone
        ↓
Pachi creates OTP challenge
        ↓
SMS provider sends OTP
        ↓
User submits OTP
        ↓
Pachi verifies challenge
        ↓
phone_verified_at recorded
```

---

## 15.4 OTP Security

Required controls:

- cryptographically secure random code;
- short expiry;
- resend cooldown;
- attempt limit;
- account/phone/IP rate limits;
- no OTP logging;
- no plaintext OTP storage.

Recommended starting values:

```text
OTP validity: 5 minutes
maximum attempts: 5
resend cooldown: 60 seconds
```

These values should remain configurable.

---

## 15.5 Phone Reuse

Proposed baseline:

A verified phone number may belong to only one active Pachi account at a time unless an authorized support workflow resolves a legitimate reassignment.

This rule should be reviewed against real usage before final approval.

---

## 15.6 Permission Gates

This ADR defines the phone-verification mechanism, not every business permission tied to it.

Those gates remain owned by `verification-model.md`.

---

# 16. Social Account Linking

## 16.1 No Automatic Email-Only Linking

Pachi must not automatically merge identities merely because they present the same email.

---

## 16.2 Explicit Linking

If a signed-in user wants to add Google or Apple:

1. authenticate to the existing Pachi account;
2. initiate linking;
3. authenticate with the new provider;
4. backend verifies both identities;
5. link the identity;
6. record a security audit event.

---

## 16.3 Existing-Email Collision

If social login returns an email already used by another Pachi account:

- do not silently merge;
- require authentication to the existing account;
- offer secure account linking.

---

## 16.4 Apple Private Relay

Apple private-relay addresses must not be treated as duplicates of ordinary email addresses.

---

## 16.5 Unlinking

Do not allow removal of the final usable authentication method.

Sensitive unlinking should require recent authentication.

---

# 17. Multi-Factor Authentication

## 17.1 Normal Users

MFA will initially be optional for ordinary users.

TOTP authenticator applications are the preferred optional second factor.

---

## 17.2 Platform Staff

Moderators and platform administrators must use stronger authentication.

Proposed baseline:

```text
local Cognito credential
+ TOTP MFA
```

Privileged staff accounts should not rely solely on social login.

---

## 17.3 Organization Owners and Admins

MFA should be strongly encouraged.

Mandatory MFA is deferred until Pachi has a consistent step-up model that works for federated identities.

---

## 17.4 Federated MFA

For Google/Apple users, the external provider controls its own authentication factors.

This must be considered before making Pachi MFA mandatory for roles that may use social login.

---

# 18. Recent Authentication / Step-Up

Sensitive actions should require recent authentication.

Examples:

- change primary email;
- link or unlink identity;
- change password;
- transfer organization ownership;
- access high-risk verification evidence;
- disable MFA;
- perform privileged administration.

Initial target:

```text
recent authentication within 10 minutes
```

If authentication is older, require reauthentication.

---

# 19. Account Recovery

## 19.1 Local Password Accounts

Primary recovery method:

```text
verified email
```

Flow:

```text
Forgot password
   ↓
Cognito recovery challenge
   ↓
verified-email proof
   ↓
new password
   ↓
session invalidation according to policy
```

---

## 19.2 Phone Recovery

Phone-only recovery is not part of the initial design.

It may be added later after explicit security review.

---

## 19.3 Social-Only Accounts

A social-only user primarily recovers access through the external identity provider.

Pachi cannot reset Google or Apple credentials.

---

## 19.4 Exceptional Recovery

If a user loses the primary verified email and has no usable linked identity:

- recovery is a high-risk support process;
- identity must be re-established through approved evidence;
- support staff must not casually replace verified contact data;
- recovery must be audited;
- existing sessions should be revoked;
- sensitive contacts must be re-verified.

---

## 19.5 Security Questions

Pachi will not use security questions.

---

## 19.6 Recovery Session Invalidation

Successful high-risk recovery should trigger:

```text
Cognito global sign-out
+ Pachi session revocation
+ security notification
```

---

# 20. Logout

## 20.1 Current Device

Web:

- revoke Pachi web session;
- revoke associated provider refresh credential where applicable;
- clear session cookie.

Mobile:

- revoke refresh credential;
- delete SecureStore credential;
- clear in-memory token.

---

## 20.2 All Devices

"Sign out everywhere" should:

- invoke Cognito global sign-out;
- revoke all Pachi sessions;
- clear current client state.

---

## 20.3 Administrative Termination

Security or moderation workflows may terminate all sessions without deleting the account.

---

# 21. Account State and Authentication

A valid Cognito token does not override Pachi account state.

The API must still enforce states such as:

```text
ACTIVE
SUSPENDED
RESTRICTED
CLOSED
```

---

# 22. Session Durations

Proposed defaults:

| Session Element | Normal User | Privileged Staff |
|---|---:|---:|
| Access token | 15 minutes | 15 minutes |
| ID token | 15 minutes | 15 minutes |
| Refresh credential | 30 days | Shorter policy to be defined |
| Recent-auth requirement | 10 minutes | 10 minutes or stricter |

---

# 23. Security Events and Audit

Record at minimum:

- Pachi account created;
- identity linked/unlinked;
- email verification completed;
- primary email changed;
- phone verification completed;
- phone changed;
- password recovery completed;
- exceptional recovery;
- MFA enabled/disabled;
- session created where appropriate;
- session revoked;
- logout-all;
- account suspended/disabled;
- privileged authentication change.

Audit fields may include:

```text
event_id
user_id
session_id
auth_identity_id
event_type
actor_id
actor_type
timestamp
request_id
ip_security_context
device_context
metadata
```

Never record:

- password;
- OTP;
- access token;
- refresh token;
- authorization code;
- provider token;
- Cognito client secret.

---

# 24. Security Controls

Initial implementation must include:

- HTTPS in production;
- exact redirect allowlists;
- Authorization Code + PKCE;
- OAuth `state`;
- OIDC `nonce` where applicable;
- short-lived access tokens;
- refresh-token rotation;
- token revocation;
- user-existence suppression;
- rate limiting;
- brute-force controls;
- secure cookies;
- secure native credential storage;
- secrets outside source control;
- audit events;
- account-state checks;
- recent authentication for sensitive changes.

AWS WAF and Cognito threat-protection features may be enabled according to risk and cost.

---

# 25. Client Responsibilities

## 25.1 Web

The browser may initiate authentication and submit application requests.

It must not become the source of truth for roles or permissions.

## 25.2 Mobile

The native app may hold short-lived auth state and securely retain the refresh credential.

It must not contain:

- Cognito client secret;
- AWS administrative credentials;
- permanent API secrets.

---

# 26. Backend Responsibilities

The API must:

1. validate Cognito access token;
2. resolve external identity to Pachi user;
3. check account state;
4. load roles/memberships;
5. apply verification gates;
6. apply resource scope;
7. apply moderation restrictions;
8. authorize the operation.

```text
Valid Access Token
        ↓
Authenticated Pachi User
        ↓
Account State
        ↓
Role / Membership
        ↓
Verification
        ↓
Resource Scope
        ↓
Moderation Restrictions
        ↓
Authorization Decision
```

---

# 27. Infrastructure Requirements

Infrastructure as code should configure:

- Cognito User Pool;
- web app client;
- mobile app client;
- managed-login domain;
- social federation;
- token lifetimes;
- refresh rotation;
- revocation;
- user-existence suppression;
- email delivery;
- callback URLs;
- logout URLs;
- environment-specific secrets.

---

# 28. Development Environments

Production OAuth credentials must not be reused for ordinary development.

Environments need separate:

- callback URLs;
- client IDs;
- social-provider configurations where necessary;
- domains;
- secrets.

Development callback patterns must not be broadly added to production allowlists.

---

# 29. Alternatives Considered

## 29.1 Auth0

**Advantages**

- mature OAuth/OIDC;
- excellent documentation;
- broad federation;
- strong security features.

**Reasons not selected initially**

- additional foundational vendor;
- cost can grow with usage/features;
- AWS is already the proposed backend platform.

Auth0 remains a strong fallback if Cognito limitations become material.

---

## 29.2 Clerk

**Advantages**

- polished UI;
- strong developer experience;
- social login and session tooling.

**Reasons not selected initially**

- greater application-level SaaS coupling;
- Pachi still needs application-owned domain authorization;
- Cognito already fits the proposed AWS foundation.

---

## 29.3 Firebase Authentication

**Advantages**

- excellent native/mobile ecosystem;
- mature social login;
- proven scale.

**Reasons not selected**

- introduces another foundational cloud platform;
- Pachi's backend is already proposed on AWS.

---

## 29.4 Supabase Auth

**Advantages**

- good developer experience;
- social login;
- PostgreSQL-oriented platform.

**Reasons not selected**

Pachi's proposed production infrastructure is AWS-centered rather than Supabase-centered.

---

## 29.5 Auth.js as Primary Identity

**Advantages**

- excellent Next.js fit;
- flexible provider ecosystem.

**Reasons not selected as the primary identity platform**

Pachi also needs native Android/iOS credential and identity lifecycle management.

Auth.js may still be used in the web BFF implementation.

---

## 29.6 AWS Amplify Auth as Architectural Boundary

**Advantages**

- convenient Cognito integration;
- helpful client SDKs.

**Reasons not selected as the architecture boundary**

Pachi should depend primarily on standard OAuth/OIDC behavior.

Amplify may be used if it simplifies implementation without becoming a hard domain dependency.

---

## 29.7 Fully Custom Authentication

**Advantages**

- complete control.

**Reasons not selected**

Building password security, OAuth, federation, MFA, recovery, issuance, rotation, and revocation would create unnecessary security and maintenance risk.

---

## 29.8 Phone OTP as Primary Login

**Advantages**

- convenient on mobile;
- passwordless.

**Reasons not selected initially**

- recurring SMS cost;
- delivery uncertainty;
- SIM-swap risk;
- number recycling;
- carrier/sender requirements.

---

## 29.9 Passwordless Email OTP

**Advantages**

- no passwords;
- simple mental model.

**Reasons not selected initially**

- every login depends on timely email;
- more messaging dependency;
- established password/social flows are sufficient initially.

---

## 29.10 Passkeys as the Only Launch Method

**Advantages**

- phishing resistance;
- strong modern security.

**Reasons not selected initially**

Recovery expectations and device support vary.

The architecture should support passkeys later.

---

# 30. Consequences

## 30.1 Positive

- Pachi does not store passwords.
- Web and mobile share one standards-based identity source.
- Google and Apple federation normalize through Cognito.
- Domain authorization stays in Pachi.
- Mobile uses PKCE-compatible flows.
- Browser refresh credentials stay outside JavaScript.
- AWS identity aligns with the proposed backend cloud.
- Phone verification can be optimized for Cameroon separately.
- Future MFA/passkeys remain possible.

## 30.2 Negative

- Cognito configuration has complexity.
- Managed login provides less brand control than custom UI.
- Web BFF/session management adds server-side state.
- Account linking requires careful implementation.
- Phone verification needs a separate OTP service.
- Federated MFA semantics differ from local users.
- Multiple app clients/callbacks require disciplined environment management.

---

# 31. Risks and Mitigations

## Identity-provider lock-in

Mitigation:

- OAuth/OIDC;
- application-owned user IDs;
- issuer + subject mappings;
- domain authorization outside Cognito.

## Stolen refresh credential

Mitigation:

- rotation;
- secure storage;
- revocation;
- session registry;
- security notifications.

## Social account takeover through email matching

Mitigation:

- never auto-link solely by email;
- require explicit linking.

## Residual access-token validity after logout

Mitigation:

- short token lifetime;
- account-state checks;
- session/restriction checks for high-risk actions.

## SMS dependency

Mitigation:

- SMS is not the only login/recovery path;
- abstract provider;
- evaluate Cameroon delivery before selection.

## Privileged federated-user MFA gap

Mitigation:

- platform staff use local Cognito + TOTP;
- design step-up authentication before extending mandatory MFA to federated privileged users.

---

# 32. Open Decisions

### AUTH-OD-001 — Managed login branding

Is Cognito managed login acceptable for launch UX?

**Current recommendation:** Start with managed login; move to custom UI only if conversion or brand quality suffers materially.

### AUTH-OD-002 — SMS provider

Which provider offers acceptable OTP delivery, compliance, and cost for Cameroon?

**Current status:** Separate vendor decision.

### AUTH-OD-003 — Phone permission gates

Which Pachi permissions require verified phone in addition to verified email?

**Current status:** Align with `verification-model.md`.

### AUTH-OD-004 — Normal-user MFA

Should optional TOTP MFA ship in MVP?

**Current recommendation:** Add early if implementation cost is modest; platform staff require it.

### AUTH-OD-005 — Privileged-session duration

What refresh/session lifetime applies to moderators and platform administrators?

**Current status:** Security architecture decision.

### AUTH-OD-006 — Account-linking implementation

Which Cognito-supported server-side linking implementation will be used?

**Current status:** Resolve before social linking ships.

### AUTH-OD-007 — Web auth library

Should the Next.js BFF use:

- a standards-compliant OIDC library directly;
- Auth.js against Cognito;
- another reviewed session library?

**Current status:** Implementation decision.

---

# 33. Decisions Established by This ADR

If accepted:

1. Amazon Cognito User Pools is Pachi's initial identity provider.
2. PostgreSQL remains authoritative for domain authorization.
3. Pachi owns its immutable user ID.
4. Initial sign-in methods are email/password, Google, and Apple.
5. Phone verification is separate from primary authentication.
6. Phone-number login is deferred.
7. Web uses opaque server-side session cookies.
8. Native mobile uses Authorization Code + PKCE.
9. Mobile refresh credentials use secure platform storage.
10. Browser JavaScript does not persist refresh tokens.
11. The API uses access tokens, not ID tokens.
12. Access tokens are short-lived and refresh rotation is enabled.
13. Social accounts are never auto-merged solely by email.
14. Platform staff use stronger local authentication with TOTP MFA.
15. Recovery is auditable and does not use security questions.
16. Cognito Identity Pools are not initially used.

---

# 34. Acceptance Criteria

This ADR may move from **Proposed** to **Accepted** when:

- Cognito is accepted as the identity provider;
- expected Cognito cost is reviewed;
- managed-login UX is acceptable;
- Google/Apple developer requirements are understood;
- web BFF session architecture is accepted;
- mobile PKCE is accepted;
- phone verification is confirmed as separate from login;
- email policy aligns with `verification-model.md`;
- staff MFA policy is accepted;
- no known domain requirement conflicts with this strategy.

---

# 35. Follow-Up Work

After acceptance:

1. create Cognito infrastructure in AWS CDK;
2. define environment-specific app clients;
3. implement `users` and `auth_identities`;
4. implement API JWT validation;
5. implement web BFF sessions;
6. implement Expo OIDC/PKCE sign-in;
7. implement security audit events;
8. configure SES-backed production email;
9. configure Google federation;
10. configure Sign in with Apple;
11. create a separate SMS/OTP vendor decision;
12. align `verification-model.md` with final email/phone gates.

---

# 36. References

Implementation should be checked against current official documentation for:

- Amazon Cognito User Pools;
- Cognito managed login;
- Cognito Authorization Code + PKCE;
- Cognito refresh-token rotation and revocation;
- Cognito email/phone verification;
- Cognito account recovery;
- Cognito social identity providers;
- Cognito TOTP MFA;
- Expo AuthSession;
- Expo SecureStore;
- Apple App Store login-service requirements;
- Sign in with Apple.

Authentication platform capabilities and app-store rules change over time and must be rechecked during implementation and before production release.
