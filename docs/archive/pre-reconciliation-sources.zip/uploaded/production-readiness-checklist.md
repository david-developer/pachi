# Pachi — Production Readiness Checklist

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document defines the minimum operational and technical checks required before Pachi is exposed to real production users.  
> **Source Runbook:** `docs/03-operations/deployment-and-operations-runbook.md`  
> **Related Documents:**  
> - `docs/02-architecture/system-architecture.md`
> - `docs/02-architecture/adr/0001-technology-stack.md`
> - `docs/02-architecture/adr/0002-authentication-and-session-strategy.md`
> - `docs/02-architecture/adr/0003-aws-region-and-environment-topology.md`
> - `docs/02-architecture/adr/0004-maps-geocoding-and-location-services.md`
> - `docs/02-architecture/adr/0005-media-processing-and-storage-policy.md`
> - `docs/02-architecture/adr/0006-notification-email-sms-strategy.md`
> - `docs/03-operations/deployment-and-operations-runbook.md`

---

## 1. Purpose

This checklist is the final pre-launch gate for Pachi production.

It converts the deployment and operations runbook into a concrete set of checks that must be completed, reviewed, and accepted before real users and production data are allowed onto the system.

A checked box means:

```text
implemented
tested
verified
and documented where required
```

Do not mark an item complete based only on configuration intent.

---

## 2. Launch Gate Rules

Items are classified as:

```text
BLOCKER
REQUIRED
RECOMMENDED
```

### `BLOCKER`

Pachi must not launch until the item is complete.

### `REQUIRED`

Expected before launch unless there is an explicit documented exception.

### `RECOMMENDED`

Strongly preferred, but launch may proceed if the remaining risk is consciously accepted.

Any exception must include:

- reason;
- owner;
- risk;
- mitigation;
- target completion date.

---

# 3. Approval Summary

Before launch, record:

```text
Launch Candidate Version:
Git Commit:
API Image Digest:
Web Release:
Mobile Release:
Planned Launch Date:
Primary Operator:
Rollback Owner:
```

Final approvals:

- [ ] **BLOCKER** Engineering readiness approved
- [ ] **BLOCKER** Production operations readiness approved
- [ ] **BLOCKER** Security-critical launch checks approved
- [ ] **BLOCKER** Backup and restore readiness approved
- [ ] **BLOCKER** No unresolved SEV-1 or SEV-2 production-readiness issue exists

---

# 4. Architecture and Decision Readiness

- [ ] **BLOCKER** `system-architecture.md` reflects the actual implementation
- [ ] **BLOCKER** No known implementation conflicts with approved product/domain rules
- [ ] **BLOCKER** Critical architecture ADRs required for launch are accepted or explicitly approved as implementation baseline
- [ ] **REQUIRED** Open ADR decisions that remain deferred are documented
- [ ] **REQUIRED** No unresolved architecture ambiguity affects security, data durability, authentication, or authorization
- [ ] **REQUIRED** Runtime component ownership is documented
- [ ] **REQUIRED** External-provider dependencies are documented

---

# 5. Repository and Release Integrity

- [ ] **BLOCKER** Production code is committed to the canonical Git repository
- [ ] **BLOCKER** Production release maps to a specific Git commit SHA
- [ ] **BLOCKER** Production container image is immutable and traceable to that commit
- [ ] **REQUIRED** Dependency lockfiles are committed
- [ ] **REQUIRED** No local-only uncommitted changes are required for production
- [ ] **REQUIRED** Production configuration is not manually dependent on a developer machine
- [ ] **REQUIRED** Release notes or deployment notes exist for launch candidate

---

# 6. CI Readiness

- [ ] **BLOCKER** GitHub Actions CI is enabled
- [ ] **BLOCKER** Production candidate passes lint
- [ ] **BLOCKER** Production candidate passes type checking
- [ ] **BLOCKER** Production candidate passes unit tests
- [ ] **BLOCKER** Production candidate passes required integration tests
- [ ] **BLOCKER** Production candidate builds successfully
- [ ] **REQUIRED** Database migration validation runs in CI
- [ ] **REQUIRED** Security/dependency checks are enabled where configured
- [ ] **REQUIRED** CI failure prevents deployment
- [ ] **REQUIRED** CI logs do not expose secrets

---

# 7. CD / Deployment Readiness

- [ ] **BLOCKER** Staging deployment pipeline works end to end
- [ ] **BLOCKER** Production deployment pipeline exists
- [ ] **BLOCKER** Production deployment requires explicit approval
- [ ] **BLOCKER** GitHub uses AWS OIDC rather than long-lived AWS deployment keys
- [ ] **BLOCKER** Staging and production use separate deployment IAM roles
- [ ] **REQUIRED** Production IAM role trust policy is scoped to expected repository/workflow/environment
- [ ] **REQUIRED** ECS health checks block unhealthy rollout
- [ ] **REQUIRED** Deployment result is auditable
- [ ] **REQUIRED** Last known-good image is identified before launch
- [ ] **REQUIRED** Rollback procedure has been tested in staging

---

# 8. Environment Isolation

- [ ] **BLOCKER** Staging and production are in separate AWS accounts
- [ ] **BLOCKER** Production does not share its RDS database with staging
- [ ] **BLOCKER** Production does not share Cognito User Pool with staging
- [ ] **BLOCKER** Production does not share S3 buckets with staging
- [ ] **BLOCKER** Production does not share SQS queues with staging
- [ ] **BLOCKER** Production secrets are separate from staging
- [ ] **REQUIRED** Production KMS keys are environment-specific where required
- [ ] **REQUIRED** Staging cannot accidentally contact production users through normal test flows

---

# 9. AWS Account Security

- [ ] **BLOCKER** Root account MFA is enabled
- [ ] **BLOCKER** Root credentials are not used for normal operations
- [ ] **BLOCKER** Named operator identities are used for production access
- [ ] **BLOCKER** Production operator access requires MFA
- [ ] **REQUIRED** Least-privilege IAM roles are in place
- [ ] **REQUIRED** Shared administrator credentials do not exist
- [ ] **REQUIRED** Unused IAM users/access keys are removed
- [ ] **REQUIRED** Billing alerts are enabled
- [ ] **REQUIRED** AWS Budgets are configured
- [ ] **RECOMMENDED** Organization-level security policies are reviewed

---

# 10. Region and Network Readiness

- [ ] **BLOCKER** Final AWS production region is confirmed
- [ ] **BLOCKER** Cameroon latency benchmark has been completed if required by ADR 0003
- [ ] **BLOCKER** Production VPC exists
- [ ] **BLOCKER** Production application runs in private application subnets
- [ ] **BLOCKER** Production database runs in isolated database subnets
- [ ] **BLOCKER** Production RDS has no public endpoint
- [ ] **BLOCKER** ALB is the approved public API ingress
- [ ] **BLOCKER** ECS tasks accept ingress only from approved security groups
- [ ] **REQUIRED** TLS certificates are valid
- [ ] **REQUIRED** Public HTTP redirects to HTTPS or is disabled
- [ ] **REQUIRED** Outbound access/NAT topology is documented
- [ ] **REQUIRED** VPC endpoint strategy is reviewed for high-volume AWS services

---

# 11. DNS Readiness

- [ ] **BLOCKER** Production web domain resolves correctly
- [ ] **BLOCKER** Production API domain resolves correctly
- [ ] **REQUIRED** Media/CDN domain resolves correctly
- [ ] **REQUIRED** Authentication domain resolves correctly where used
- [ ] **REQUIRED** DNS ownership/access is documented
- [ ] **REQUIRED** DNS TTL values are appropriate for launch and rollback
- [ ] **REQUIRED** DNS change procedure is documented

---

# 12. Production Compute

- [ ] **BLOCKER** ECS production cluster is healthy
- [ ] **BLOCKER** API service runs successfully
- [ ] **BLOCKER** At least two production API tasks run before public launch
- [ ] **BLOCKER** API tasks span multiple Availability Zones
- [ ] **REQUIRED** CPU and memory sizing are reasonable for expected launch load
- [ ] **REQUIRED** ECS autoscaling policy is configured or intentionally deferred
- [ ] **REQUIRED** Worker service is healthy if independently deployed
- [ ] **REQUIRED** Application containers run without unnecessary privileged permissions

---

# 13. Health Endpoints

- [ ] **BLOCKER** `/liveness` works
- [ ] **BLOCKER** `/readiness` works
- [ ] **BLOCKER** ALB health checks use appropriate readiness behavior
- [ ] **REQUIRED** Readiness checks critical dependencies without depending on optional providers
- [ ] **REQUIRED** Health endpoints do not expose sensitive configuration

---

# 14. Database Readiness

- [ ] **BLOCKER** Production PostgreSQL is deployed through Amazon RDS
- [ ] **BLOCKER** PostGIS is installed and verified
- [ ] **BLOCKER** Production RDS is Multi-AZ
- [ ] **BLOCKER** Database encryption at rest is enabled
- [ ] **BLOCKER** TLS database connections are enforced/used
- [ ] **BLOCKER** Database security group accepts connections only from approved application resources
- [ ] **BLOCKER** Production schema migrations are current
- [ ] **REQUIRED** Important unique/foreign-key/check constraints are present
- [ ] **REQUIRED** Required indexes exist
- [ ] **REQUIRED** Database connection pool settings are reviewed
- [ ] **REQUIRED** Database free storage has launch headroom
- [ ] **REQUIRED** Critical geospatial queries are tested

---

# 15. Migration Readiness

- [ ] **BLOCKER** Production migrations are version-controlled
- [ ] **BLOCKER** Migrations do not run independently from every application container
- [ ] **BLOCKER** Launch migrations have been tested against staging
- [ ] **BLOCKER** High-risk migrations have explicit recovery plans
- [ ] **REQUIRED** Lock/runtime impact of significant migrations has been reviewed
- [ ] **REQUIRED** Expand/contract strategy is used where compatibility spans releases
- [ ] **REQUIRED** Production migration execution is auditable
- [ ] **REQUIRED** Post-migration validation query/check exists for critical migrations

---

# 16. Backup Readiness

- [ ] **BLOCKER** RDS automated backups are enabled
- [ ] **BLOCKER** RDS backup retention is configured
- [ ] **BLOCKER** Point-in-time recovery is enabled
- [ ] **BLOCKER** At least one production-like restore test has succeeded
- [ ] **BLOCKER** Backup failure monitoring is enabled
- [ ] **REQUIRED** Cross-region backup replication/copy is configured
- [ ] **REQUIRED** Critical backup copy exists outside the production account
- [ ] **REQUIRED** Backup retention matches current operations policy
- [ ] **REQUIRED** S3 versioning is enabled on critical buckets
- [ ] **RECOMMENDED** Backup immutability/Vault Lock is configured

---

# 17. Restore Readiness

- [ ] **BLOCKER** Database restore procedure is documented
- [ ] **BLOCKER** Operator knows how to perform PITR
- [ ] **BLOCKER** Restored database can be connected to the application
- [ ] **BLOCKER** PostGIS works after restore
- [ ] **REQUIRED** Restore verification queries/checks are documented
- [ ] **REQUIRED** Original failed database is preserved during parallel recovery where possible
- [ ] **REQUIRED** Quarterly restore-testing cadence is scheduled

---

# 18. Disaster Recovery

- [ ] **BLOCKER** Backup/DR region is defined
- [ ] **BLOCKER** Regional disaster procedure is documented
- [ ] **REQUIRED** CDK can recreate core infrastructure in the DR region
- [ ] **REQUIRED** Cross-region database recovery point is available
- [ ] **REQUIRED** Required private-media recovery path is documented
- [ ] **REQUIRED** DNS failover/switch procedure is documented
- [ ] **REQUIRED** Current DR RTO/RPO targets are recorded
- [ ] **RECOMMENDED** Regional recovery exercise has been rehearsed before significant scale

---

# 19. Secrets Readiness

- [ ] **BLOCKER** Production secrets are stored in Secrets Manager or approved parameter storage
- [ ] **BLOCKER** No production secrets exist in Git history
- [ ] **BLOCKER** No production secrets are embedded in Docker images
- [ ] **BLOCKER** No backend secrets are exposed in web/mobile bundles
- [ ] **BLOCKER** Production `.env` files are not committed
- [ ] **REQUIRED** Secret access follows least privilege
- [ ] **REQUIRED** Secret rotation procedure is documented
- [ ] **REQUIRED** External provider credentials can be rotated without source-code changes

---

# 20. Authentication Readiness

- [ ] **BLOCKER** Production Cognito User Pool exists
- [ ] **BLOCKER** Production web and mobile app clients are separate
- [ ] **BLOCKER** Production callback/logout URLs are correct
- [ ] **BLOCKER** Authorization Code + PKCE works
- [ ] **BLOCKER** Mobile client contains no client secret
- [ ] **BLOCKER** Web session cookie is `HttpOnly` and `Secure`
- [ ] **BLOCKER** API validates token signature, issuer, expiry, and token use
- [ ] **BLOCKER** Cognito identity resolves to Pachi user correctly
- [ ] **BLOCKER** Suspended/restricted Pachi users cannot bypass application authorization with a valid token
- [ ] **REQUIRED** User-existence suppression is configured where applicable
- [ ] **REQUIRED** Refresh-token rotation/revocation behavior is verified
- [ ] **REQUIRED** Logout current device works
- [ ] **REQUIRED** Logout all sessions works
- [ ] **REQUIRED** Account recovery works
- [ ] **REQUIRED** Platform-staff MFA works before staff accounts are used

---

# 21. Authorization Readiness

- [ ] **BLOCKER** Server-side authorization is enforced
- [ ] **BLOCKER** Frontend-only role checks are not treated as authoritative
- [ ] **BLOCKER** Default-deny behavior exists for protected operations
- [ ] **BLOCKER** Organization membership scope is enforced
- [ ] **BLOCKER** Verification requirements affect protected actions correctly
- [ ] **BLOCKER** Moderation restrictions affect permissions immediately
- [ ] **BLOCKER** Ownership/resource-scope checks are tested
- [ ] **REQUIRED** Privileged actions are audited
- [ ] **REQUIRED** Authorization test coverage includes negative cases

---

# 22. Email Readiness

- [ ] **BLOCKER** SES production access is approved
- [ ] **BLOCKER** Production sending domain is verified
- [ ] **BLOCKER** DKIM is configured
- [ ] **BLOCKER** SPF is configured
- [ ] **REQUIRED** DMARC is configured
- [ ] **BLOCKER** Transactional email can be delivered successfully
- [ ] **BLOCKER** Bounce handling works
- [ ] **BLOCKER** Complaint handling works
- [ ] **REQUIRED** SES quotas are sufficient for launch
- [ ] **REQUIRED** English templates are tested
- [ ] **REQUIRED** French templates are tested
- [ ] **REQUIRED** Staging cannot accidentally send unrestricted production email

---

# 23. SMS / OTP Readiness

- [ ] **BLOCKER** Production SMS account/access is approved
- [ ] **BLOCKER** Cameroon `+237` delivery is tested
- [ ] **BLOCKER** Phone numbers are normalized to E.164
- [ ] **BLOCKER** OTP generation is cryptographically secure
- [ ] **BLOCKER** OTP values are never logged
- [ ] **BLOCKER** OTP expiry works
- [ ] **BLOCKER** Resend cooldown works
- [ ] **BLOCKER** Attempt limits work
- [ ] **BLOCKER** Per-phone/IP/device rate limiting works
- [ ] **BLOCKER** SMS destination-country controls are configured
- [ ] **BLOCKER** SMS spending threshold/alerts are configured
- [ ] **REQUIRED** Sender ID behavior is confirmed on real Cameroon networks
- [ ] **REQUIRED** English OTP template is tested
- [ ] **REQUIRED** French OTP template is tested
- [ ] **REQUIRED** Delivery/failure events are captured
- [ ] **REQUIRED** At least one alternative SMS provider has been benchmarked or explicitly deferred with risk recorded

---

# 24. Push Notification Readiness

- [ ] **BLOCKER** Android push notifications work in a production-like build
- [ ] **BLOCKER** iOS push notifications work in a production-like build
- [ ] **BLOCKER** Push tokens are associated with user/device installation
- [ ] **BLOCKER** Invalid device-token receipts disable obsolete endpoints
- [ ] **BLOCKER** Push payloads do not expose sensitive data
- [ ] **REQUIRED** Push deep links resolve correctly
- [ ] **REQUIRED** Deep-linked screens still authorize server-side
- [ ] **REQUIRED** User can decline push permission without losing core product access

---

# 25. Notification Pipeline

- [ ] **BLOCKER** Domain notifications use an asynchronous queue
- [ ] **BLOCKER** Transactional outbox prevents lost post-commit notifications
- [ ] **BLOCKER** Notification delivery is idempotent
- [ ] **BLOCKER** Retry behavior distinguishes retryable and permanent failures
- [ ] **BLOCKER** Dead-letter queue exists
- [ ] **BLOCKER** DLQ monitoring exists
- [ ] **REQUIRED** In-app notification history works
- [ ] **REQUIRED** User preferences suppress optional channels correctly
- [ ] **REQUIRED** Mandatory security notifications cannot be disabled accidentally

---

# 26. Maps and Location Readiness

- [ ] **BLOCKER** Production Google Maps credentials are configured
- [ ] **BLOCKER** Web key is restricted by approved referrers/APIs
- [ ] **BLOCKER** Android key is restricted by package/signing identity
- [ ] **BLOCKER** iOS key is restricted by bundle identifier
- [ ] **BLOCKER** Geocoding/place-search usage is restricted to supported production flows
- [ ] **BLOCKER** Property pin confirmation works
- [ ] **BLOCKER** PostGIS search does not depend on Google availability
- [ ] **BLOCKER** Canonical Pachi city/neighborhood records exist for launch locations
- [ ] **REQUIRED** Cameroon geocoding benchmark is complete
- [ ] **REQUIRED** Public exact-location privacy mode is tested
- [ ] **REQUIRED** Map API quotas and billing alerts are configured
- [ ] **REQUIRED** Reverse geocoding is not triggered continuously on map movement

---

# 27. Public Media Readiness

- [ ] **BLOCKER** Public media S3 bucket is private
- [ ] **BLOCKER** S3 Block Public Access is enabled
- [ ] **BLOCKER** CloudFront can read approved public derivatives
- [ ] **BLOCKER** Public images are not served from a broadly public S3 bucket
- [ ] **BLOCKER** Direct-to-S3 upload authorization checks ownership
- [ ] **BLOCKER** Arbitrary bucket/key upload is prevented
- [ ] **BLOCKER** Uploaded media enters quarantine
- [ ] **BLOCKER** File type is validated server-side
- [ ] **BLOCKER** Public images are decoded/re-encoded
- [ ] **BLOCKER** GPS/EXIF metadata is stripped from public derivatives
- [ ] **BLOCKER** Image resizing/compression works
- [ ] **BLOCKER** Processing failure does not expose raw original
- [ ] **REQUIRED** Public image cache behavior works
- [ ] **REQUIRED** Orphan upload cleanup exists
- [ ] **REQUIRED** Media processing DLQ exists and is monitored

---

# 28. Verification Evidence Readiness

- [ ] **BLOCKER** Verification evidence uses a separate private bucket/security domain
- [ ] **BLOCKER** Verification evidence is not reachable through public CloudFront
- [ ] **BLOCKER** Evidence upload requires authorized active verification case
- [ ] **BLOCKER** Evidence access requires server authorization
- [ ] **BLOCKER** Evidence uses short-lived signed URLs
- [ ] **BLOCKER** Sensitive evidence access is audited
- [ ] **BLOCKER** Verification documents undergo file/malware validation
- [ ] **BLOCKER** Original evidence is preserved according to verification policy
- [ ] **BLOCKER** Evidence retention period is approved before real identity documents are collected
- [ ] **REQUIRED** Safe preview behavior is tested
- [ ] **REQUIRED** Deletion/hold behavior is tested

---

# 29. Domain Lifecycle Readiness

- [ ] **BLOCKER** Listing lifecycle transitions are enforced server-side
- [ ] **BLOCKER** Membership lifecycle transitions are enforced server-side
- [ ] **BLOCKER** Verification lifecycle transitions are enforced server-side
- [ ] **BLOCKER** Interaction lifecycle transitions are enforced server-side
- [ ] **BLOCKER** Review lifecycle transitions are enforced server-side
- [ ] **BLOCKER** Moderation actions preserve historical state
- [ ] **BLOCKER** Invalid transitions return explicit errors
- [ ] **REQUIRED** Concurrent transition behavior is tested
- [ ] **REQUIRED** Idempotent transition behavior is tested

---

# 30. Listing Readiness

- [ ] **BLOCKER** Draft listing creation works
- [ ] **BLOCKER** Publication authorization works
- [ ] **BLOCKER** Provider verification gates publication
- [ ] **BLOCKER** Property-authority verification gates publication
- [ ] **BLOCKER** Moderation restrictions block publication where required
- [ ] **BLOCKER** Paused/closed/under-moderation listings behave correctly
- [ ] **BLOCKER** Archived listings cannot create new interactions
- [ ] **REQUIRED** Search excludes non-public states
- [ ] **REQUIRED** Public location privacy is respected

---

# 31. Interaction Readiness

- [ ] **BLOCKER** Viewing request creation is authorized
- [ ] **BLOCKER** Provider response is scope-controlled
- [ ] **BLOCKER** Scheduling works
- [ ] **BLOCKER** Cancellation preserves history
- [ ] **BLOCKER** Completion is not inferred only from elapsed time
- [ ] **BLOCKER** No-show state cannot be forged by unrelated users
- [ ] **BLOCKER** Completion creates review eligibility exactly once
- [ ] **REQUIRED** Disputed completion enters moderation flow
- [ ] **REQUIRED** Existing interactions survive listing closure correctly

---

# 32. Review Readiness

- [ ] **BLOCKER** Only qualifying interactions create review eligibility
- [ ] **BLOCKER** Self-review is impossible
- [ ] **BLOCKER** Duplicate review creation is prevented
- [ ] **BLOCKER** Review rating validation works
- [ ] **BLOCKER** Hidden/removed reviews do not affect public aggregates
- [ ] **BLOCKER** Review moderation is auditable
- [ ] **REQUIRED** Review edit history is preserved where editing is enabled
- [ ] **REQUIRED** Invalidated interactions trigger related review reevaluation

---

# 33. Moderation Readiness

- [ ] **BLOCKER** User reports create moderation records/cases
- [ ] **BLOCKER** Moderation actions require privileged authorization
- [ ] **BLOCKER** Moderators cannot silently rewrite audit history
- [ ] **BLOCKER** Capability-specific restrictions work
- [ ] **BLOCKER** Interaction invalidation preserves history
- [ ] **BLOCKER** Review removal preserves historical record
- [ ] **REQUIRED** Moderation case assignment/state flow works
- [ ] **REQUIRED** Appeals/reversals are auditable where supported

---

# 34. Audit Readiness

- [ ] **BLOCKER** Verification trust decisions are audited
- [ ] **BLOCKER** Moderation actions are audited
- [ ] **BLOCKER** Privileged evidence access is audited
- [ ] **BLOCKER** Session/security recovery events are audited
- [ ] **BLOCKER** Review moderation is audited
- [ ] **BLOCKER** Interaction invalidation is audited
- [ ] **REQUIRED** Audit events are append-oriented
- [ ] **REQUIRED** Ordinary users cannot mutate audit history
- [ ] **REQUIRED** Audit logs do not duplicate secrets/sensitive evidence unnecessarily

---

# 35. Observability Readiness

- [ ] **BLOCKER** Structured JSON logging is enabled
- [ ] **BLOCKER** Request IDs are present
- [ ] **BLOCKER** Trace IDs are propagated where applicable
- [ ] **BLOCKER** CloudWatch receives production runtime logs
- [ ] **BLOCKER** Core production metrics are visible
- [ ] **BLOCKER** Sentry receives web/mobile errors
- [ ] **REQUIRED** OpenTelemetry instrumentation exists for critical backend flows
- [ ] **REQUIRED** External provider latency/error metrics are visible
- [ ] **REQUIRED** Sensitive values are redacted from telemetry

---

# 36. Critical Alert Readiness

Verify alerts for:

- [ ] **BLOCKER** API unavailable
- [ ] **BLOCKER** ALB has no healthy targets
- [ ] **BLOCKER** production RDS unavailable
- [ ] **BLOCKER** database storage critically low
- [ ] **BLOCKER** elevated production 5xx rate
- [ ] **BLOCKER** backup failure
- [ ] **BLOCKER** SQS/DLQ critical backlog
- [ ] **REQUIRED** notification provider failure spike
- [ ] **REQUIRED** media processing failure spike
- [ ] **REQUIRED** SMS spend anomaly
- [ ] **REQUIRED** deployment failure
- [ ] **REQUIRED** authentication failure spike

---

# 37. Alert Delivery

- [ ] **BLOCKER** Alerts reach a monitored destination
- [ ] **BLOCKER** Critical alerts do not depend only on manually checking AWS console
- [ ] **REQUIRED** Alert owner is known
- [ ] **REQUIRED** Alert severity maps to incident severity
- [ ] **REQUIRED** Test alert has been triggered successfully

---

# 38. Incident Response Readiness

- [ ] **BLOCKER** SEV-1 through SEV-4 model is accepted
- [ ] **BLOCKER** Incident owner/lead role is defined
- [ ] **BLOCKER** Operator knows how to freeze deployments
- [ ] **BLOCKER** Rollback procedure is available
- [ ] **BLOCKER** Secret-exposure procedure is available
- [ ] **BLOCKER** Database-corruption procedure is available
- [ ] **BLOCKER** Backup-restore procedure is available
- [ ] **REQUIRED** Provider-outage procedures are documented
- [ ] **REQUIRED** Post-incident review format is defined

---

# 39. Application Rollback Readiness

- [ ] **BLOCKER** Previous known-good image is retained
- [ ] **BLOCKER** Operator can redeploy previous ECS task definition/image
- [ ] **BLOCKER** Previous release compatibility with current database is understood
- [ ] **BLOCKER** Rollback smoke tests are defined
- [ ] **REQUIRED** Rollback was tested in staging
- [ ] **REQUIRED** Rollback action produces an operational audit record

---

# 40. Configuration Rollback Readiness

- [ ] **BLOCKER** Last known-good critical configuration can be restored
- [ ] **BLOCKER** Secret rotation/rollback path is understood
- [ ] **REQUIRED** Environment-specific config changes are versioned where possible
- [ ] **REQUIRED** Configuration changes are traceable

---

# 41. Infrastructure Rollback Readiness

- [ ] **REQUIRED** CDK deployment rollback behavior is understood
- [ ] **REQUIRED** CloudFormation failure states can be investigated
- [ ] **REQUIRED** Emergency manual changes have a reconciliation procedure
- [ ] **REQUIRED** Operator knows how to detect infrastructure drift

---

# 42. Performance Readiness

- [ ] **BLOCKER** Core API endpoints meet acceptable launch latency in staging/production-like testing
- [ ] **BLOCKER** Listing search performs acceptably with representative data
- [ ] **BLOCKER** PostGIS location search is tested
- [ ] **REQUIRED** Image derivatives load acceptably on mobile networks
- [ ] **REQUIRED** Basic concurrency/load test has been run
- [ ] **REQUIRED** Database connection limits have launch headroom
- [ ] **RECOMMENDED** Slow-query monitoring is enabled

---

# 43. Capacity Readiness

- [ ] **BLOCKER** Production RDS storage has sufficient headroom
- [ ] **BLOCKER** ECS task CPU/memory has headroom
- [ ] **REQUIRED** SES quota supports launch volume
- [ ] **REQUIRED** SMS spend/throughput settings support expected OTP volume
- [ ] **REQUIRED** Expo push throughput is sufficient for expected launch volume
- [ ] **REQUIRED** SQS worker throughput is sufficient for expected media/notification volume

---

# 44. Cost Readiness

- [ ] **BLOCKER** AWS Budgets are configured
- [ ] **BLOCKER** SMS spending alerts/limits are configured
- [ ] **BLOCKER** Google Maps billing alerts/quotas are configured
- [ ] **REQUIRED** S3/CloudFront cost expectations are reviewed
- [ ] **REQUIRED** NAT gateway cost is understood
- [ ] **REQUIRED** RDS Multi-AZ cost is reviewed
- [ ] **REQUIRED** Backup storage cost is reviewed
- [ ] **RECOMMENDED** Cost dashboard exists

---

# 45. Privacy and Data Handling Readiness

- [ ] **BLOCKER** Exact private property location is not exposed unintentionally
- [ ] **BLOCKER** Verification evidence cannot be publicly accessed
- [ ] **BLOCKER** Public images strip unnecessary GPS metadata
- [ ] **BLOCKER** Sensitive data is excluded from logs
- [ ] **BLOCKER** Account deletion behavior is defined
- [ ] **BLOCKER** Verification evidence retention is defined
- [ ] **REQUIRED** Backup-deletion behavior is documented
- [ ] **REQUIRED** Data-residency region decision has been reviewed
- [ ] **REQUIRED** Production privacy/data-retention policy aligns with implementation

---

# 46. Abuse and Rate-Limit Readiness

- [ ] **BLOCKER** Authentication endpoints are rate-limited
- [ ] **BLOCKER** OTP endpoints are rate-limited
- [ ] **BLOCKER** Upload authorization endpoints are rate-limited where needed
- [ ] **BLOCKER** Report/review abuse paths have controls
- [ ] **REQUIRED** Suspicious SMS usage is monitored
- [ ] **REQUIRED** Excessive upload behavior is constrained
- [ ] **REQUIRED** Provider/API quotas prevent runaway external cost

---

# 47. Mobile Production Readiness

- [ ] **BLOCKER** Android production build succeeds
- [ ] **BLOCKER** iOS production build succeeds
- [ ] **BLOCKER** Production API/auth URLs are correct
- [ ] **BLOCKER** Production map credentials are correct
- [ ] **BLOCKER** Push notifications work
- [ ] **BLOCKER** SecureStore session behavior is tested
- [ ] **BLOCKER** Logout clears mobile credentials correctly
- [ ] **REQUIRED** App handles expired/revoked sessions cleanly
- [ ] **REQUIRED** Upload retry behavior is tested
- [ ] **REQUIRED** Deep links are tested
- [ ] **REQUIRED** Crash reporting is enabled

---

# 48. Web Production Readiness

- [ ] **BLOCKER** Production Next.js deployment succeeds
- [ ] **BLOCKER** Production API integration works
- [ ] **BLOCKER** Authentication callback flow works
- [ ] **BLOCKER** Session cookie security attributes are correct
- [ ] **BLOCKER** CSRF protections work
- [ ] **BLOCKER** Public listing pages render correctly
- [ ] **BLOCKER** SEO metadata exists for public listing pages where required
- [ ] **REQUIRED** Error reporting is enabled
- [ ] **REQUIRED** Map lazy-loading behavior works
- [ ] **REQUIRED** Responsive behavior is validated

---

# 49. Operational Smoke Test

Before launch, run a full end-to-end smoke test.

Minimum sequence:

- [ ] Create a production test user
- [ ] Verify email
- [ ] Verify phone
- [ ] Sign in on web
- [ ] Sign in on mobile
- [ ] Create provider profile
- [ ] Create property
- [ ] Confirm map location
- [ ] Upload property images
- [ ] Verify images process successfully
- [ ] Create listing
- [ ] Publish listing
- [ ] Confirm listing appears in search
- [ ] Request viewing from second account
- [ ] Accept/schedule viewing
- [ ] Complete interaction
- [ ] Confirm review eligibility
- [ ] Submit review
- [ ] Confirm notification delivery
- [ ] Confirm audit history
- [ ] Exercise one moderation/report flow
- [ ] Log out and sign back in

Use only controlled test accounts and clearly marked production test data.

---

# 50. Failure Smoke Test

Before launch, verify at least:

- [ ] Invalid auth token rejected
- [ ] Suspended user restricted
- [ ] Unauthorized organization access rejected
- [ ] Unverified provider cannot publish
- [ ] Missing property authority blocks publication
- [ ] Invalid listing transition rejected
- [ ] Duplicate review rejected
- [ ] Invalid upload rejected
- [ ] Private evidence URL expires
- [ ] OTP attempt limit works
- [ ] Push invalid-token handling works
- [ ] Notification retry works
- [ ] DLQ receives exhausted job
- [ ] Rollback works in staging

---

# 51. Launch-Day Operational Readiness

- [ ] **BLOCKER** Operator is available during launch
- [ ] **BLOCKER** Monitoring dashboards are open/accessible
- [ ] **BLOCKER** Critical alerting is active
- [ ] **BLOCKER** Backup status checked immediately before launch
- [ ] **BLOCKER** No high-risk deployment is pending
- [ ] **BLOCKER** Last known-good release is identified
- [ ] **REQUIRED** External provider status pages/health are checked
- [ ] **REQUIRED** SMS spend/map quota dashboards are accessible
- [ ] **REQUIRED** Incident runbook is accessible

---

# 52. Launch Freeze Conditions

Do not launch if any of the following is true:

```text
production database backup unhealthy
restore procedure untested
critical auth path failing
authorization bypass known
verification evidence publicly reachable
production secrets exposed
SEV-1 / SEV-2 unresolved
rollback path unavailable
database migration state uncertain
critical monitoring unavailable
```

---

# 53. Conditional Launch Exceptions

If a `REQUIRED` item is intentionally deferred, record:

```text
Checklist Item:
Reason:
Risk:
Mitigation:
Owner:
Target Date:
Approved By:
```

`BLOCKER` items require explicit architecture/operations reclassification before launch; they should not simply be waived informally.

---

# 54. Launch Approval Record

Complete immediately before launch:

```text
Launch Version:
Git SHA:
API Image Digest:
Web Release:
Android Version:
iOS Version:
Database Migration Version:
Launch Time:
Operator:
Approver:
Known Exceptions:
```

Approvals:

- [ ] Engineering approved
- [ ] Operations approved
- [ ] Security-critical checks approved
- [ ] Backup/restore checks approved
- [ ] Launch authorized

---

# 55. Post-Launch Verification

Within the first production operating window, verify:

- [ ] API error rate normal
- [ ] API latency normal
- [ ] RDS health normal
- [ ] RDS storage normal
- [ ] ECS tasks stable
- [ ] SQS backlog normal
- [ ] DLQs empty or understood
- [ ] SES bounce/complaint rate normal
- [ ] SMS delivery rate acceptable
- [ ] SMS spend normal
- [ ] Push failures normal
- [ ] Media processing latency normal
- [ ] Google Maps usage/cost normal
- [ ] No unexpected authorization failures
- [ ] No suspicious security activity
- [ ] Backup completed after launch

---

# 56. First-Week Review

After the first week of live use, review:

- production incidents;
- slow queries;
- provider failures;
- SMS delivery performance;
- email bounce/complaint data;
- push-token failures;
- media-processing backlog;
- map/geocoding failures;
- authentication recovery issues;
- moderation/report volume;
- infrastructure cost;
- false-positive alerts;
- missing alerts.

Update:

- runbook;
- architecture docs;
- thresholds;
- backlog;

based on evidence.

---

# 57. Definition of Ready for Production

Pachi is considered ready for public production only when:

1. all `BLOCKER` items are complete;
2. unresolved `REQUIRED` items have explicit approved exceptions;
3. production deployment has succeeded;
4. backup and restore have been tested;
5. rollback has been tested;
6. critical monitoring and alerting are active;
7. security-sensitive workflows have been tested;
8. end-to-end production smoke tests pass;
9. no known critical architecture/domain conflict remains;
10. launch ownership is explicit.

