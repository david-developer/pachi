# Pachi — Lifecycle States

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document is the primary source of truth for lifecycle states and valid state transitions for listings, organization memberships, verification cases, and marketplace interactions.  
> **Related Documents:**  
> - `docs/00-product/product-specification.md`
> - `docs/01-domain/domain-model.md`
> - `docs/01-domain/roles-and-permissions.md`
> - `docs/01-domain/verification-model.md`
> - `docs/01-domain/review-system.md`
> - `docs/04-business-rules/listing-rules.md`
> - `docs/04-business-rules/interaction-rules.md`
> - `docs/04-business-rules/review-rules.md`
> - `docs/04-business-rules/moderation-rules.md`

---

## 1. Purpose

This document defines the lifecycle state machines used by Pachi for:

- property listings;
- organization memberships;
- verification cases;
- marketplace interactions.

A lifecycle state represents the current business condition of an entity.

State transitions are business events, not arbitrary field updates.

The backend must enforce valid transitions. Clients may request transitions, but they must not directly set protected state values without server-side validation.

---

## 2. Lifecycle Design Principles

### 2.1 Explicit states

Important business states must be represented explicitly.

Avoid inferring lifecycle state from combinations of unrelated fields where a dedicated state is clearer.

### 2.2 Valid transitions only

An entity may move only through transitions defined in this document or a more specialized authoritative document.

Invalid transitions must be rejected.

### 2.3 Transitions are permission-aware

A valid transition may still be denied if the actor lacks permission.

For example:

- a listing may be technically eligible to move from `DRAFT` to `PUBLISHED`;
- the request must still fail if the actor lacks listing-publication permission or required verification.

### 2.4 Transitions are condition-aware

A transition may require additional business conditions.

Examples:

- required listing fields are complete;
- verification requirements are satisfied;
- membership invitation has not expired;
- an interaction participant is authorized;
- no moderation restriction prevents the action.

### 2.5 State history must be preserved where important

For sensitive entities, the system should retain enough history to answer:

- what changed;
- when it changed;
- who initiated the change;
- why it changed;
- what the previous state was.

This may be implemented with audit records, transition history, event records, or a combination.

### 2.6 Terminal does not always mean deleted

A terminal state means no further normal business transitions are expected.

Terminal entities may still remain stored for:

- history;
- auditing;
- reporting;
- dispute handling;
- analytics;
- legal or operational requirements.

### 2.7 Deletion is separate from lifecycle state

Soft deletion, archival, anonymization, and physical deletion are storage/data-retention concerns.

They should not be used as substitutes for business lifecycle states.

---

# 3. Listing Lifecycle

## 3.1 Scope

This lifecycle applies to a marketplace listing that exposes a property or housing offering to seekers.

A property may exist independently from a published listing.

The listing lifecycle should not be used as the property lifecycle unless the domain model explicitly says otherwise.

---

## 3.2 Listing States

### `DRAFT`

The listing exists but is not publicly visible.

Typical characteristics:

- incomplete content is allowed;
- provider or authorized organization members may edit it;
- it does not appear in public search;
- it cannot receive normal public marketplace traffic.

This is the default initial state for a newly created listing.

### `PENDING_REVIEW`

The listing has been submitted for a review process but is not yet publicly visible.

This state is used only if Pachi requires listing review, moderation review, or automated/manual approval before publication.

Typical characteristics:

- publication requirements have been submitted;
- editing may be restricted or may return the listing to `DRAFT`;
- public search visibility is disabled.

If Pachi ultimately allows eligible providers to publish immediately, this state may be unused for standard listings but retained for exceptional or moderated cases.

### `PUBLISHED`

The listing is publicly active.

Typical characteristics:

- visible in public discovery surfaces;
- searchable and filterable;
- eligible users may contact the provider;
- eligible users may begin supported marketplace interactions;
- provider may update allowed listing fields;
- publication requirements must continue to be satisfied.

### `PAUSED`

The listing is temporarily unavailable to new seekers but remains active in the provider's account.

Typical reasons:

- provider temporarily pauses inquiries;
- property availability is temporarily uncertain;
- provider is making operational changes;
- automated policy temporarily removes it from discovery without closing it.

Typical characteristics:

- not visible in normal public search;
- existing interactions may continue according to interaction rules;
- the listing may return to `PUBLISHED` if publication requirements remain satisfied.

### `UNDER_MODERATION`

The listing has been removed from normal public availability while a moderation issue is being reviewed.

Typical characteristics:

- public discovery is disabled;
- normal provider publication controls may be restricted;
- existing interactions may continue, pause, or be restricted according to moderation policy;
- only authorized moderation actions may resolve this state.

This state must not be treated as a normal provider-controlled pause.

### `CLOSED`

The listing is no longer accepting new marketplace activity because the underlying offering is no longer available.

Typical reasons:

- property rented;
- property sold;
- offering withdrawn;
- listing intentionally ended.

Typical characteristics:

- not shown as an active listing;
- no new inquiries or viewing requests;
- historical interactions remain available where permitted;
- review eligibility may remain active based on completed interactions.

A closed listing may be reactivated only if business rules permit it.

### `ARCHIVED`

The listing is retained as historical information but is no longer part of normal provider operations.

Typical characteristics:

- not publicly active;
- not eligible for new interactions;
- read-only or near-read-only;
- retained for history, analytics, moderation, and audit purposes.

`ARCHIVED` is normally terminal.

---

## 3.3 Listing State Diagram

```text
                         ┌──────────────────┐
                         │      DRAFT       │
                         └────────┬─────────┘
                                  │
                    submit/publish eligibility
                                  │
                 ┌────────────────┴───────────────┐
                 │                                │
                 ▼                                ▼
        ┌────────────────┐               ┌────────────────┐
        │ PENDING_REVIEW │──────────────▶│   PUBLISHED    │
        └───────┬────────┘    approve    └───────┬────────┘
                │                                 │
          changes required                  pause │ close
                │                                 │
                ▼                                 ├──────────────▶ CLOSED
              DRAFT                               │
                                                  ▼
                                               PAUSED
                                                  │
                                                  └──────────────▶ PUBLISHED

PUBLISHED / PAUSED / PENDING_REVIEW
        │
        │ moderation action
        ▼
UNDER_MODERATION
        │
        ├──────────────▶ PUBLISHED
        ├──────────────▶ PAUSED
        ├──────────────▶ CLOSED
        └──────────────▶ ARCHIVED

CLOSED ────────────────▶ ARCHIVED
```

---

## 3.4 Allowed Listing Transitions

| From | To | Typical Trigger | Minimum Conditions |
|---|---|---|---|
| `DRAFT` | `PENDING_REVIEW` | Submit for review | Required submission fields complete |
| `DRAFT` | `PUBLISHED` | Publish directly | Actor authorized; publication requirements satisfied |
| `DRAFT` | `ARCHIVED` | Abandon draft | Actor authorized |
| `PENDING_REVIEW` | `DRAFT` | Changes required / submission withdrawn | Actor or reviewer authorized |
| `PENDING_REVIEW` | `PUBLISHED` | Approved | Review completed; publication requirements satisfied |
| `PENDING_REVIEW` | `UNDER_MODERATION` | Policy concern detected | Moderation authority |
| `PENDING_REVIEW` | `ARCHIVED` | Submission permanently withdrawn | Authorized actor |
| `PUBLISHED` | `PAUSED` | Provider pauses listing | Actor controls listing |
| `PUBLISHED` | `CLOSED` | Offering no longer available | Actor controls listing |
| `PUBLISHED` | `UNDER_MODERATION` | Moderation action | Moderator authorized |
| `PAUSED` | `PUBLISHED` | Resume listing | Publication requirements still satisfied |
| `PAUSED` | `CLOSED` | Offering ended | Actor controls listing |
| `PAUSED` | `UNDER_MODERATION` | Moderation action | Moderator authorized |
| `UNDER_MODERATION` | `PUBLISHED` | Cleared and restored | Moderator authorized; publication requirements satisfied |
| `UNDER_MODERATION` | `PAUSED` | Cleared but provider pause retained | Moderator authorized |
| `UNDER_MODERATION` | `CLOSED` | Listing closed during/after review | Authorized actor |
| `UNDER_MODERATION` | `ARCHIVED` | Permanently removed | Moderation policy permits |
| `CLOSED` | `PUBLISHED` | Reactivate | Business rules permit; publication requirements satisfied |
| `CLOSED` | `ARCHIVED` | Archive history | Authorized actor or retention process |

---

## 3.5 Listing Invariants

1. Only `PUBLISHED` listings appear in normal public search and discovery.
2. A listing must not enter `PUBLISHED` unless required publication fields are valid.
3. A listing must not enter `PUBLISHED` unless the responsible provider or organization satisfies applicable verification requirements.
4. `UNDER_MODERATION` must not be bypassed by ordinary provider actions.
5. Existing interactions must not be deleted merely because a listing leaves `PUBLISHED`.
6. Listing closure must preserve enough history for reviews, disputes, and auditing.
7. `ARCHIVED` listings must not accept new marketplace interactions.

---

## 3.6 Listing Open Decisions

### LS-OD-001 — Pre-publication review

Does every new listing require approval before publication, or only listings/providers that trigger specific verification or moderation conditions?

**Current status:** Open.

### LS-OD-002 — Reactivation from `CLOSED`

May a closed listing return directly to `PUBLISHED`, or must it return to `DRAFT` first for revalidation?

**Current status:** Open.

### LS-OD-003 — Paused-listing visibility

Should a paused listing be completely hidden from public users, or accessible by direct URL with an "unavailable" status?

**Current status:** Open.

---

# 4. Organization Membership Lifecycle

## 4.1 Scope

This lifecycle represents a user's membership in a provider organization.

Organization membership is distinct from the user's Pachi account.

Removing or suspending a membership must not automatically delete the user's account.

---

## 4.2 Membership States

### `INVITED`

An organization has invited a user to join, but the user has not yet accepted.

Typical characteristics:

- no active organization permissions;
- invitation may expire;
- invitation may be revoked;
- user may accept or decline.

### `ACTIVE`

The membership is valid and may grant organization-scoped permissions.

Typical characteristics:

- role is effective;
- user may act within organization scope;
- permissions depend on Owner/Admin/Agent role;
- membership must still satisfy account and platform restrictions.

### `SUSPENDED`

The membership temporarily grants no operational organization permissions.

Typical reasons:

- organization administrator action;
- internal investigation;
- temporary security restriction;
- platform moderation affecting the membership relationship.

Typical characteristics:

- historical actions remain attributed to the user;
- membership may later return to `ACTIVE`;
- the user account itself may remain active.

### `REMOVED`

The membership has ended.

Typical characteristics:

- no organization permissions;
- historical attribution remains;
- ordinary reactivation should not occur by editing the old record in place.

A removed user should normally require a new invitation or explicit reinstatement workflow.

`REMOVED` is normally terminal.

### `DECLINED`

The invited user declined the invitation.

Typical characteristics:

- no organization permissions;
- invitation is no longer actionable;
- a future invitation should normally create a new invitation/membership attempt or reset through a defined workflow.

`DECLINED` is terminal for the specific invitation lifecycle.

### `EXPIRED`

The invitation was not accepted before its expiration time.

Typical characteristics:

- no organization permissions;
- invitation can no longer be accepted;
- a new invitation may be issued.

`EXPIRED` is terminal for the specific invitation lifecycle.

---

## 4.3 Membership State Diagram

```text
                    ┌──────────────┐
                    │   INVITED    │
                    └──────┬───────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
           accept        decline      expire/revoke
              │            │            │
              ▼            ▼            ▼
          ┌────────┐   ┌──────────┐  ┌─────────┐
          │ ACTIVE │   │ DECLINED │  │ EXPIRED │
          └───┬────┘   └──────────┘  └─────────┘
              │
       suspend│remove
              │
        ┌─────┴─────────────┐
        ▼                   ▼
   ┌───────────┐       ┌─────────┐
   │ SUSPENDED │       │ REMOVED │
   └─────┬─────┘       └─────────┘
         │
     reinstate
         │
         ▼
       ACTIVE
```

---

## 4.4 Allowed Membership Transitions

| From | To | Typical Trigger | Minimum Conditions |
|---|---|---|---|
| `INVITED` | `ACTIVE` | User accepts invitation | Invitation valid; user eligible |
| `INVITED` | `DECLINED` | User declines | Invitation valid |
| `INVITED` | `EXPIRED` | Expiration reached | Invitation not accepted |
| `INVITED` | `EXPIRED` | Invitation revoked | Authorized organization actor |
| `ACTIVE` | `SUSPENDED` | Temporarily disable membership | Authorized actor |
| `ACTIVE` | `REMOVED` | Remove member | Authorized actor; owner-protection rules satisfied |
| `SUSPENDED` | `ACTIVE` | Reinstate member | Authorized actor |
| `SUSPENDED` | `REMOVED` | Permanently end membership | Authorized actor; owner-protection rules satisfied |

---

## 4.5 Membership Invariants

1. Only `ACTIVE` membership grants organization-scoped permissions.
2. `INVITED`, `DECLINED`, `EXPIRED`, `SUSPENDED`, and `REMOVED` grant no normal organization permissions.
3. Organization owner protections defined in `roles-and-permissions.md` must be enforced.
4. An owner must not be moved to `REMOVED` through the ordinary membership-removal flow.
5. Historical actions remain attributed to removed or suspended members.
6. Membership state changes must immediately affect authorization.
7. A membership's organization ID must not change during its lifecycle.

---

## 4.6 Membership Open Decisions

### MS-OD-001 — Invitation revocation

Should revoked invitations use a dedicated `REVOKED` state instead of being represented as `EXPIRED`?

**Current recommendation:** Add `REVOKED` if invitation revocation needs to be distinguishable operationally or analytically.

### MS-OD-002 — Rejoining after removal

Should a previously removed user receive a new membership record when rejoining, or may a privileged actor restore the old record?

**Current recommendation:** Create a new membership or a new membership term so historical access periods remain unambiguous.

---

# 5. Verification Lifecycle

## 5.1 Scope

This lifecycle represents a verification case submitted to Pachi.

Verification may apply to subjects such as:

- a person;
- an individual provider;
- an organization;
- a property;
- authority to represent a property;
- another verification subject defined by `verification-model.md`.

This lifecycle describes the verification case, not the complete meaning of verification levels.

`verification-model.md` remains authoritative for verification requirements and evidence.

---

## 5.2 Verification States

### `DRAFT`

The verification case has been started but not submitted.

Typical characteristics:

- evidence may be added or removed;
- required information may be incomplete;
- no review has begun.

### `SUBMITTED`

The applicant has submitted the case.

Typical characteristics:

- minimum submission requirements are satisfied;
- case awaits review;
- evidence editing may be restricted.

### `UNDER_REVIEW`

The case is actively being reviewed.

Review may include:

- automated checks;
- document validation;
- manual review;
- cross-checking submitted evidence;
- fraud-risk assessment.

### `ACTION_REQUIRED`

The reviewer requires additional information, corrected evidence, or applicant action.

Typical characteristics:

- applicant may provide requested information;
- case is not verified;
- case may return to `SUBMITTED` or `UNDER_REVIEW` when the requested action is completed.

### `VERIFIED`

The verification case has been approved.

Typical characteristics:

- the verification result may grant or support marketplace permissions;
- approval metadata should be retained;
- verification may have an expiry date if applicable.

`VERIFIED` is not necessarily permanent.

### `REJECTED`

The verification case was reviewed and not approved.

Typical characteristics:

- rejection reason should be recorded;
- applicant may be permitted to resubmit through a new or revised case;
- no verification-dependent permission should be granted from this case.

### `EXPIRED`

A previously verified result is no longer valid because its validity period ended.

Typical characteristics:

- verification-dependent privileges may be reduced;
- re-verification may be required;
- historical verification result remains recorded.

### `REVOKED`

A previously verified result was invalidated before normal expiry.

Typical reasons:

- fraud discovered;
- underlying evidence invalidated;
- authority to represent a property ended;
- serious policy violation;
- manual administrative revocation.

Revocation must require a reason and appropriate authority.

### `CANCELLED`

The case was withdrawn before a final verification decision.

Typical characteristics:

- no active verification result;
- historical submission may be retained;
- a future verification attempt may use a new case.

---

## 5.3 Verification State Diagram

```text
                     ┌─────────┐
                     │  DRAFT  │
                     └────┬────┘
                          │ submit
                          ▼
                    ┌───────────┐
                    │ SUBMITTED │
                    └─────┬─────┘
                          │ review begins
                          ▼
                   ┌──────────────┐
                   │ UNDER_REVIEW │
                   └───┬────┬─────┘
                       │    │
          more info    │    │ decision
                       │    │
                       ▼    ├──────────────▶ VERIFIED
                ACTION_REQUIRED             │
                       │                    └──────────────▶ REJECTED
                       │ resubmit
                       ▼
                  SUBMITTED /
                  UNDER_REVIEW

VERIFIED ──────────────▶ EXPIRED
    │
    └──────────────────▶ REVOKED

DRAFT / SUBMITTED / ACTION_REQUIRED
    └──────────────────▶ CANCELLED
```

---

## 5.4 Allowed Verification Transitions

| From | To | Typical Trigger | Minimum Conditions |
|---|---|---|---|
| `DRAFT` | `SUBMITTED` | Applicant submits | Required evidence present |
| `DRAFT` | `CANCELLED` | Applicant abandons case | Applicant authorized |
| `SUBMITTED` | `UNDER_REVIEW` | Review starts | Reviewer/system authorized |
| `SUBMITTED` | `CANCELLED` | Withdrawal allowed | Policy permits |
| `UNDER_REVIEW` | `ACTION_REQUIRED` | More information needed | Reviewer authorized |
| `UNDER_REVIEW` | `VERIFIED` | Approved | Verification requirements satisfied |
| `UNDER_REVIEW` | `REJECTED` | Not approved | Reviewer authorized; reason recorded |
| `ACTION_REQUIRED` | `SUBMITTED` | Applicant responds | Requested action completed |
| `ACTION_REQUIRED` | `UNDER_REVIEW` | Reviewer resumes directly | Policy permits |
| `ACTION_REQUIRED` | `CANCELLED` | Applicant withdraws | Policy permits |
| `VERIFIED` | `EXPIRED` | Validity period ends | Expiry condition reached |
| `VERIFIED` | `REVOKED` | Verification invalidated | Authorized actor; reason recorded |

---

## 5.5 Verification Invariants

1. Verification-dependent privileges must rely only on a currently valid verification result.
2. `REJECTED`, `EXPIRED`, `REVOKED`, and `CANCELLED` do not satisfy active verification requirements.
3. A verification decision must identify the verified subject.
4. Approval and revocation actions must be attributable to an authorized reviewer, system process, or administrator.
5. Revocation must preserve the original verification history.
6. Evidence must not be exposed to unauthorized users simply because a public verification badge exists.
7. If verification expires, dependent authorization must respond promptly.
8. Verification status and moderation status must remain conceptually separate even if one can trigger changes in the other.

---

## 5.6 Verification Open Decisions

### VS-OD-001 — Review workflow

Which verification types are automated, manually reviewed, or hybrid?

**Current status:** To be defined in `verification-model.md`.

### VS-OD-002 — Resubmission after rejection

Should an applicant update the rejected case or create a new verification case?

**Current recommendation:** Preserve the rejected case and create a new attempt, while linking related attempts if useful.

### VS-OD-003 — Expiry behavior

Which verification types expire, and what happens to active listings when required verification expires?

**Current status:** Open.

---

# 6. Marketplace Interaction Lifecycle

## 6.1 Scope

An interaction represents a structured marketplace process between a seeker and a provider relating to a listing or property.

Examples may include:

- inquiry/contact request;
- viewing request;
- scheduled viewing;
- completed viewing;
- another qualifying marketplace engagement.

This state machine is intentionally broader than messaging.

Messages may be associated with an interaction but should not define the interaction's business state by themselves.

---

## 6.2 Interaction States

### `REQUESTED`

A seeker initiated an interaction that requires provider response.

Typical examples:

- viewing request;
- structured contact request;
- another provider-approval workflow.

Typical characteristics:

- provider has not accepted yet;
- seeker may be permitted to cancel;
- provider may accept or decline.

### `ACCEPTED`

The provider accepted the requested interaction, but no scheduled appointment has been confirmed yet.

This state is useful where acceptance and scheduling are separate steps.

If a particular interaction type does not need this distinction, the system may transition directly from `REQUESTED` to `SCHEDULED`.

### `SCHEDULED`

A date/time or other concrete arrangement has been confirmed.

Typical characteristics:

- both parties can see scheduling details;
- rescheduling may be allowed;
- cancellation rules apply;
- reminders may be generated.

### `IN_PROGRESS`

The interaction has started but is not yet complete.

This state is optional for interaction types where real-time start/end tracking provides value.

For a property viewing, it may represent a viewing that has begun.

### `COMPLETED`

The interaction concluded successfully.

Typical characteristics:

- normal scheduling changes are no longer allowed;
- qualifying interactions may create review eligibility;
- historical record should be retained.

`COMPLETED` is normally terminal.

### `DECLINED`

The provider declined the initial request.

Typical characteristics:

- no further normal progression;
- a new request may be created separately.

`DECLINED` is terminal.

### `CANCELLED`

An accepted or scheduled interaction was cancelled by an authorized participant.

Cancellation metadata should identify:

- who cancelled;
- when;
- reason, where applicable.

`CANCELLED` is terminal for that interaction occurrence.

### `NO_SHOW`

A scheduled participant failed to attend according to the business rules.

Typical characteristics:

- actor responsible for the no-show should be captured where determinable;
- review eligibility must not be assumed automatically;
- repeated no-show behavior may contribute to trust or moderation systems.

`NO_SHOW` is terminal.

### `EXPIRED`

The request was not acted upon within its allowed response window.

Typical characteristics:

- interaction does not continue;
- seeker may initiate a new interaction if the listing remains eligible.

`EXPIRED` is terminal.

---

## 6.3 Interaction State Diagram

```text
                      ┌───────────┐
                      │ REQUESTED │
                      └─────┬─────┘
                            │
           ┌────────────────┼─────────────────┐
           │                │                 │
         accept           decline           expire
           │                │                 │
           ▼                ▼                 ▼
      ┌──────────┐     ┌──────────┐      ┌─────────┐
      │ ACCEPTED │     │ DECLINED │      │ EXPIRED │
      └────┬─────┘     └──────────┘      └─────────┘
           │
       schedule
           │
           ▼
      ┌───────────┐
      │ SCHEDULED │
      └─────┬─────┘
            │
      ┌─────┼──────────────┐
      │     │              │
    start cancel         no-show
      │     │              │
      ▼     ▼              ▼
IN_PROGRESS CANCELLED    NO_SHOW
      │
   complete
      │
      ▼
 COMPLETED
```

A simplified interaction type may use:

```text
REQUESTED → SCHEDULED → COMPLETED
```

without requiring `ACCEPTED` or `IN_PROGRESS`.

---

## 6.4 Allowed Interaction Transitions

| From | To | Typical Trigger | Minimum Conditions |
|---|---|---|---|
| `REQUESTED` | `ACCEPTED` | Provider accepts | Provider authorized; listing eligible |
| `REQUESTED` | `SCHEDULED` | Provider accepts with confirmed schedule | Provider authorized; schedule valid |
| `REQUESTED` | `DECLINED` | Provider declines | Provider authorized |
| `REQUESTED` | `CANCELLED` | Seeker withdraws | Cancellation allowed |
| `REQUESTED` | `EXPIRED` | Response window ends | Expiry condition reached |
| `ACCEPTED` | `SCHEDULED` | Time confirmed | Participants authorized |
| `ACCEPTED` | `CANCELLED` | Participant cancels | Cancellation allowed |
| `SCHEDULED` | `SCHEDULED` | Reschedule | Rescheduling allowed; transition should create history |
| `SCHEDULED` | `IN_PROGRESS` | Interaction starts | Start conditions satisfied |
| `SCHEDULED` | `COMPLETED` | Completion recorded directly | Policy permits |
| `SCHEDULED` | `CANCELLED` | Participant cancels | Cancellation allowed |
| `SCHEDULED` | `NO_SHOW` | Attendance failure recorded | No-show rules satisfied |
| `IN_PROGRESS` | `COMPLETED` | Interaction ends successfully | Completion conditions satisfied |
| `IN_PROGRESS` | `CANCELLED` | Exceptional termination | Policy permits |

---

## 6.5 Interaction Invariants

1. An interaction must identify its participants.
2. An interaction must be associated with the relevant listing/property context.
3. Only authorized participants or staff may change interaction state.
4. A terminal interaction must not silently return to an active state.
5. Rescheduling must preserve historical schedule data or transition history.
6. `COMPLETED` must not be set merely because a scheduled time passed.
7. Review eligibility must be derived from review rules, not from arbitrary client input.
8. Listing closure must not delete existing interaction history.
9. If a listing becomes unavailable, active interaction handling must follow explicit business rules.
10. Messages alone must not be allowed to forge a qualifying completed interaction.

---

## 6.6 Interaction Open Decisions

### IS-OD-001 — Interaction types

Which structured interaction types exist in MVP?

Candidates include:

- inquiry;
- contact request;
- viewing request;
- viewing appointment.

**Current status:** To be aligned with the product specification.

### IS-OD-002 — Acceptance vs scheduling

Should `ACCEPTED` remain a separate state, or should accepted viewing requests always require immediate scheduling?

**Current status:** Open.

### IS-OD-003 — In-progress tracking

Does MVP need an `IN_PROGRESS` state for physical viewings?

**Current recommendation:** Omit it from MVP unless there is a concrete requirement for check-in/check-out, attendance confirmation, safety, or real-time operational tracking.

### IS-OD-004 — Completion confirmation

Who may mark a viewing as completed?

Options may include:

- provider only;
- seeker only;
- either party;
- both parties;
- automated completion with later dispute;
- staff in exceptional cases.

**Current status:** Open.

This decision is important because completion may affect review eligibility.

### IS-OD-005 — No-show confirmation

How is a no-show established and disputed?

**Current status:** Open.

### IS-OD-006 — Review eligibility

Which terminal interaction outcomes generate review eligibility?

At minimum, `COMPLETED` is a candidate.

`CANCELLED`, `NO_SHOW`, and `DECLINED` must not generate review eligibility unless the review system explicitly defines a special review type.

**Current status:** To be finalized in `review-system.md` and `review-rules.md`.

---

# 7. Cross-Lifecycle Rules

The four state machines interact but must remain separate.

## 7.1 Listing and verification

A listing may enter or remain `PUBLISHED` only when applicable verification requirements are satisfied.

If required verification becomes `EXPIRED` or `REVOKED`, the system must apply a defined listing policy.

Possible outcomes include:

```text
PUBLISHED → PAUSED
```

or:

```text
PUBLISHED → UNDER_MODERATION
```

The exact behavior is an open policy decision.

## 7.2 Listing and membership

For organization-owned listings, an actor's ability to manage the listing depends on an `ACTIVE` membership with sufficient role permissions.

Changing a membership to:

- `SUSPENDED`;
- `REMOVED`;

must immediately remove that user's organization-scoped listing management authority.

The listing itself does not automatically close merely because one member loses access.

## 7.3 Listing and interactions

When a listing moves from `PUBLISHED` to `PAUSED`, existing interactions should not automatically be deleted.

When a listing moves to `CLOSED`, the system must define whether already scheduled viewings may still proceed.

This should be finalized in `interaction-rules.md`.

## 7.4 Interaction and reviews

A qualifying interaction may create review eligibility.

The interaction state is evidence for eligibility, but the review system remains authoritative for:

- who may review whom;
- when;
- how many times;
- within what time period;
- whether a review may be edited or disputed.

## 7.5 Verification and membership

Organization membership and verification are separate.

An `ACTIVE` organization membership does not automatically imply that the user, provider, or organization is verified.

Similarly, verification does not automatically grant organization membership.

---

# 8. State Transition Implementation Requirements

The implementation should avoid unrestricted state updates such as:

```text
PATCH /listing/{id}
{
  "status": "PUBLISHED"
}
```

without transition-specific validation.

Preferred behavior is conceptually closer to:

```text
publishListing(listingId, actor)
pauseListing(listingId, actor)
closeListing(listingId, actor)

acceptMembership(invitationId, actor)
suspendMembership(membershipId, actor)

submitVerification(caseId, actor)
approveVerification(caseId, reviewer)

acceptInteraction(interactionId, actor)
scheduleInteraction(interactionId, schedule, actor)
completeInteraction(interactionId, actor)
```

An API may still expose RESTful endpoints, but business logic must represent transitions explicitly.

---

# 9. Transition Metadata

Where relevant, a state transition should record:

```text
entity_id
previous_state
new_state
actor_id
actor_type
timestamp
reason_code
reason_text
metadata
```

Not every transition requires every field.

Sensitive reason text must follow access-control rules.

---

# 10. Concurrency Requirements

State transitions must be safe under concurrent requests.

Examples:

- two organization admins attempt conflicting membership changes;
- provider pauses a listing while a moderator restricts it;
- provider accepts an interaction while seeker cancels;
- verification expires while listing publication is being attempted.

The backend should use appropriate transactional or optimistic-concurrency controls so that invalid double transitions cannot succeed.

---

# 11. Idempotency Requirements

Where clients may retry requests, transition operations should be designed to avoid unintended duplicate effects.

Examples:

- accepting the same interaction twice;
- submitting the same verification case twice;
- publishing the same listing twice;
- accepting the same organization invitation twice.

Repeated requests should either:

- return the already-achieved state safely; or
- return a clear conflict response.

They must not create duplicate business effects.

---

# 12. API Error Categories

The API specification should distinguish between failures such as:

- actor lacks permission;
- current state does not allow transition;
- required verification missing;
- resource ownership mismatch;
- validation requirements incomplete;
- entity already in target state;
- transition conflicts with a concurrent update;
- moderation restriction blocks action.

Exact status codes and error formats belong in `api-specification.md`.

---

# 13. Testing Requirements

Each state machine requires automated transition tests.

At minimum, tests should cover:

## Listings

- draft listing can publish when requirements are satisfied;
- incomplete draft cannot publish;
- unauthorized actor cannot publish;
- published listing can pause;
- paused listing can resume if still eligible;
- ordinary provider cannot escape `UNDER_MODERATION`;
- archived listing cannot accept new interactions.

## Memberships

- valid invitation can be accepted;
- expired invitation cannot be accepted;
- active membership grants appropriate organization scope;
- suspended membership loses permissions immediately;
- organization owner cannot be removed through normal removal;
- removed membership cannot continue acting on organization resources.

## Verification

- draft case can submit only with required evidence;
- submitted case can enter review;
- reviewer can request additional information;
- verified case satisfies active verification checks;
- expired verification no longer satisfies active requirements;
- revoked verification cannot be restored by ordinary applicant action.

## Interactions

- seeker can create an eligible request;
- provider can accept only requests within their scope;
- unrelated user cannot modify interaction;
- declined interaction cannot later be completed;
- cancelled interaction cannot silently become scheduled;
- completed interaction cannot be completed again;
- invalid completion cannot create review eligibility.

---

# 14. Open Cross-Domain Decisions

The following decisions should be resolved before implementation of the affected flows.

### CD-OD-001 — Listing behavior after verification loss

When required provider or organization verification becomes `EXPIRED` or `REVOKED`, should affected published listings become:

- `PAUSED`;
- `UNDER_MODERATION`;
- `CLOSED`;
- another explicitly defined state?

**Current status:** Open.

### CD-OD-002 — Active interactions after listing closure

May an already scheduled interaction continue after its listing moves to `CLOSED`?

**Current status:** Open.

### CD-OD-003 — Review-triggering completion authority

Because interaction completion may create review eligibility, Pachi must define a trustworthy completion-confirmation model.

**Current status:** Open.

### CD-OD-004 — Moderation override semantics

When moderation places a listing into `UNDER_MODERATION`, should the previous listing state be stored separately so restoration returns it automatically to its prior state?

**Current recommendation:** Yes.

Store the prior operational state rather than assuming every restored listing returns to `PUBLISHED`.

---

# 15. Decisions Established by This Document

Unless changed through an approved product update, this document establishes the following baseline decisions:

1. Lifecycle transitions must be enforced server-side.
2. Listings begin in `DRAFT`.
3. Only `PUBLISHED` listings participate in normal public discovery.
4. `UNDER_MODERATION` is distinct from provider-controlled `PAUSED`.
5. Organization permissions require an `ACTIVE` membership.
6. Suspended and removed memberships grant no organization-scoped permissions.
7. Verification cases preserve rejection, expiry, and revocation history.
8. `VERIFIED` verification may later become `EXPIRED` or `REVOKED`.
9. Marketplace interactions have explicit business states independent of messaging.
10. A completed interaction may contribute to review eligibility, but review rules remain authoritative.
11. Terminal lifecycle states must preserve historical and audit data where required.
12. State transitions should be represented as domain operations rather than unrestricted status-field edits.

---

# 16. Definition of Done

This document may move from **Draft for Review** to **Approved** when:

- listing pre-publication review behavior is decided;
- listing reactivation behavior is decided;
- organization invitation revocation behavior is confirmed;
- verification expiry behavior is aligned with `verification-model.md`;
- MVP interaction types are confirmed;
- interaction completion authority is defined;
- no-show rules are defined if `NO_SHOW` remains in MVP;
- review eligibility rules are aligned with `review-system.md`;
- cross-lifecycle behavior for verification loss and listing closure is resolved;
- no known conflicts remain with the product specification, domain model, or roles-and-permissions model.
