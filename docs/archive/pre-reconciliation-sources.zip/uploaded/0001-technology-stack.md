# ADR 0001: Technology Stack

> **Status:** Proposed  
> **Date:** 2026-09-24  
> **Decision Owners:** Pachi Engineering  
> **Scope:** Application platform, data layer, infrastructure, CI/CD, and observability  
> **Supersedes:** None  
> **Superseded By:** None

---

## 1. Context

Pachi is a housing marketplace intended to support:

- Android;
- iOS;
- a public web experience;
- provider and organization workflows;
- property and listing management;
- location-aware property discovery;
- structured seeker/provider interactions;
- verification;
- reviews and reputation;
- moderation;
- administrative operations.

The product is expected to begin with a relatively small engineering footprint while still being suitable for production use.

The initial architecture must therefore optimize for:

- maintainability;
- fast iteration;
- strong typing;
- shared knowledge across frontend and backend;
- reliable transactional data;
- geospatial queries;
- secure handling of verification evidence;
- app-store deployment;
- search-engine-visible public web pages;
- operational simplicity;
- clear scaling paths;
- observability;
- vendor portability where practical.

The system does **not** currently require:

- microservices;
- Kubernetes;
- a distributed database;
- dedicated search infrastructure;
- event streaming infrastructure;
- multi-region active-active deployment.

Those technologies may become appropriate later, but adopting them before they solve a demonstrated problem would increase operational complexity without sufficient benefit.

---

## 2. Decision

Pachi will initially use:

- a **TypeScript monorepo**;
- **React Native with Expo** for Android and iOS;
- **Next.js** for the public and authenticated web application;
- **NestJS** for the backend API;
- a **modular monolith** backend architecture;
- **REST + OpenAPI** as the primary application API;
- **PostgreSQL + PostGIS** as the system of record;
- **Drizzle ORM** with explicit SQL migrations;
- **Amazon Web Services (AWS)** as the primary backend infrastructure provider;
- **Amazon ECS on AWS Fargate** for backend containers;
- **Amazon RDS for PostgreSQL** for the production database;
- **Amazon S3 + CloudFront** for object/media storage and delivery;
- **Amazon SQS** for durable asynchronous jobs;
- **Vercel** for the Next.js web application initially;
- **Expo Application Services (EAS)** for mobile builds and store submission;
- **GitHub Actions** for continuous integration and deployment orchestration;
- **OpenTelemetry** for portable backend telemetry instrumentation;
- **Amazon CloudWatch / AWS X-Ray** as the initial backend observability destination;
- **Sentry** for application errors, crashes, and release diagnostics, particularly on web and mobile.

Authentication, payments, maps/geocoding, messaging, email/SMS delivery, product analytics, and third-party identity verification are intentionally deferred to separate ADRs.

---

## 3. Decision Drivers

### 3.1 Cross-platform mobile delivery

Pachi must support both Android and iOS without maintaining two entirely separate native codebases at launch.

### 3.2 High-quality public web experience

Property pages and marketplace discovery should work well on the public web and remain compatible with:

- search-engine indexing;
- server rendering;
- metadata generation;
- link previews;
- responsive desktop/mobile web experiences.

### 3.3 Shared language across the product

Using TypeScript across web, mobile, backend, shared contracts, and infrastructure reduces context switching and enables code sharing where appropriate.

### 3.4 Relational marketplace data

Pachi's core entities have significant relationships and transactional rules:

- users;
- providers;
- organizations;
- memberships;
- properties;
- listings;
- interactions;
- reviews;
- verification cases;
- moderation cases.

A relational database is a strong fit for these constraints.

### 3.5 Geospatial search

Housing discovery requires location-aware operations such as:

- storing property coordinates;
- distance filtering;
- bounding-box searches;
- proximity sorting;
- potentially region and neighborhood spatial queries.

The data layer must support mature spatial indexing and query capabilities.

### 3.6 Trust-sensitive workflows

Verification, review eligibility, moderation, and interaction state transitions require:

- transactions;
- constraints;
- auditability;
- deterministic state changes;
- durable histories.

### 3.7 Small-team operational efficiency

The stack should minimize infrastructure that must be manually operated.

Managed services are preferred where they remove routine maintenance without creating unacceptable lock-in.

### 3.8 Production scaling path

The initial system should be capable of scaling vertically and horizontally without requiring a complete rewrite.

### 3.9 Deployment from Windows

The development environment is Windows + WSL2.

The mobile build strategy must not require a local Mac for routine iOS build and distribution workflows.

### 3.10 Cost discipline

Infrastructure should be added only when needed.

Pachi should avoid paying early for:

- Kubernetes control-plane complexity;
- dedicated search clusters;
- large always-on cache tiers;
- unnecessary microservices;
- self-hosted observability stacks.

---

## 4. High-Level Architecture

```text
                         ┌─────────────────────┐
                         │      Users          │
                         └──────────┬──────────┘
                                    │
                    ┌───────────────┴───────────────┐
                    │                               │
                    ▼                               ▼
          ┌──────────────────┐            ┌──────────────────┐
          │  Next.js Web App │            │ Expo Mobile App  │
          │     Vercel       │            │ Android + iOS    │
          └────────┬─────────┘            └────────┬─────────┘
                   │                               │
                   └──────────────┬────────────────┘
                                  │ HTTPS / REST
                                  ▼
                       ┌────────────────────┐
                       │    NestJS API      │
                       │ Modular Monolith   │
                       │    ECS Fargate     │
                       └─────────┬──────────┘
                                 │
              ┌──────────────────┼────────────────────┐
              │                  │                    │
              ▼                  ▼                    ▼
     ┌────────────────┐  ┌────────────────┐  ┌────────────────┐
     │ PostgreSQL +   │  │       S3       │  │      SQS       │
     │    PostGIS     │  │ Media/Evidence │  │  Async Jobs    │
     │      RDS       │  └───────┬────────┘  └───────┬────────┘
     └────────────────┘          │                   │
                                 ▼                   ▼
                         ┌──────────────┐    ┌────────────────┐
                         │ CloudFront   │    │ Worker Process │
                         └──────────────┘    │  ECS Fargate   │
                                             └────────────────┘
```

Observability:

```text
Applications
    │
    ├── Structured logs ─────────────▶ CloudWatch
    │
    ├── OpenTelemetry ───────────────▶ ADOT / X-Ray / CloudWatch
    │
    └── Errors / crashes ────────────▶ Sentry
```

---

## 5. Repository Strategy

### 5.1 Monorepo

Pachi will use one repository for the primary application code.

Proposed structure:

```text
pachi/
├── apps/
│   ├── api/
│   ├── mobile/
│   ├── web/
│   └── worker/
│
├── packages/
│   ├── api-client/
│   ├── contracts/
│   ├── database/
│   ├── eslint-config/
│   ├── typescript-config/
│   └── ui-tokens/
│
├── infrastructure/
│   └── aws/
│
├── docs/
│
├── package.json
├── pnpm-workspace.yaml
└── turbo.json
```

`apps/worker/` may initially be omitted if background processing remains small enough to run within the API deployment.

It should be added once asynchronous workloads justify an independently scalable worker.

### 5.2 Package Manager

**Decision:** `pnpm`

Reasons:

- efficient dependency storage;
- strong workspace support;
- suitable for monorepos;
- deterministic lockfile;
- good compatibility with the selected TypeScript ecosystem.

### 5.3 Monorepo Build Orchestration

**Decision:** Turborepo

Used for:

- build orchestration;
- dependency-aware tasks;
- caching;
- linting;
- testing;
- type checking;
- CI optimization.

Turborepo must not become a dependency for runtime business logic.

---

## 6. Language and Runtime

### 6.1 TypeScript

**Decision:** TypeScript is the primary application language.

Used for:

- web;
- mobile;
- backend API;
- workers;
- shared contracts;
- infrastructure code where AWS CDK is used.

Benefits:

- shared domain vocabulary;
- compile-time checks;
- common tooling;
- easier sharing of generated clients and contracts;
- reduced context switching.

### 6.2 Node.js

**Decision:** Use the current Active LTS version of Node.js and pin it in the repository.

At the time of this ADR, Node.js 24 is an LTS release.

The exact runtime version should be declared in repository configuration rather than relying on a developer's globally installed version.

Possible mechanisms:

```text
.nvmrc
.tool-versions
package.json engines
Docker base image
CI configuration
```

The runtime should move between supported LTS releases through explicit upgrade work.

---

## 7. Mobile Application

### 7.1 Framework

**Decision:** React Native with Expo.

Primary packages/concepts:

```text
React Native
Expo
Expo Router
TypeScript
```

### 7.2 Why Expo

Expo is selected because it provides a strong cross-platform development and deployment workflow while preserving access to native capabilities where necessary.

It supports:

- Android;
- iOS;
- native modules;
- file-based application routing;
- development builds;
- hosted mobile build infrastructure;
- app-store submission workflows;
- update tooling for eligible application changes.

Expo also reduces dependence on a local macOS machine for routine iOS cloud builds.

### 7.3 Build and Distribution

**Decision:** Expo Application Services (EAS).

Use:

```text
EAS Build
EAS Submit
```

for production mobile build and submission workflows.

EAS Update may be evaluated separately for eligible non-native application updates.

All update behavior must remain compliant with Apple App Store and Google Play policies.

### 7.4 Mobile Scope

The mobile app should contain mobile product experiences.

It should not become the backend.

Business rules must remain enforced in the API even if mobile code mirrors rules for user experience.

---

## 8. Web Application

### 8.1 Framework

**Decision:** Next.js with the App Router.

Used for:

- public marketplace pages;
- listing discovery;
- listing details;
- provider profiles;
- organization profiles;
- authenticated web workflows;
- operational web surfaces where appropriate.

### 8.2 Why Separate Next.js Web From Expo Web

Pachi will not initially use the Expo mobile application as the only web application.

Reasons:

- property marketplace pages benefit strongly from mature web rendering and metadata capabilities;
- public property pages require first-class SEO behavior;
- desktop workflows may differ significantly from native mobile workflows;
- Next.js has a mature ecosystem for server-rendered React web applications.

Code may still be shared where sensible.

### 8.3 Web Hosting

**Initial decision:** Vercel.

Reasons:

- low operational burden;
- strong Next.js deployment support;
- preview environments;
- straightforward production deployment.

Important constraint:

Core marketplace business logic must remain in the Pachi backend API.

The architecture must not require proprietary Vercel server behavior to enforce core domain rules.

This preserves the option to self-host or move the web application later.

---

## 9. Backend Application

### 9.1 Framework

**Decision:** NestJS.

NestJS provides:

- structured modules;
- dependency injection;
- guards;
- validation integration;
- interceptors;
- background-task integrations;
- testing support;
- OpenAPI support;
- clear boundaries suitable for a modular monolith.

### 9.2 Architecture Style

**Decision:** Modular monolith.

Possible initial modules:

```text
auth
users
providers
organizations
memberships
properties
listings
search
interactions
reviews
verification
moderation
media
notifications
audit
admin
```

Each module should own:

- application services;
- domain logic;
- persistence boundaries;
- authorization logic specific to the module.

Cross-module dependencies should be deliberate.

### 9.3 Why Not Microservices

Pachi does not initially have:

- independent engineering teams;
- independently scaling service domains;
- extreme traffic separation requirements;
- deployment isolation requirements that justify distributed-service complexity.

Starting with microservices would introduce:

- distributed transactions;
- service discovery;
- cross-service tracing;
- network failure modes;
- multiple deployment pipelines;
- duplicated infrastructure.

The modular monolith preserves logical boundaries without paying those costs.

Modules may be extracted into services later if operational evidence justifies it.

---

## 10. API Style

### 10.1 Primary API

**Decision:** REST over HTTPS.

The API will be documented with OpenAPI.

Example:

```text
/api/v1/listings
/api/v1/properties
/api/v1/interactions
/api/v1/reviews
/api/v1/verification-cases
```

### 10.2 API Contract

OpenAPI should be treated as a generated or validated application contract.

Where practical, typed clients should be generated for:

- web;
- mobile.

The application should avoid maintaining manually duplicated request/response interfaces across clients.

### 10.3 Why Not GraphQL Initially

GraphQL is not selected for the first version because:

- the application domain can be expressed cleanly through REST;
- authorization and state transitions benefit from explicit operations;
- REST reduces initial backend and client complexity;
- OpenAPI provides sufficient contract tooling.

GraphQL may be reconsidered if client query flexibility becomes a demonstrated requirement.

---

## 11. Database

### 11.1 Primary Database

**Decision:** PostgreSQL.

PostgreSQL is the authoritative transactional store for:

- users;
- provider profiles;
- organizations;
- memberships;
- properties;
- listings;
- interactions;
- reviews;
- verification metadata;
- moderation;
- audit references.

### 11.2 Geospatial Extension

**Decision:** PostGIS.

Used for:

- property coordinates;
- spatial indexes;
- proximity queries;
- bounding boxes;
- distance sorting;
- region-based geospatial queries.

Typical data should use an appropriate geographic coordinate reference system and index strategy.

Exact spatial types and indexing choices belong in the database-design documentation.

### 11.3 ORM / Query Layer

**Decision:** Drizzle ORM.

Use Drizzle for:

- typed schema definitions;
- common queries;
- migrations;
- application database access.

Use explicit SQL when necessary for:

- advanced PostGIS operations;
- complex indexes;
- database constraints;
- specialized query plans;
- performance-sensitive operations.

The ORM must not prevent the system from using PostgreSQL features directly.

### 11.4 Schema Philosophy

The database should enforce important invariants where practical through:

- foreign keys;
- unique constraints;
- check constraints;
- transaction boundaries;
- indexes.

Business rules should not rely exclusively on application code when the database can safely enforce an invariant.

---

## 12. Search Strategy

### 12.1 Initial Search

**Decision:** Use PostgreSQL first.

Initial discovery/search capabilities should use:

- PostGIS;
- PostgreSQL full-text search where appropriate;
- trigram/fuzzy matching where appropriate;
- ordinary relational filters;
- indexed sorting.

This should support early marketplace requirements such as:

- city/region;
- price;
- bedrooms;
- property type;
- distance;
- availability;
- provider type;
- keywords.

### 12.2 Dedicated Search Engine

**Decision:** Deferred.

Do not provision OpenSearch, Elasticsearch, Meilisearch, or another dedicated search engine at launch unless measured requirements justify it.

Reconsider dedicated search when:

- query complexity exceeds PostgreSQL comfortably;
- relevance ranking becomes a product differentiator;
- autocomplete requirements become advanced;
- index scale materially affects database workloads;
- analytics indicate search latency problems.

---

## 13. Object Storage and Media

### 13.1 Storage

**Decision:** Amazon S3.

Separate storage policies should exist for:

#### Public marketplace media

Examples:

- listing photos;
- organization logos;
- permitted avatars.

#### Private sensitive evidence

Examples:

- identity documents;
- organization verification documents;
- property-authority evidence.

These categories must not share the same public-access policy.

### 13.2 Media Delivery

**Decision:** Amazon CloudFront for public media delivery.

Public media may be delivered through CloudFront while keeping origin buckets protected.

### 13.3 Private Evidence

Sensitive evidence must use:

- private S3 access;
- tightly scoped IAM;
- short-lived signed access mechanisms where required;
- encryption;
- audit logging;
- explicit retention rules.

Verification documents must never be exposed through public CloudFront behavior intended for listing photos.

---

## 14. Background Jobs

### 14.1 Queue

**Decision:** Amazon SQS.

Potential workloads:

- email/SMS notification requests;
- image processing;
- verification expiry;
- listing expiry;
- moderation jobs;
- review-window expiry;
- data synchronization;
- webhook processing;
- audit-related async work.

### 14.2 Workers

Background jobs will be processed by one or more worker processes built from the same TypeScript/NestJS ecosystem.

Workers may run as separate ECS Fargate services/tasks when background load justifies independent scaling.

### 14.3 Why SQS Before Redis Queues

SQS is selected as the first durable queue because it provides:

- managed durability;
- retry semantics;
- dead-letter queues;
- independent scaling;
- no cache cluster to operate solely for queueing.

A Redis-compatible service may still be added later for caching or ephemeral coordination.

---

## 15. Caching

### 15.1 Initial Position

**Decision:** Do not require a distributed cache at initial launch.

Use:

- HTTP caching where appropriate;
- CDN caching;
- application-local caching only where safe;
- optimized database indexes.

### 15.2 Future Cache

If metrics demonstrate a need, use a managed Redis-compatible cache such as Amazon ElastiCache for Valkey/Redis-compatible workloads.

Potential uses:

- rate limiting;
- hot-query cache;
- distributed locks;
- ephemeral session-related data if architecture requires it.

Caching must never become the only durable source of marketplace state.

---

## 16. Infrastructure Platform

### 16.1 Primary Cloud

**Decision:** AWS.

AWS will initially host backend infrastructure.

### 16.2 Compute

**Decision:** Amazon ECS with AWS Fargate.

Deploy containerized:

- API;
- background worker;
- future independently scalable processes.

Reasons:

- production container runtime;
- horizontal scaling;
- no server fleet management;
- simpler operational model than Kubernetes;
- clear path to multiple services later.

### 16.3 Container Registry

**Decision:** Amazon ECR.

All production backend container images should be:

- versioned;
- immutable after release where practical;
- tied to a Git commit/release.

### 16.4 Load Balancing

Use an AWS Application Load Balancer for public backend HTTP traffic when required by the deployment topology.

Production API containers should not be exposed directly to the public internet without the approved ingress layer.

### 16.5 Production Database

**Decision:** Amazon RDS for PostgreSQL.

Use managed features such as:

- automated backups;
- snapshots;
- point-in-time recovery;
- encryption;
- monitoring.

High-availability settings should match the production risk and budget.

Production launch requirements should define when Multi-AZ becomes mandatory.

### 16.6 Network

Expected production topology:

```text
Internet
   │
   ▼
ALB
   │
   ▼
ECS tasks
   │
   ▼
Private database connectivity
   │
   ▼
RDS
```

The database must not be publicly exposed in production.

### 16.7 Secrets

**Decision:** AWS Secrets Manager and/or AWS Systems Manager Parameter Store.

Production secrets must not live in:

- source code;
- Git history;
- Docker images;
- committed `.env` files.

Local development may use ignored environment files.

### 16.8 DNS and TLS

Proposed AWS services:

```text
Route 53
AWS Certificate Manager
```

Exact DNS ownership and domain architecture will be documented separately.

---

## 17. Infrastructure as Code

### 17.1 AWS Infrastructure

**Decision:** AWS CDK using TypeScript.

Reasons:

- same primary language as the application;
- version-controlled infrastructure;
- repeatable environments;
- native AWS resource coverage;
- CloudFormation deployment model.

Infrastructure must not be created manually in production without being reflected in infrastructure code unless responding to an emergency.

Emergency changes should be reconciled into infrastructure code afterward.

### 17.2 Environments

Minimum long-lived environments:

```text
local
staging
production
```

Preview deployments may exist for the web application.

Avoid maintaining many permanent cloud environments until they are needed.

---

## 18. Local Development

### 18.1 Environment

Primary developer environment:

```text
Windows
+ WSL2 Ubuntu
+ VS Code
+ Docker Desktop
```

### 18.2 Docker Compose

Docker Compose should provide local infrastructure such as:

```text
PostgreSQL + PostGIS
```

Additional local services should be added only when the production architecture requires them.

Application processes may run directly in WSL during development for faster iteration.

---

## 19. CI/CD

### 19.1 CI Platform

**Decision:** GitHub Actions.

Pull requests should eventually run:

```text
dependency installation
format checks
lint
type check
unit tests
integration tests
build validation
database migration validation
security/dependency checks where configured
```

### 19.2 Backend Deployment

Expected production pipeline:

```text
Merge to approved branch
        ↓
GitHub Actions
        ↓
Test / Build
        ↓
Build Docker image
        ↓
Push to ECR
        ↓
Run migration gate
        ↓
Deploy ECS service
        ↓
Health verification
```

Production migrations require explicit safe-migration practices.

### 19.3 Web Deployment

Initial web deployment:

```text
GitHub
  ↓
CI validation
  ↓
Vercel
```

Preview deployments may be created for pull requests.

Production deployment must remain tied to an auditable Git revision.

### 19.4 Mobile Deployment

Expected mobile pipeline:

```text
GitHub release / approved workflow
        ↓
EAS Build
        ↓
Internal / preview testing
        ↓
EAS Submit
        ↓
Google Play / Apple App Store
```

Production app-store releases should not occur automatically from every merge to `main`.

---

## 20. Observability

### 20.1 Goals

Production observability must answer:

- Is the system available?
- Which requests are failing?
- Which releases introduced failures?
- Where is latency occurring?
- Are background jobs failing?
- Is the database under pressure?
- Are external integrations failing?
- Which user-visible workflow was affected?

### 20.2 Structured Logging

**Decision:** Structured JSON logging.

Backend logs should include context such as:

```text
timestamp
level
service
environment
request_id
trace_id
route
actor_id where appropriate
organization_id where appropriate
error_code
duration
```

Sensitive data must not be logged.

Recommended Node logging library:

```text
Pino
```

### 20.3 OpenTelemetry

**Decision:** Instrument backend services with OpenTelemetry.

OpenTelemetry should provide portable instrumentation for:

- traces;
- metrics;
- request context.

This prevents application instrumentation from depending entirely on one observability vendor.

### 20.4 AWS Telemetry Destination

**Initial decision:**

```text
OpenTelemetry
        ↓
AWS Distro for OpenTelemetry
        ↓
CloudWatch / X-Ray
```

AWS infrastructure metrics and alarms remain in CloudWatch.

### 20.5 Application Error Monitoring

**Decision:** Sentry.

Primary use:

- web error reporting;
- mobile crash/error reporting;
- release association;
- source-map-aware diagnostics.

Backend exception reporting may also use Sentry where it adds value, but backend metrics and distributed tracing should remain OpenTelemetry-based.

### 20.6 Alerting

Initial alerts should focus on actionable production failures, such as:

- API 5xx error rate;
- API health-check failures;
- sustained latency;
- ECS task failures;
- queue backlog;
- worker failures;
- database capacity pressure;
- failed production deployment.

Avoid excessive low-value alerts.

---

## 21. Security Baseline

This ADR does not replace the security architecture, but the stack must support the following baseline.

Production must use:

- HTTPS;
- encrypted managed database storage;
- encrypted object storage;
- private verification evidence;
- least-privilege IAM;
- secrets outside source control;
- database backups;
- auditable privileged actions;
- separate production credentials;
- dependency update processes;
- environment separation.

The API remains the authoritative enforcement point for domain permissions.

---

## 22. Authentication and Authorization Boundary

Authentication technology is intentionally deferred to a separate ADR.

Regardless of the selected identity provider:

- Pachi's domain authorization remains application-owned;
- organization roles remain in Pachi's data model;
- provider permissions remain in Pachi's data model;
- verification gates remain in Pachi's data model;
- moderation restrictions remain in Pachi's data model.

The application must not reduce Pachi authorization to external identity-provider roles alone.

---

## 23. Version Policy

This ADR selects technologies, not permanent version numbers.

Repository configuration must pin actual versions.

General policy:

1. use supported stable releases;
2. prefer LTS runtimes for production;
3. lock dependency versions through the package manager;
4. schedule framework/runtime upgrades intentionally;
5. avoid depending on experimental framework features for critical business logic without a documented reason.

---

## 24. Alternatives Considered

### 24.1 Flutter

**Advantages**

- strong cross-platform mobile framework;
- good native performance;
- single UI toolkit;
- mature Android/iOS support.

**Reasons not selected**

Pachi's web and backend stack is expected to use TypeScript/JavaScript.

React Native + Expo allows greater language/tooling continuity with Next.js, NestJS, and shared TypeScript contracts.

Flutter remains a valid alternative if future mobile requirements strongly favor it.

### 24.2 Native Kotlin + Swift

**Advantages**

- maximum platform-native control;
- direct access to platform APIs.

**Reasons not selected**

Maintaining two native applications would significantly increase initial implementation and maintenance cost.

Native modules may still be introduced through React Native where necessary.

### 24.3 One Expo Application for Mobile and Web

**Advantages**

- maximal UI reuse;
- fewer applications.

**Reasons not selected**

Pachi's public property marketplace is expected to depend heavily on mature web capabilities including SEO and server-rendered public pages.

A dedicated Next.js web application provides a clearer fit.

### 24.4 Django / Django REST Framework

**Advantages**

- mature ecosystem;
- strong ORM;
- excellent administrative capabilities;
- proven marketplace suitability.

**Reasons not selected**

It would introduce Python as another primary application language.

NestJS gives Pachi a more unified TypeScript stack.

Django remains a technically strong alternative.

### 24.5 FastAPI

**Advantages**

- lightweight;
- strong Python typing;
- excellent API ergonomics.

**Reasons not selected**

Pachi benefits more from a highly structured modular backend framework and a single primary language across the application.

### 24.6 Supabase as the Entire Backend

**Advantages**

- rapid setup;
- hosted PostgreSQL;
- authentication;
- storage;
- realtime functionality.

**Reasons not selected as the core application architecture**

Pachi has substantial custom domain behavior around authorization, verification, moderation, lifecycle transitions, review eligibility, and audit history.

A dedicated backend application provides clearer control over those workflows.

Individual Supabase services could be reconsidered separately if they provide clear value.

### 24.7 Firebase / Firestore

**Advantages**

- excellent mobile ecosystem;
- realtime features;
- managed infrastructure.

**Reasons not selected**

Pachi has strongly relational and transactional domain data.

PostgreSQL provides a more natural fit for relationships, constraints, joins, audit records, reporting, and geospatial functionality.

### 24.8 MongoDB

**Advantages**

- flexible document model;
- mature managed offerings.

**Reasons not selected**

Pachi's domain benefits strongly from relational integrity and transactions across related marketplace records.

### 24.9 Prisma

**Advantages**

- excellent TypeScript developer experience;
- mature tooling;
- large ecosystem.

**Reasons not selected**

Drizzle gives Pachi a relatively thin SQL-oriented abstraction and direct access to PostgreSQL features, including PostGIS-oriented schema/query patterns.

Prisma remains a viable fallback if Drizzle creates unacceptable maintenance or tooling problems.

### 24.10 Microservices

**Advantages**

- independent deployment;
- independent scaling;
- team ownership boundaries.

**Reasons not selected**

Current product and team scale does not justify the operational complexity.

Start with strong internal module boundaries and extract services only when evidence supports the change.

### 24.11 Kubernetes

**Advantages**

- sophisticated orchestration;
- portability;
- powerful scaling and deployment patterns.

**Reasons not selected**

Pachi does not initially need Kubernetes-level orchestration.

ECS Fargate provides container deployment and scaling with substantially less cluster administration.

### 24.12 Serverless Functions for the Entire Backend

Examples:

- AWS Lambda-only backend;
- web-host serverless API only.

**Advantages**

- scale-to-zero opportunities;
- low infrastructure management.

**Reasons not selected**

Pachi's backend contains structured modules, transactional workflows, background processing, potentially long-running operational tasks, and shared middleware/authorization.

A containerized long-running API provides simpler operational consistency.

Serverless functions may still be used selectively.

### 24.13 Dedicated Search Engine at Launch

Examples:

- OpenSearch;
- Elasticsearch;
- Meilisearch.

**Advantages**

- advanced relevance;
- autocomplete;
- independent search scaling.

**Reasons not selected**

PostgreSQL + PostGIS is expected to satisfy initial marketplace search requirements.

Dedicated search adds infrastructure, synchronization, eventual-consistency concerns, and operational cost.

### 24.14 Redis as a Required Initial Dependency

**Advantages**

- caching;
- rate limiting;
- queue support;
- fast ephemeral data.

**Reasons not selected initially**

Pachi should add Redis/Valkey when a measured requirement exists.

SQS provides the initial durable queue requirement without requiring an always-on cache cluster.

### 24.15 Railway / Render / Fly.io for All Backend Infrastructure

**Advantages**

- very fast initial deployment;
- lower infrastructure learning curve;
- simpler developer experience.

**Reasons not selected as the proposed long-term primary platform**

AWS provides a broader production infrastructure path for managed PostgreSQL, private networking, object storage, queues, IAM, observability, background processing, and future scaling requirements.

A platform-as-a-service remains a possible early staging option if AWS setup delays product validation, but production architecture should remain container-portable.

### 24.16 Self-Hosted Observability Stack

Examples:

```text
Prometheus
Grafana
Loki
Tempo
```

**Advantages**

- maximum control;
- open ecosystem;
- reduced SaaS dependency.

**Reasons not selected initially**

Operating the monitoring platform would itself become production infrastructure requiring maintenance.

OpenTelemetry preserves the ability to change telemetry destinations later.

---

## 25. Consequences

### 25.1 Positive Consequences

- Most application development uses TypeScript.
- PostgreSQL matches Pachi's domain structure and trust workflows.
- PostGIS supports property search without another primary data store.
- Expo supports Android/iOS development and hosted build workflows.
- Next.js provides a dedicated public web platform.
- NestJS modular monolith supports explicit domain boundaries.
- Managed AWS services reduce routine infrastructure maintenance.
- API and worker containers can scale independently when required.
- OpenTelemetry keeps telemetry instrumentation portable.

### 25.2 Negative Consequences

- The initial system uses several vendors: AWS, Vercel, Expo EAS, and Sentry.
- AWS networking, IAM, ECS, and infrastructure-as-code require careful configuration.
- Separate Next.js and React Native applications mean not all UI code can be shared.
- Using TypeScript across most components concentrates ecosystem risk.
- Advanced location queries require PostGIS knowledge.
- A modular monolith requires discipline to prevent tight coupling.

---

## 26. Risk Mitigations

### Vendor lock-in

Mitigation:

- containerized backend;
- PostgreSQL;
- S3-compatible abstractions where practical;
- REST/OpenAPI contracts;
- OpenTelemetry;
- core business logic outside hosting-provider functions.

### AWS operational complexity

Mitigation:

- infrastructure as code;
- minimal initial service set;
- managed services;
- staging environment;
- documented runbooks.

### Monolith coupling

Mitigation:

- domain modules;
- module-owned services;
- controlled dependency direction;
- no direct cross-module table manipulation where avoidable;
- architecture tests if needed later.

### Database bottlenecks

Mitigation:

- indexes;
- query monitoring;
- PostGIS indexing;
- caching only when demonstrated;
- read scaling later if necessary.

### Mobile/web divergence

Share:

- API contracts;
- validation schemas where appropriate;
- business types;
- design tokens;
- domain terminology.

Do not force UI sharing when platform-specific experiences are better.

---

## 27. Deferred Decisions

The following require separate ADRs or engineering documents.

### Authentication

Evaluate:

- managed identity provider;
- email/phone verification;
- social login;
- account recovery;
- MFA;
- session/token strategy.

### Maps and Geocoding

Evaluate:

- Google Maps Platform;
- Mapbox;
- HERE;
- OpenStreetMap-based services;
- geocoding quality and coverage for Cameroon.

### Messaging

Evaluate whether Pachi requires:

- in-app messaging;
- contact relay;
- WhatsApp handoff;
- provider contact reveal.

### Email and SMS

Evaluate providers based on:

- Cameroon delivery;
- cost;
- sender identity requirements;
- OTP reliability;
- deliverability.

### Payments

Payment architecture must be separate because provider availability, regulation, mobile money, and marketplace payment flows require dedicated analysis.

### Identity Verification Provider

The verification domain model is already defined.

The vendor implementation must be evaluated separately.

### Product Analytics

Evaluate event collection and analytics tooling after the event taxonomy is defined.

### AWS Region

The production AWS region must be chosen after evaluating:

- latency from Cameroon;
- required AWS service availability;
- cost;
- data handling requirements;
- disaster-recovery strategy.

---

## 28. Initial Technology Matrix

| Layer | Proposed Technology |
|---|---|
| Language | TypeScript |
| Runtime | Node.js Active LTS |
| Monorepo | pnpm + Turborepo |
| Mobile | React Native + Expo |
| Mobile Routing | Expo Router |
| Mobile Build/Submit | EAS |
| Web | Next.js |
| Backend | NestJS |
| Backend Architecture | Modular monolith |
| API | REST + OpenAPI |
| Database | PostgreSQL |
| Geospatial | PostGIS |
| ORM / Query Layer | Drizzle ORM + SQL |
| Initial Search | PostgreSQL + PostGIS + FTS/trigram as needed |
| Object Storage | Amazon S3 |
| Public Media Delivery | Amazon CloudFront |
| Async Queue | Amazon SQS |
| Optional Future Cache | ElastiCache for Valkey/Redis-compatible workloads |
| Backend Compute | Amazon ECS on Fargate |
| Database Hosting | Amazon RDS for PostgreSQL |
| Container Registry | Amazon ECR |
| Infrastructure as Code | AWS CDK + TypeScript |
| Web Hosting | Vercel |
| Mobile Delivery | Expo EAS |
| CI/CD | GitHub Actions |
| Backend Logging | Structured JSON / Pino |
| Telemetry Standard | OpenTelemetry |
| AWS Observability | CloudWatch + X-Ray / ADOT |
| Application Error Monitoring | Sentry |
| Local Infrastructure | Docker Compose |

---

## 29. Proposed Repository Evolution

After this ADR is accepted, the repository may evolve toward:

```text
pachi/
├── apps/
│   ├── api/
│   ├── mobile/
│   └── web/
├── packages/
│   ├── contracts/
│   ├── database/
│   ├── eslint-config/
│   └── typescript-config/
├── infrastructure/
│   └── aws/
├── docs/
└── tooling/
```

Do not scaffold every directory merely because it appears here.

Create a component when implementation work actually begins.

---

## 30. Acceptance Criteria

This ADR can move from **Proposed** to **Accepted** when:

- the application architecture has been reviewed against the product/domain documents;
- Expo + EAS is accepted as the mobile approach;
- Next.js is accepted as the web approach;
- NestJS modular monolith is accepted as the backend approach;
- PostgreSQL + PostGIS is accepted as the primary data store;
- AWS is accepted as the primary backend cloud;
- the expected initial AWS operating cost is reviewed;
- the production AWS region is either selected or explicitly deferred to a follow-up ADR;
- authentication is tracked as a separate decision;
- no product requirement is known to be incompatible with the proposed stack.

---

## 31. Follow-Up ADRs

Recommended next ADRs:

```text
0002-authentication-and-session-strategy.md
0003-aws-region-and-environment-topology.md
0004-maps-geocoding-and-location-services.md
0005-media-processing-and-storage-policy.md
0006-notification-email-sms-strategy.md
```

Additional ADRs should be created when a decision is significant, difficult to reverse, or affects multiple parts of the system.

---

## 32. References

This decision was informed by the current official documentation for:

- Node.js release and LTS policy;
- Expo and Expo Application Services;
- Next.js;
- NestJS;
- PostgreSQL and PostGIS;
- Drizzle ORM;
- Amazon ECS and AWS Fargate;
- Amazon RDS for PostgreSQL;
- Amazon S3 and CloudFront;
- GitHub Actions;
- OpenTelemetry;
- AWS Distro for OpenTelemetry;
- Amazon CloudWatch;
- Sentry.

Framework and cloud documentation should be rechecked when implementation begins because supported versions and service capabilities change over time.
