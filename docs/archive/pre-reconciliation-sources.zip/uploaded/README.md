# Pachi Documentation

> **Status:** Approved  
> **Last Updated:** 2026-09-24  
> **Owner:** Project

---

## 1. Purpose

This directory is the canonical documentation source for Pachi.

All maintained project documentation is Markdown and lives in the same Git repository as the application.

Legacy DOCX files are no longer authoritative.

Git history is the versioning mechanism. Do not create filenames such as:

```text
final.docx
final-v2.docx
final-v2-fixed.docx
```

When an authoritative document changes, update the canonical Markdown file and commit the change.

---

## 2. Documentation Authority

Pachi documentation follows this hierarchy:

```text
Approved Product Decision
        ↓
Product Specification
        ↓
Domain Model
        ↓
Specialized Domain / Business Rule
        ↓
Architecture / Engineering Specification
        ↓
Database / API Implementation Detail
        ↓
Application Code
```

A lower layer must not silently contradict a higher layer.

---

## 3. Documentation Structure

```text
docs/
├── README.md
│
├── 00-product/
│   └── product-specification.md
│
├── 01-domain/
│   ├── domain-model.md
│   ├── roles-and-permissions.md
│   ├── lifecycle-states.md
│   ├── verification-model.md
│   ├── review-system.md
│   └── interaction-and-moderation-rules.md
│
├── 02-architecture/
│   ├── system-architecture.md
│   └── adr/
│       ├── 0001-technology-stack.md
│       ├── 0002-authentication-and-session-strategy.md
│       ├── 0003-aws-region-and-environment-topology.md
│       ├── 0004-maps-geocoding-and-location-services.md
│       ├── 0005-media-processing-and-storage-policy.md
│       └── 0006-notification-email-sms-strategy.md
│
├── 03-operations/
│   ├── deployment-and-operations-runbook.md
│   ├── production-readiness-checklist.md
│   └── launch-day-runbook.md
│
└── archive/
    └── legacy-docx/
        └── README.md
```

Create additional documents only when implementation creates a concrete need.

---

## 4. Canonical Foundation

The primary product/domain foundation is:

1. `00-product/product-specification.md`
2. `01-domain/domain-model.md`
3. `01-domain/roles-and-permissions.md`
4. `01-domain/lifecycle-states.md`
5. `01-domain/verification-model.md`
6. `01-domain/review-system.md`
7. `01-domain/interaction-and-moderation-rules.md`

Architecture is then defined by:

1. `02-architecture/system-architecture.md`
2. accepted/current ADRs under `02-architecture/adr/`

Operations live under `03-operations/`.

---

## 5. Status Vocabulary

Use:

```text
Approved
Proposed
Planned
Deferred
Deprecated
```

Operational working documents may additionally use:

```text
Draft for Review
```

Architecture Decision Records use:

```text
Proposed
Accepted
Superseded
Deprecated
Rejected
```

Do not label a decision `Accepted` merely because implementation has started.

---

## 6. Document Metadata

Recommended header:

```text
> **Status:** Approved
> **Last Updated:** YYYY-MM-DD
> **Owner:** Project
```

Add authority/scope metadata when helpful.

---

## 7. ADR Format

Architecture Decision Records should contain:

```text
Title
Status
Date
Context
Decision
Decision Drivers
Alternatives Considered
Consequences
Open Decisions where applicable
Acceptance Criteria
Related Documentation
```

Significant architecture changes require an ADR.

Do not use ADRs for ordinary implementation details that are easy to change.

---

## 8. Product vs Engineering Authority

Use product/domain documentation when the uncertainty is:

```text
WHAT should Pachi do?
```

Examples:

- who may review whom;
- when a listing is publishable;
- what verification means;
- which lifecycle states exist.

Use architecture/engineering documentation when the uncertainty is:

```text
HOW should Pachi implement it?
```

Examples:

- Cognito vs another identity provider;
- RDS deployment topology;
- queue technology;
- image-processing pipeline.

If neither layer answers an implementation-blocking question, make the decision, document it at the correct authority level, then implement it.

---

## 9. Traceability

Important requirements should be traceable through:

```text
Product Requirement
        ↓
Domain / Business Rule
        ↓
API / Database / Architecture
        ↓
Implementation
        ↓
Tests
```

This does not require a separate traceability document for every feature.

Prefer meaningful references in code, tests, PRs, and documentation.

---

## 10. Update Rules

When behavior changes:

1. identify the authoritative document;
2. update that document;
3. update dependent documents only where necessary;
4. implement the change;
5. update tests;
6. record significant architecture rationale in an ADR.

Do not create duplicate competing specifications.

---

## 11. Implementation Rule

Pachi is now beyond the bulk-documentation phase.

Default workflow:

```text
Design
→ Document the minimum required decision
→ Implement
→ Test
→ Record significant decisions
→ Continue
```

Do not return to:

```text
Document everything
→ eventually start coding
```

Documentation should support implementation rather than delay it.

---

## 12. Security Documentation Rules

Security-sensitive behavior must be enforced server-side.

Documentation must never imply that:

- client UI is an authorization boundary;
- a role check in the frontend is sufficient;
- verification evidence can use public-media access paths;
- database changes can bypass migrations in normal production operation.

---

## 13. Database and API Documentation Rules

Production database changes use migrations.

API behavior should be intentional and documented where it forms a stable contract.

Lifecycle state changes should use domain operations rather than unrestricted state mutation.

---

## 14. Legacy DOCX Policy

Legacy DOCX documents have been superseded by native Markdown.

The two former foundational DOCX authorities are replaced by:

```text
00-product/product-specification.md
01-domain/domain-model.md
```

The old DOCX binaries, when available in the repository, should be moved to:

```text
docs/archive/legacy-docx/
```

They remain historical references only.

Do not edit legacy DOCX files after migration.

See:

```text
docs/archive/legacy-docx/README.md
```

for the migration record.

---

## 15. Current Architecture Baseline

Current architecture documents include ADRs `0001` through `0006`.

Some ADRs remain `Proposed`.

`02-architecture/system-architecture.md` consolidates them as the current implementation baseline without changing their formal ADR status.

Implementation may proceed against that baseline while open non-blocking decisions remain documented.

---

## 16. Next Phase

The documentation foundation is sufficient to begin implementation.

The next default activity is repository/application scaffolding rather than producing additional planning documents.

New documentation should be created only when:

- a missing decision blocks implementation;
- an important architecture decision needs rationale;
- a stable API/database contract needs specification;
- operations require a concrete runbook.
