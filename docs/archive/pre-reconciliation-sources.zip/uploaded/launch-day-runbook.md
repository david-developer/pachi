# Pachi — Launch-Day Runbook

> **Status:** Draft for Review  
> **Last Updated:** 2026-09-24  
> **Authority:** This document defines the operational procedure for launching Pachi into public production and operating the first 24 hours after launch.  
> **Related Documents:**  
> - `docs/03-operations/production-readiness-checklist.md`
> - `docs/03-operations/deployment-and-operations-runbook.md`
> - `docs/02-architecture/system-architecture.md`
> - `docs/02-architecture/adr/0001-technology-stack.md`
> - `docs/02-architecture/adr/0002-authentication-and-session-strategy.md`
> - `docs/02-architecture/adr/0003-aws-region-and-environment-topology.md`
> - `docs/02-architecture/adr/0004-maps-geocoding-and-location-services.md`
> - `docs/02-architecture/adr/0005-media-processing-and-storage-policy.md`
> - `docs/02-architecture/adr/0006-notification-email-sms-strategy.md`

---

## 1. Purpose

This runbook is the step-by-step operating procedure for Pachi's first public production launch.

It defines:

- pre-launch validation;
- launch ownership;
- go/no-go criteria;
- ordered deployment and enablement;
- live monitoring;
- rollback triggers;
- incident handling;
- stakeholder communication;
- first-24-hours operating cadence.

This document is not a substitute for the production readiness checklist.

The readiness checklist determines whether Pachi is ready to launch.

This runbook defines **how the launch is executed**.

---

# 2. Launch Principles

Launch day should optimize for:

1. safety over speed;
2. controlled change;
3. observability;
4. reversible deployment;
5. explicit ownership;
6. minimal simultaneous variables;
7. rapid detection of user impact;
8. documented decisions.

Do not combine launch with unrelated infrastructure or architecture changes.

---

# 3. Launch Roles

Assign these roles before launch.

For a small team, one person may hold multiple roles.

## 3.1 Launch Lead

Responsible for:

- final go/no-go call;
- sequencing launch steps;
- freezing unrelated changes;
- coordinating rollback if required.

## 3.2 Technical Operator

Responsible for:

- deployments;
- migrations;
- AWS/ECS/RDS operations;
- rollback execution;
- infrastructure verification.

## 3.3 Monitoring Owner

Responsible for:

- dashboards;
- alerts;
- logs;
- user-impact metrics;
- provider health.

## 3.4 Communications Owner

Responsible for:

- internal status updates;
- public status communication where needed;
- support coordination;
- incident updates.

## 3.5 Support / Triage Owner

Responsible for:

- incoming user issues;
- issue classification;
- escalation to engineering;
- tracking repeated patterns.

---

# 4. Launch Record

Complete before launch:

```text
Launch Date:
Planned Launch Time:
Launch Lead:
Technical Operator:
Monitoring Owner:
Communications Owner:
Support Owner:

Git SHA:
API Image Digest:
Web Release:
Android Version:
iOS Version:
Database Migration Version:

Primary AWS Region:
Backup / DR Region:
Known Approved Exceptions:
```

---

# 5. Change Freeze

Before launch:

- [ ] Freeze unrelated production changes
- [ ] Freeze non-essential infrastructure changes
- [ ] Freeze database schema work not required for launch
- [ ] Freeze provider configuration changes not required for launch
- [ ] Confirm only launch-related changes remain pending

The freeze remains in effect until the initial launch stabilization window is complete.

---

# 6. Pre-Launch Go/No-Go Review

Run the final review before any production-enablement step.

Required inputs:

- production-readiness checklist;
- latest staging results;
- latest backup status;
- latest deployment candidate;
- open incident list;
- known exceptions.

---

## 6.1 Automatic No-Go Conditions

Launch is **NO-GO** if any of the following is true:

```text
production database backup unhealthy
restore path untested
critical auth path failing
known authorization bypass
verification evidence publicly reachable
production secrets exposed
SEV-1 or SEV-2 unresolved
rollback unavailable
database migration state uncertain
critical monitoring unavailable
production alerting unavailable
launch build differs from tested candidate
```

---

## 6.2 Go Criteria

Launch may proceed only when:

- [ ] All `BLOCKER` items in production-readiness checklist are complete
- [ ] Required exceptions are explicitly approved
- [ ] Staging is healthy
- [ ] Production backup state is healthy
- [ ] Rollback image/version is identified
- [ ] Operator access works
- [ ] Monitoring is live
- [ ] Critical alerts are active
- [ ] No unresolved high-severity incident exists
- [ ] Launch team confirms readiness

---

# 7. Final Backup Check

Immediately before launch:

- [ ] Verify latest RDS automated backup
- [ ] Verify PITR window is current
- [ ] Verify cross-region backup/copy health where enabled
- [ ] Verify cross-account backup health where enabled
- [ ] Record latest known recovery point
- [ ] Verify S3 critical-bucket versioning
- [ ] Record backup timestamp in launch notes

Do not launch if backup state is uncertain.

---

# 8. Final Provider Health Check

Check current operational health for:

```text
AWS
Cognito
SES
AWS End User Messaging SMS
Google Maps Platform
Expo Push Service
Vercel
GitHub Actions
```

A minor provider degradation does not automatically block launch.

A provider outage blocks launch if it affects a critical path such as:

- authentication;
- production database;
- deployment;
- essential account verification.

---

# 9. Final Security Check

Before launch:

- [ ] Production credentials verified
- [ ] No test credentials active in production configuration
- [ ] Production callback URLs correct
- [ ] API keys restricted
- [ ] Public S3 access blocked
- [ ] Private evidence bucket confirmed inaccessible publicly
- [ ] Production RDS confirmed private
- [ ] GitHub OIDC deployment role working
- [ ] No exposed secrets detected in recent changes

---

# 10. Final Migration Review

If launch includes a migration:

- [ ] Migration tested in staging
- [ ] Migration risk classified
- [ ] Expected runtime understood
- [ ] Lock impact understood
- [ ] Recovery path documented
- [ ] Pre-migration recovery point created if required
- [ ] Application compatibility with migration understood

If no migration is required, record:

```text
Launch migration: NONE
```

---

# 11. Launch Sequence

Launch steps should be executed in order.

Do not parallelize high-risk steps unless there is a clear reason.

---

## 11.1 Step 1 — Confirm Freeze

- [ ] Confirm deployment/change freeze active
- [ ] Confirm launch candidate unchanged
- [ ] Confirm launch roles available

---

## 11.2 Step 2 — Verify Production Infrastructure

Check:

- [ ] ALB healthy
- [ ] ECS cluster healthy
- [ ] RDS healthy
- [ ] RDS Multi-AZ enabled where required
- [ ] SQS queues healthy
- [ ] S3 buckets reachable by expected roles
- [ ] CloudFront healthy
- [ ] Cognito production pool reachable
- [ ] Secrets readable by runtime roles

---

## 11.3 Step 3 — Run Production Migration

If required:

```text
approved migration task
    ↓
migration execution
    ↓
migration validation
```

After migration:

- [ ] Schema version correct
- [ ] Core tables readable
- [ ] PostGIS extension works
- [ ] No unexpected long-running locks
- [ ] No migration errors
- [ ] No abnormal database resource spike

If migration fails, stop launch progression.

---

## 11.4 Step 4 — Deploy Backend

Deploy immutable API image.

Verify:

- [ ] ECS deployment begins
- [ ] New tasks start
- [ ] Readiness passes
- [ ] ALB reports healthy targets
- [ ] Old tasks drain safely
- [ ] 5xx rate remains normal
- [ ] database connection count remains safe

---

## 11.5 Step 5 — Deploy Worker

If worker is separate:

- [ ] Deploy worker image
- [ ] Confirm queue consumption
- [ ] Confirm no rapid retry loop
- [ ] Confirm DLQ remains stable

---

## 11.6 Step 6 — Deploy Web

Deploy production Next.js release.

Verify:

- [ ] Homepage loads
- [ ] Listing search loads
- [ ] Public listing page loads
- [ ] Login initiation works
- [ ] API integration works
- [ ] Map integration works
- [ ] Error reporting active

---

## 11.7 Step 7 — Verify Mobile Production Configuration

Before public app availability:

- [ ] Production API URL correct
- [ ] Cognito production configuration correct
- [ ] Google Maps keys correct
- [ ] Push credentials correct
- [ ] Deep links correct
- [ ] SecureStore auth persistence tested

---

## 11.8 Step 8 — Enable Public Access

Only after prior checks pass:

```text
enable production traffic
or
publish public release
or
remove launch gate
```

Record exact time:

```text
Public Launch Time:
```

---

# 12. Immediate Smoke Test

Run immediately after public enablement.

Use controlled production test accounts.

- [ ] Web sign-up/sign-in works
- [ ] Mobile sign-in works
- [ ] Email verification works
- [ ] Phone OTP works
- [ ] Listing search works
- [ ] Map loads
- [ ] Provider can create property
- [ ] Image upload works
- [ ] Image processing completes
- [ ] Listing publish works
- [ ] Published listing appears in search
- [ ] Viewing request works
- [ ] Notification generated
- [ ] Push/email delivery works
- [ ] Audit events recorded
- [ ] Logout works

---

# 13. Live Monitoring Dashboard

Keep these views open during launch.

## 13.1 API

Watch:

```text
request rate
5xx rate
4xx rate
p50 latency
p95 latency
p99 latency
ALB target health
```

## 13.2 ECS

Watch:

```text
desired task count
running task count
task restarts
CPU
memory
deployment state
```

## 13.3 Database

Watch:

```text
CPU
connections
free storage
IO
latency
failover events
locks
slow queries where available
```

## 13.4 Queues

Watch:

```text
queue depth
oldest message age
DLQ depth
worker processing rate
```

## 13.5 Authentication

Watch:

```text
sign-in failures
token validation failures
account recovery failures
unexpected auth error spike
```

## 13.6 Notifications

Watch:

```text
SES delivery/bounces
SMS success/failure
OTP latency
push receipt errors
notification queue depth
```

## 13.7 Media

Watch:

```text
upload failures
processing latency
processing queue
media DLQ
CloudFront origin errors
```

## 13.8 Maps

Watch:

```text
API errors
quota usage
unexpected request volume
billing anomaly
```

---

# 14. Launch Monitoring Cadence

## First Hour

Review at approximately:

```text
T+5 min
T+15 min
T+30 min
T+60 min
```

At each checkpoint, record:

- error rate;
- latency;
- database health;
- queue health;
- provider health;
- user-reported issues;
- rollback status.

---

## Hours 1–6

Review every:

```text
30–60 minutes
```

or more frequently if load/incident activity requires it.

---

## Hours 6–24

Review at least every:

```text
2–4 hours
```

during staffed coverage.

Critical alerting remains active continuously.

---

# 15. Go/No-Go After Deployment

Even after successful deployment, launch may still be stopped before broader exposure.

## GO

Proceed if:

- error rate normal;
- core flows work;
- database healthy;
- no security issue;
- queues stable;
- provider delivery acceptable;
- no significant user-impact pattern.

## HOLD

Pause rollout if:

- intermittent critical-flow errors;
- uncertain migration behavior;
- rising queue backlog;
- abnormal provider failures;
- unclear security signal.

## ROLLBACK

Rollback if rollback criteria are met.

---

# 16. Rollback Triggers

Rollback should be strongly considered or initiated when any of the following occurs after a deployment:

```text
sustained severe 5xx increase
core authentication broken
listing search unusable
database incompatibility introduced
critical authorization failure
data corruption caused by new release
worker creates damaging duplicate effects
media pipeline exposes unsafe/raw content
production secrets exposed by release
severe performance regression
```

---

# 17. Automatic Rollback Thresholds

Pachi may later automate rollback.

Initially, rollback remains operator-controlled.

Suggested manual trigger examples:

```text
API 5xx > 5% sustained for 5 minutes
or
no healthy API tasks
or
critical auth flow unavailable
or
confirmed data integrity issue
```

Exact thresholds should be tuned from real baseline metrics.

---

# 18. Application Rollback Procedure

1. Freeze further deployments.
2. Identify last known-good image digest.
3. Confirm previous version is database-compatible.
4. Redeploy previous ECS task definition/image.
5. Wait for healthy targets.
6. Run smoke tests.
7. Confirm error/latency recovery.
8. Record rollback.
9. Preserve failed-release logs.

---

# 19. Web Rollback Procedure

1. Identify previous known-good Vercel deployment.
2. Promote/restore previous deployment.
3. Verify API compatibility.
4. Run web smoke tests.
5. Confirm authentication callback behavior.
6. Record rollback.

---

# 20. Mobile Rollback Limitation

App-store releases cannot always be instantly rolled back like backend/web deployments.

Therefore:

- backend APIs must remain backward compatible;
- remote configuration/feature disablement should be used where appropriate;
- emergency mobile fix may require a new store release;
- EAS Update may be used only for eligible non-native changes and according to app-store policy.

---

# 21. Database Failure During Launch

If database behavior becomes unsafe:

1. stop application rollout;
2. restrict writes where possible;
3. identify migration/write issue;
4. preserve current database;
5. determine forward-fix vs restore;
6. restore in parallel if necessary;
7. do not destroy original evidence.

Do not treat application rollback as sufficient if the database itself is corrupted.

---

# 22. Queue Failure During Launch

If queues back up:

- confirm worker health;
- confirm provider health;
- inspect oldest messages;
- stop poison-message loops;
- scale worker if safe;
- inspect DLQ;
- do not blindly replay DLQ.

Core product writes should remain available where asynchronous effects can safely wait.

---

# 23. Notification Failure During Launch

If email, SMS, or push degrades:

- keep in-app notification records;
- retry retryable deliveries;
- avoid duplicate multi-provider sends;
- use fallback only according to approved policy;
- do not block core marketplace transaction unless notification is required for security.

OTP failure may block phone verification but should not corrupt account state.

---

# 24. Maps Failure During Launch

If Google Maps/Geocoding fails:

- existing listing search remains on PostGIS;
- existing stored coordinates remain valid;
- map rendering/autocomplete may degrade;
- do not remove existing listings;
- manual location fallback should remain available where implemented.

---

# 25. Media Failure During Launch

If processing fails:

- keep uploads quarantined;
- do not publish originals;
- pause new uploads if necessary;
- recover worker;
- monitor DLQ/backlog;
- communicate affected feature only.

---

# 26. Authentication Failure During Launch

If Cognito or federation fails:

- determine whether existing sessions still work;
- verify whether failure affects local, Google, Apple, or all login;
- do not bypass auth manually;
- preserve security logs;
- consider pausing launch if new-user access is materially broken.

---

# 27. Security Incident During Launch

Immediate actions:

1. declare incident;
2. stop unrelated deployments;
3. preserve logs/evidence;
4. revoke compromised credential/session;
5. restrict vulnerable path;
6. assess exposure;
7. rotate secrets if required;
8. decide rollback/disablement.

A confirmed critical security exposure is a launch rollback/no-go condition.

---

# 28. Incident Severity During Launch

Use:

```text
SEV-1
SEV-2
SEV-3
SEV-4
```

Launch-specific interpretation:

### SEV-1

- widespread outage;
- database corruption;
- major security breach;
- auth unavailable for most users.

### SEV-2

- major core workflow unavailable;
- severe provider or media failure;
- widespread interaction/listing impact.

### SEV-3

- limited segment affected;
- workaround available.

### SEV-4

- cosmetic/minor defect.

---

# 29. Launch Communication Model

Communication should be factual and concise.

Maintain:

```text
timestamp
current status
user impact
actions in progress
next decision point
```

Avoid speculation.

---

# 30. Internal Launch Updates

Suggested cadence during active launch:

```text
pre-launch
launch start
public enablement
T+15
T+30
T+60
major incident/change
launch stabilization
```

---

# 31. Internal Status Template

```text
Pachi Launch Status

Time:
Status: GO / HOLD / ROLLBACK / STABLE
User Impact:
API:
Database:
Queues:
Auth:
Notifications:
Media:
Known Issues:
Actions:
Next Checkpoint:
```

---

# 32. User-Facing Communications

User-facing communication may be needed when:

- sign-in unavailable;
- listings unavailable;
- viewing workflows unavailable;
- major degradation persists;
- launch is rolled back after public exposure.

Do not publish unnecessary technical implementation detail.

---

# 33. User-Facing Incident Message Principles

Messages should:

- state affected feature;
- acknowledge degraded service;
- avoid exposing security-sensitive details;
- state recovery when resolved.

Example style:

```text
Some users are currently unable to sign in to Pachi. We are working to restore access.
```

---

# 34. Support Triage

During the first 24 hours, support issues should be tagged by category:

```text
AUTH
LISTING
SEARCH
MAPS
MEDIA
INTERACTION
NOTIFICATION
PAYMENT if applicable later
PERFORMANCE
OTHER
```

Track repeated reports.

Three independent reports of the same failure pattern should trigger engineering review even if monitoring appears normal.

---

# 35. First-Hour Operating Procedure

During the first hour:

- [ ] Monitor API continuously
- [ ] Monitor RDS continuously
- [ ] Watch auth errors
- [ ] Watch queue backlog
- [ ] Watch media processing
- [ ] Watch SMS/OTP delivery
- [ ] Watch email bounces
- [ ] Watch push failures
- [ ] Review first user reports
- [ ] Verify one end-to-end transaction manually
- [ ] Confirm first post-launch backup remains scheduled/healthy

---

# 36. Hours 1–6 Operating Procedure

- [ ] Review dashboards every 30–60 minutes
- [ ] Review error aggregation in Sentry
- [ ] Review database slow/error patterns
- [ ] Review SMS/OTP success rate
- [ ] Review Google Maps usage
- [ ] Review media queue
- [ ] Review notification queue
- [ ] Review user reports
- [ ] Avoid non-essential deployment changes

---

# 37. Hours 6–12 Operating Procedure

- [ ] Verify no hidden backlog accumulated
- [ ] Review costs for anomalous growth
- [ ] Review auth/recovery failures
- [ ] Review moderation/report activity
- [ ] Verify background expiration/reminder jobs
- [ ] Verify backup jobs remain healthy
- [ ] Confirm alert routing still works

---

# 38. Hours 12–24 Operating Procedure

- [ ] Review first full-cycle operational metrics
- [ ] Confirm database/storage growth is reasonable
- [ ] Confirm no queue/DLQ drift
- [ ] Confirm SMS spending is expected
- [ ] Confirm maps usage/cost is expected
- [ ] Review top Sentry issues
- [ ] Review support issue categories
- [ ] Decide whether launch freeze can be relaxed

---

# 39. First 24-Hour No-Risk Changes Policy

During the first 24 hours, prefer:

```text
fix only user-impacting defects
```

Avoid:

- refactors;
- infrastructure reorganization;
- dependency upgrades;
- unrelated schema changes;
- provider migrations.

Every additional change makes incident attribution harder.

---

# 40. Hotfix Procedure

If a hotfix is required:

1. create focused fix;
2. run CI;
3. verify in staging if time permits;
4. assess migration impact;
5. obtain launch-lead approval;
6. deploy;
7. run smoke tests;
8. monitor;
9. record hotfix.

Avoid bundling multiple unrelated fixes.

---

# 41. Feature Disablement

If a feature is unstable but the platform is otherwise healthy, prefer targeted disablement where available.

Potentially disable:

```text
new media uploads
listing publication
new verification submission
SMS OTP resend
specific social login provider
```

Do not disable foundational security checks to keep a feature available.

---

# 42. Launch Success Criteria

Pachi may be considered stable after the initial launch window when:

- core flows work;
- error rate remains within baseline;
- database is healthy;
- queues are stable;
- no SEV-1/SEV-2 incident is active;
- auth works reliably;
- SMS/OTP delivery is acceptable;
- media processing is stable;
- monitoring/alerts work;
- no uncontrolled cost spike exists;
- no unresolved critical security issue exists.

---

# 43. Launch Completion Decision

At the end of the stabilization window, choose one:

```text
STABLE
EXTEND MONITORING
PARTIAL ROLLBACK
FULL ROLLBACK
```

Record:

```text
Decision:
Time:
Owner:
Reason:
Known Issues:
Next Actions:
```

---

# 44. First-24-Hours Review

At approximately T+24h, review:

```text
API availability
5xx rate
latency
database health
queue health
SMS delivery
email delivery
push delivery
maps usage
media processing
auth failures
support issues
security events
cost
```

---

# 45. First-24-Hours Summary

Create a brief operational summary:

```text
Launch version:
Total incidents:
SEV-1:
SEV-2:
SEV-3:
SEV-4:

Major user-impacting issues:
Rollback events:
Hotfixes:
Provider issues:
Unexpected costs:
Outstanding risks:
```

---

# 46. Post-Launch Actions

After the first 24 hours:

- open issues for recurring defects;
- adjust alert thresholds;
- update runbook gaps;
- update readiness checklist if a missing launch gate was discovered;
- update architecture docs if implementation changed;
- schedule follow-up performance work;
- schedule follow-up cost review;
- document accepted operational debt.

---

# 47. Post-Launch Freeze Exit

The launch freeze may be relaxed when:

- no critical incident is active;
- metrics are stable;
- support volume is manageable;
- backlog is understood;
- backups are healthy;
- launch lead approves exit.

---

# 48. Rollback Decision Record

If rollback occurs, record:

```text
Rollback Time:
Trigger:
Affected Release:
Previous Release:
Database State:
Migration State:
User Impact:
Rollback Owner:
Verification Result:
Follow-Up Issue:
```

---

# 49. Incident Decision Log

For major launch incidents, maintain a timestamped decision log.

Example:

```text
18:05 — elevated 5xx detected
18:08 — deployment frozen
18:12 — database healthy; issue isolated to API release
18:15 — rollback approved
18:22 — previous image healthy
18:30 — incident downgraded
```

This log improves later root-cause analysis.

---

# 50. Launch-Day Forbidden Actions

Unless responding to an emergency, do not:

- manually edit production data without change record;
- bypass authorization;
- expose RDS publicly;
- disable MFA for convenience;
- disable backups;
- change multiple providers at once;
- replay DLQ blindly;
- delete logs during investigation;
- rotate unrelated secrets;
- deploy unreviewed code.

---

# 51. Definition of Launch Complete

Pachi's initial public launch is operationally complete when:

1. public access has been enabled;
2. production smoke tests pass;
3. first-hour monitoring is stable;
4. no unresolved SEV-1/SEV-2 incident exists;
5. core marketplace flows are functioning;
6. backup state is healthy;
7. notification/media queues are stable;
8. first 24-hour review is complete;
9. launch outcome is recorded;
10. follow-up operational issues are assigned.

