# ADR 0006: Notification, Email, SMS, and Push Strategy

> **Status:** Proposed  
> **Date:** 2026-09-24  
> **Decision Owners:** Pachi Engineering  
> **Scope:** Transactional email, OTP/SMS delivery, notification preferences, in-app notifications, retries, provider abstraction, native push notifications, Cameroon-specific delivery controls, observability, and failure handling  
> **Supersedes:** None  
> **Superseded By:** None  
> **Related ADRs:**  
> - `0001-technology-stack.md`
> - `0002-authentication-and-session-strategy.md`
> - `0003-aws-region-and-environment-topology.md`
> - `0005-media-processing-and-storage-policy.md`

---

## 1. Context

Pachi needs reliable user communication for events such as:

- account verification;
- password and account-recovery security events;
- phone OTP verification;
- viewing requests;
- viewing acceptance, decline, rescheduling, cancellation, and reminders;
- organization invitations;
- verification status changes;
- listing status changes;
- moderation decisions;
- review eligibility;
- review publication or moderation;
- security alerts;
- operational support messages.

Pachi will serve users through:

- web;
- Android;
- iOS.

Users may have:

- unreliable mobile data;
- intermittent app usage;
- varying email quality;
- varying SMS delivery reliability;
- different notification preferences.

No single delivery channel should be assumed to be perfectly reliable.

The architecture therefore needs to separate:

```text
business event
        ↓
notification intent
        ↓
channel selection
        ↓
delivery provider
```

rather than embedding provider-specific email/SMS/push calls throughout domain modules.

---

## 2. Decision Summary

Pachi will use a **channel-independent notification service**.

Initial channel providers:

| Channel | Proposed Provider |
|---|---|
| Transactional email | Amazon SES |
| SMS / OTP | AWS End User Messaging SMS |
| Native mobile push | Expo Push Service |
| In-app notifications | Pachi PostgreSQL + API |
| Web browser push | Deferred |

Pachi will maintain provider interfaces so that these can be replaced without changing domain workflows.

Conceptually:

```text
Domain Event
    ↓
Notification Service
    ↓
Notification Record / Outbox
    ↓
SQS
    ↓
Channel Workers
    ├── EmailProvider
    ├── SmsProvider
    └── PushProvider
```

Pachi will not make external delivery providers the source of truth for product notification state.

---

## 3. Decision Drivers

### 3.1 Delivery reliability

Important events should survive:

- process restarts;
- provider outages;
- transient network failures;
- worker failures.

Notification delivery must therefore be asynchronous and durable.

### 3.2 Cameroon SMS support

SMS must support Cameroon numbers and be tested on real local networks before production use.

### 3.3 Cost control

SMS has direct per-message cost and is susceptible to abuse.

Push and in-app delivery should be preferred for normal product activity where appropriate.

### 3.4 Security

OTPs and account-security messages require stricter:

- rate limiting;
- expiration;
- logging rules;
- content rules.

### 3.5 User preferences

Users should be able to control non-essential notification channels without disabling required security messages.

### 3.6 Provider portability

Domain modules should not import SES, AWS SMS, or Expo-specific SDKs directly.

### 3.7 Mobile experience

Native push should integrate cleanly with the Expo mobile architecture selected in ADR 0001.

### 3.8 Auditability

Pachi needs to know:

- what notification was requested;
- what channels were selected;
- whether a provider accepted it;
- whether delivery failed;
- whether a user preference suppressed it.

---

# 4. Notification Architecture

The initial architecture is:

```text
Business Action
     ↓
Domain Event
     ↓
Notification Planner
     ↓
Notification Record
     ↓
Transactional Outbox
     ↓
SQS
     ↓
Channel Delivery Worker
     ↓
Provider Adapter
     ↓
Email / SMS / Push
```

This design keeps product transactions separate from external network calls.

---

# 5. Domain Events

Domain modules should produce events such as:

```text
VIEWING_REQUESTED
VIEWING_ACCEPTED
VIEWING_RESCHEDULED
VIEWING_CANCELLED
ORGANIZATION_INVITED
VERIFICATION_ACTION_REQUIRED
VERIFICATION_APPROVED
VERIFICATION_REJECTED
LISTING_PUBLISHED
LISTING_MODERATED
REVIEW_ELIGIBLE
REVIEW_PUBLISHED
ACCOUNT_SECURITY_ALERT
```

The domain event should describe what happened.

It should not decide provider-specific delivery details.

---

# 6. Notification Intent

A notification intent represents a user-facing communication request.

Conceptually:

```text
Notification
- id
- recipient_user_id
- category
- event_type
- entity_type
- entity_id
- priority
- locale
- created_at
- read_at
- archived_at
```

A separate delivery record tracks each channel attempt.

---

# 7. Delivery Record

Conceptual model:

```text
NotificationDelivery
- id
- notification_id
- channel
- provider
- destination_ref
- status
- attempt_count
- provider_message_id
- scheduled_at
- first_attempted_at
- delivered_at
- failed_at
- failure_code
- created_at
```

This separates:

```text
notification exists
```

from:

```text
a specific delivery channel succeeded
```

---

# 8. Notification Categories

Initial categories:

```text
SECURITY
ACCOUNT
INTERACTION
LISTING
VERIFICATION
ORGANIZATION
REVIEW
MODERATION
SYSTEM
MARKETING
```

Marketing is architecturally separate from transactional messaging.

This ADR primarily defines **transactional notifications**.

---

# 9. Priority Levels

Recommended priority model:

```text
CRITICAL
HIGH
NORMAL
LOW
```

Examples:

### `CRITICAL`

- account recovery;
- suspicious security event;
- privileged account change.

### `HIGH`

- OTP;
- imminent viewing change;
- moderation restriction.

### `NORMAL`

- viewing request;
- verification update;
- review eligibility.

### `LOW`

- non-urgent informational update.

Priority may affect:

- retry behavior;
- selected channels;
- delivery timing.

---

# 10. In-App Notifications

Pachi will maintain an in-app notification center.

This is the durable user-facing history for ordinary product notifications.

Examples:

```text
Your viewing request was accepted.
Your verification requires additional information.
Your listing has been published.
```

The in-app notification record exists independently of push/email delivery.

---

## 10.1 Why In-App Is Important

Email, SMS, and push may:

- fail;
- be delayed;
- be disabled;
- be blocked by the device.

The user's Pachi account should still contain the event.

---

## 10.2 Read State

Support:

```text
unread
read
archived
```

Unread count should be derived efficiently.

---

# 11. Channel Selection

The notification planner determines eligible channels based on:

```text
notification category
priority
user preference
verified destinations
device availability
security requirements
provider health
cost policy
```

Example:

```text
VIEWING_ACCEPTED
→ in-app
→ push if enabled
→ email if enabled
```

Example:

```text
PHONE_OTP
→ SMS only
```

Example:

```text
SECURITY_ALERT
→ in-app
→ email
→ push when available
```

---

# 12. Transactional Email

## 12.1 Provider

**Decision:** Amazon Simple Email Service (SES).

SES will send Pachi's transactional email.

Reasons:

- integrates with the selected AWS stack;
- managed sending infrastructure;
- domain authentication;
- delivery/bounce/complaint events;
- configurable quotas;
- support for transactional workloads.

---

## 12.2 Sending Domain

Use a Pachi-controlled authenticated domain.

Possible layout:

```text
notify.<pachi-domain>
```

or a dedicated mail subdomain.

Example sender identities:

```text
no-reply@<pachi-domain>
security@<pachi-domain>
support@<pachi-domain>
```

Final addresses depend on the acquired production domain.

---

## 12.3 Email Authentication

Configure:

```text
DKIM
SPF
DMARC
```

before production sending.

DMARC policy can be tightened after deliverability is validated.

---

## 12.4 SES Production Access

New SES environments may begin in the SES sandbox.

Before production launch:

- request SES production access;
- verify sending domain;
- validate sending quotas;
- validate sending rate.

Staging should use isolated configuration and must not send uncontrolled mail to real users.

---

# 13. Email Templates

Templates should be application-owned.

Recommended approach:

```text
template code in repository
+ localization resources
+ SES transport
```

Do not make provider-console templates the only source of truth.

This preserves:

- code review;
- versioning;
- provider portability;
- automated testing.

---

## 13.1 Template Data

Template rendering should use explicit typed variables.

Example:

```text
viewing-accepted
- recipient_name
- property_label
- scheduled_at
- deep_link
```

Avoid arbitrary HTML injection.

---

## 13.2 English and French

Transactional email must support at least:

```text
English
French
```

The recipient locale should be selected from Pachi profile/preferences.

If unavailable, use the product's configured fallback language.

---

# 14. Email Delivery Events

Pachi must process email provider events.

Relevant SES events include:

```text
SEND
DELIVERY
DELIVERY_DELAY
BOUNCE
COMPLAINT
REJECT
RENDERING_FAILURE
```

SES configuration sets and event destinations should publish operational events into Pachi/AWS monitoring.

---

## 14.1 Bounce Handling

Hard-bouncing addresses should be suppressed from further non-essential delivery.

Repeated soft failures should be monitored.

Pachi should not repeatedly retry a permanently invalid email address.

---

## 14.2 Complaint Handling

Spam complaints must affect future email sending.

Use the SES suppression list and Pachi's own destination status where appropriate.

A complaint must not disable mandatory in-app security history.

---

# 15. Email Tracking

Pachi does not initially need marketing-style open/click tracking for transactional email.

Avoid unnecessary tracking pixels where product functionality does not require them.

Operational delivery tracking is more important than engagement tracking.

---

# 16. SMS / OTP Provider

## 16.1 Primary Provider

**Decision:** AWS End User Messaging SMS.

Initial use cases:

- phone verification OTP;
- high-priority transactional SMS where explicitly approved.

Do not use SMS for every marketplace event.

---

## 16.2 Cameroon Capability

The selected provider currently supports sending SMS to Cameroon (`+237`).

AWS currently documents Cameroon support for:

- sender IDs;
- short codes;
- two-way SMS;
- international sending.

Pachi's initial use case remains outbound transactional messaging.

Two-way SMS is not part of the initial product workflow.

---

## 16.3 Cameroon Sender Identity

Preferred branding:

```text
PACHI
```

using an approved sender ID where provider/carrier requirements allow it.

Sender ID rules and regulatory requirements can change.

Before launch:

- confirm current Cameroon sender-ID requirements;
- complete any required registration/KYC;
- test the actual displayed sender identity.

---

# 17. Cameroon Number Normalization

All phone numbers must be stored canonically in:

```text
E.164
```

Cameroon example:

```text
+237XXXXXXXXX
```

Do not store phone numbers as:

```text
6xx...
00237...
237...
```

without normalization.

Display formatting is separate from canonical storage.

---

# 18. OTP Design

Phone verification OTP is defined by ADR 0002 and the verification model.

Initial proposal:

```text
6 numeric digits
5-minute validity
5 maximum verification attempts
60-second resend cooldown
```

The OTP value must be:

- cryptographically generated;
- stored only as a secure verifier/hash where feasible;
- never logged;
- never included in analytics.

---

# 19. OTP Message Content

Keep SMS short and unambiguous.

Example structure:

```text
Pachi code: 123456. Expires in 5 minutes. Do not share this code.
```

Do not include:

- property details;
- private account data;
- clickable login links unless intentionally designed and reviewed.

For SMS cost and delivery consistency, OTP messages should preferably remain within one SMS segment.

---

# 20. SMS Character Encoding

SMS segment length varies depending on character encoding.

French accents and other Unicode characters may cause UCS-2 encoding and reduce characters per segment.

For OTP messages:

- use concise text;
- prefer a one-segment template;
- test English and French templates;
- measure provider-reported segment count/cost.

Do not remove necessary language clarity merely to save a segment, but OTP templates should remain compact.

---

# 21. SMS Use Policy

SMS should be reserved primarily for:

```text
OTP
security-critical phone events
selected high-priority transactional events
```

Normal marketplace activity should prefer:

```text
in-app
push
email
```

This reduces:

- cost;
- spam perception;
- carrier filtering.

---

# 22. SMS Provider Abstraction

Define an internal interface.

Conceptually:

```text
SmsProvider
- sendTransactional()
- sendOtp()
- getDeliveryStatus()
```

Initial adapter:

```text
AwsEndUserMessagingSmsProvider
```

Potential fallback adapters:

```text
AfricasTalkingSmsProvider
TwilioSmsProvider
OtherRegionalSmsProvider
```

Domain services must not call AWS SMS APIs directly.

---

# 23. SMS Fallback Strategy

Do not automatically route the same OTP through multiple providers simultaneously.

That can:

- confuse users;
- increase cost;
- create duplicate codes/messages.

Fallback should occur only through controlled policy.

Possible strategy:

```text
primary provider fails before acceptance
        ↓
fallback provider
```

If the primary accepted the message but delivery status is uncertain, avoid immediate duplicate delivery unless the user explicitly requests resend.

---

# 24. Cameroon Provider Validation

Before production launch, perform a delivery benchmark.

At minimum test:

```text
multiple Cameroon phone numbers
multiple mobile networks
English OTP
French OTP
sender ID display
delivery latency
delivery receipt quality
failure behavior
```

The test should compare:

```text
AWS End User Messaging SMS
and
at least one serious alternative provider
```

Africa's Talking is a strong candidate because it currently documents Cameroon bulk SMS and sender-ID onboarding.

---

# 25. SMS Fraud Controls

OTP endpoints are common targets for SMS pumping / artificially inflated traffic.

Required controls:

- authenticated or pre-auth flow limits;
- IP rate limits;
- device/session limits;
- per-phone limits;
- resend cooldown;
- daily phone-attempt ceilings;
- country allowlist;
- bot protection where appropriate;
- suspicious-pattern monitoring.

---

## 25.1 Destination Allowlist

At launch, SMS sending should be restricted to countries Pachi intentionally supports.

If Pachi launches only in Cameroon:

```text
ALLOW: CM
BLOCK: other destinations
```

AWS End User Messaging protect configurations should enforce country rules where used.

---

## 25.2 SMS Spending Limit

Configure a conservative monthly SMS spending threshold.

Increase deliberately as production volume grows.

Billing alarms should trigger well before the enforced limit.

---

# 26. SMS Delivery Status

Provider acceptance is not equivalent to handset delivery.

Track statuses conceptually as:

```text
QUEUED
PROVIDER_ACCEPTED
DELIVERED
FAILED
UNKNOWN
```

Pachi should consume provider delivery events where available.

---

# 27. OTP Success vs SMS Delivery

Phone verification succeeds when the user submits the correct valid OTP.

It should not depend solely on the provider reporting `DELIVERED`.

Delivery receipts can be delayed or incomplete.

---

# 28. Push Notifications

## 28.1 Initial Provider

**Decision:** Expo Push Service.

Pachi's Expo app will use:

```text
expo-notifications
```

Initial delivery path:

```text
Pachi worker
     ↓
Expo Push Service
     ↓
FCM / APNs
     ↓
device
```

---

## 28.2 Why Expo Push Initially

Benefits:

- unified Android/iOS API;
- natural fit with Expo/EAS;
- reduced server-side FCM/APNs complexity;
- delivery receipts;
- no direct push-service cost for initial usage.

Pachi can later send directly to FCM/APNs if more control is required.

---

# 29. Push Token Model

Store push registrations per device/app installation.

Conceptually:

```text
PushEndpoint
- id
- user_id
- platform
- expo_push_token
- native_push_token
- device_installation_id
- app_version
- enabled
- last_seen_at
- invalidated_at
```

Where practical, retain native tokens as well as Expo tokens to preserve future provider portability.

---

# 30. Push Permission

The mobile app should request push permission contextually.

Do not require push permission to use Pachi.

A user declining push must still receive:

- in-app notifications;
- required email/SMS according to policy.

---

# 31. Invalid Push Tokens

If Expo/FCM/APNs indicates that a device is no longer registered:

```text
PushEndpoint.enabled = false
```

or invalidate the token.

Do not repeatedly retry permanently invalid device tokens.

---

# 32. Push Payload Privacy

Lock-screen notifications may be visible to other people.

Do not include highly sensitive data such as:

- identity document status details beyond necessary wording;
- private verification evidence;
- full private address;
- OTP;
- moderation evidence.

Prefer generic safe text where sensitivity exists.

Example:

```text
You have a new verification update.
```

rather than exposing private details.

---

# 33. Push Deep Links

Push notifications may include an application route.

Example:

```text
pachi://interactions/<id>
```

or equivalent Expo Router deep-link destination.

The destination screen must still authorize access server-side.

A deep link is navigation, not authorization.

---

# 34. Web Push Notifications

Browser web push is deferred.

Reasons:

- Expo Push Service does not provide web browser push;
- browser push introduces service-worker and browser permission complexity;
- initial Pachi users still have in-app and email channels.

A future web-push ADR may evaluate:

- native Web Push APIs;
- Firebase Cloud Messaging for web;
- another provider.

---

# 35. Notification Preferences

Pachi should store preferences in its own database.

Conceptually:

```text
NotificationPreference
- user_id
- category
- email_enabled
- push_enabled
- sms_enabled
- updated_at
```

---

# 36. Mandatory Notifications

Some messages cannot be disabled through ordinary notification preferences.

Examples:

```text
password/account recovery
email change
phone verification OTP
security alerts
legal/account enforcement notices
critical moderation decisions
```

The exact mandatory set must remain narrowly defined.

---

# 37. Configurable Notifications

Examples:

```text
new viewing request
viewing reminder
review eligibility
listing activity
organization activity
product updates
```

Users may control channel preferences for these categories.

---

# 38. Marketing Consent

Marketing/promotional messaging must be separate from transactional notification preferences.

Do not interpret:

```text
has Pachi account
```

as:

```text
consents to marketing SMS/email
```

Marketing consent and unsubscribe behavior require explicit policy and legal review.

---

# 39. Default Preferences

Recommended initial defaults:

| Category | In-App | Push | Email | SMS |
|---|---:|---:|---:|---:|
| Security | Yes | Yes | Yes | Only where required |
| Interaction | Yes | Yes | Yes | No |
| Verification | Yes | Yes | Yes | OTP only / exceptional |
| Listing | Yes | Yes | Optional | No |
| Organization | Yes | Yes | Yes | No |
| Review | Yes | Yes | Optional | No |
| Moderation | Yes | Yes | Yes | Exceptional |
| Marketing | Opt-in | Opt-in | Opt-in | Opt-in |

Final defaults require product/privacy approval.

---

# 40. Quiet Hours

Pachi may later support user-configurable quiet hours.

Critical notifications such as:

- security alerts;
- OTP requested by the user;
- imminent cancellation/change;

may bypass quiet hours where appropriate.

MVP can defer quiet-hour configuration.

---

# 41. Notification Localization

Templates must support:

```text
English
French
```

All delivery jobs should carry the selected locale.

Do not render language dynamically inside provider adapters.

Render from Pachi-controlled templates.

---

# 42. Time and Timezones

Notification timestamps shown to users should respect the relevant user/property context.

Cameroon uses West Africa Time:

```text
UTC+1
```

Store timestamps in UTC internally.

Render them in the correct display timezone.

Do not bake Cameroon local time directly into stored timestamps.

---

# 43. Notification Outbox

Pachi should use a transactional outbox pattern for domain-triggered notifications.

Example:

```text
database transaction
├── update interaction
└── insert notification_outbox event

commit
    ↓
outbox publisher
    ↓
SQS
```

This prevents:

```text
database update succeeded
but notification event was lost
```

---

# 44. Queue Strategy

Use Amazon SQS for asynchronous delivery.

Potential queues:

```text
notification-email
notification-sms
notification-push
```

or one queue with typed messages.

Start simple and split queues where scaling/failure isolation justifies it.

---

# 45. Delivery Idempotency

A retry must not accidentally send duplicate notifications.

Each delivery should have an idempotency/deduplication key.

Example:

```text
notification_id + channel + recipient_destination_version
```

Before sending, the worker should determine whether that logical delivery has already succeeded.

---

# 46. Retry Policy

Retries depend on failure type.

### Retryable

Examples:

- provider timeout;
- HTTP 5xx;
- temporary throttling;
- network failure.

Use exponential backoff with jitter.

### Non-retryable

Examples:

- invalid email;
- invalid phone number;
- permanently invalid push token;
- user unsubscribed/suppressed;
- provider rejects unsupported destination.

Mark failed without repeated retry.

---

# 47. Suggested Retry Schedule

Normal transactional delivery may use approximately:

```text
attempt 1: immediate
attempt 2: +1 minute
attempt 3: +5 minutes
attempt 4: +15 minutes
attempt 5: +1 hour
```

Exact schedules should be adjusted per channel and provider behavior.

OTP SMS must **not** keep retrying after the OTP expires.

---

# 48. Dead-Letter Queue

Permanently exhausted asynchronous deliveries should move to a dead-letter queue.

Monitor:

```text
DLQ message count
oldest DLQ message
channel
failure reason
```

A DLQ is an operational signal, not a long-term notification database.

---

# 49. Provider Rate Limits

Workers must respect:

- SES send rate;
- SMS provider throughput;
- Expo Push Service throughput;
- account quotas.

Implement backpressure rather than repeatedly triggering throttling.

---

# 50. Delivery Ordering

Pachi must not assume strict cross-channel ordering.

Example:

```text
push may arrive before email
```

Notification wording must remain understandable independently.

For sequences where order matters, encode state in the product rather than relying on message arrival order.

---

# 51. Notification Deduplication

Domain workflows may emit repeated equivalent events.

Example:

```text
VIEWING_RESCHEDULED
```

multiple times during rapid edits.

Where appropriate, Pachi may collapse low-priority stale notifications before delivery.

Never collapse:

- OTP;
- security events;
- legally important notices;

without explicit rules.

---

# 52. Reminders

Scheduled reminders should be created as durable jobs.

Example:

```text
viewing scheduled
    ↓
create reminder job
    ↓
T - 24h
T - 2h
```

If the viewing is cancelled or rescheduled, obsolete reminder jobs must be invalidated.

---

# 53. OTP Channel Independence

OTP generation belongs to Pachi's verification/auth domain.

The SMS provider receives:

```text
destination
rendered message
provider metadata
```

It must not become the source of truth for:

- OTP validity;
- attempt count;
- verification success.

---

# 54. Email Account Verification

ADR 0002 assigns Cognito local-account email verification to Cognito/SES-backed authentication workflows.

Pachi's general notification service should not duplicate Cognito's built-in verification flow unless the authentication architecture is intentionally changed.

General SES transactional email remains separate from Cognito-managed verification messages.

---

# 55. Notification Provider Interfaces

Proposed interfaces:

```text
EmailProvider
- send(message)
- getStatus(providerMessageId)

SmsProvider
- send(message)
- getStatus(providerMessageId)

PushProvider
- send(message)
- getReceipt(providerMessageId)
```

Normalized provider result:

```text
ProviderDeliveryResult
- accepted
- provider_message_id
- status
- retryable
- error_code
```

---

# 56. Provider-Specific Metadata

Provider-specific fields must not leak broadly into domain tables.

Use a bounded metadata structure where necessary.

Example:

```text
provider_metadata
```

with security and size limits.

---

# 57. Secrets

Provider credentials belong in:

```text
AWS Secrets Manager
```

or equivalent approved secret storage.

Do not store:

- SMS API keys;
- Expo push access credentials;
- email provider secrets;

in Git or application configuration files committed to the repository.

---

# 58. SES Bounce and Complaint Processing

SES requires Pachi to handle bounce and complaint feedback.

Use SES configuration sets and an event destination.

Potential integration:

```text
SES
 ↓
EventBridge / SNS
 ↓
Pachi notification-event handler
```

Update Pachi destination state accordingly.

---

# 59. Email Destination State

Conceptual model:

```text
EmailDestination
- user_id
- email
- verified
- deliverability_status
- last_bounce_at
- last_complaint_at
```

Possible deliverability states:

```text
ACTIVE
TEMPORARILY_FAILED
SUPPRESSED
INVALID
```

Authentication identity/email truth still belongs to the auth design.

---

# 60. SMS Destination State

Conceptual operational metadata:

```text
PhoneDestination
- user_id
- phone_e164
- verified
- deliverability_status
- last_delivery_at
- last_failure_at
```

A transient carrier failure must not automatically remove phone verification.

---

# 61. Push Endpoint State

Possible states:

```text
ACTIVE
DISABLED_BY_USER
INVALID
STALE
```

The user may have multiple active devices.

---

# 62. Notification Security

Never include secrets in normal notifications.

Specifically:

- no password;
- no refresh token;
- no full identity-document number;
- no raw verification document;
- no private internal moderation notes.

OTP is the one intentional short-lived secret delivered over SMS and must follow strict OTP rules.

---

# 63. Anti-Enumeration

OTP and account-recovery flows must avoid exposing whether another person's account exists.

Responses should be intentionally generic where required by ADR 0002.

Notification sending behavior must not undermine those protections through observable API responses.

---

# 64. Logs

Do not log full notification payloads indiscriminately.

Recommended operational logging:

```text
notification_id
delivery_id
channel
provider
template_id
destination_hash_or_redacted
provider_status
attempt
latency
error_code
```

Avoid full:

- email body;
- SMS OTP;
- push private content.

---

# 65. Audit Requirements

Security/trust-sensitive notifications require durable audit events.

Examples:

- OTP requested;
- phone verification message sent;
- email-change warning sent;
- account recovery notification sent;
- moderation notice generated;
- notification preference changed;
- provider delivery permanently failed where operationally relevant.

Do not store OTP values in audit logs.

---

# 66. Observability

Track metrics by:

```text
channel
provider
template
environment
category
```

Key metrics:

```text
requested
queued
provider accepted
delivered
failed
retrying
suppressed
latency
cost
```

---

# 67. Email Metrics

Track:

```text
send success
delivery
delivery delay
hard bounce
soft bounce
complaint
rejection
render failure
SES quota usage
```

---

# 68. SMS Metrics

Track:

```text
attempted
provider accepted
delivered
failed
unknown
latency
segments
cost
OTP verification success
resend rate
fraud/rate-limit blocks
```

---

# 69. Push Metrics

Track:

```text
push requested
Expo accepted
push receipt success/error
invalid device token
delivery pipeline latency
push opt-in rate
```

Push-provider acceptance must not be treated as proof that a person read the notification.

---

# 70. Alerting

Operational alerts should include:

- email bounce/complaint spike;
- SES quota exhaustion;
- SMS spend anomaly;
- SMS provider outage/failure spike;
- OTP delivery latency spike;
- push failure spike;
- queue backlog;
- DLQ growth;
- notification worker failures.

---

# 71. Cost Controls

## Email

Use:

- SES quotas;
- template deduplication;
- preference checks before queueing optional mail;
- suppression handling.

## SMS

Use:

- country restrictions;
- spending thresholds;
- rate limits;
- one-segment OTP templates;
- channel selection rules;
- no marketing SMS without explicit approval.

## Push

Push is preferred for many non-critical mobile events because incremental delivery cost is much lower than SMS.

---

# 72. Provider Health

The notification service should expose provider health state.

Example:

```text
HEALTHY
DEGRADED
UNAVAILABLE
```

Provider health may influence fallback policy.

Do not automatically switch providers based on one transient failure.

---

# 73. Multi-Channel Fallback

Fallback should be notification-specific.

Example:

```text
important interaction update
push fails
→ in-app remains available
→ email may still deliver
```

Example:

```text
phone OTP SMS fails
→ allow resend
→ provider fallback may be attempted
```

Do not silently turn every failed push into paid SMS.

---

# 74. Staging Safety

Staging must not accidentally contact production users.

Controls should include:

- separate SES/SMS configuration;
- destination allowlist;
- test email domains where practical;
- verified test phone numbers;
- clear environment prefix in non-production messages.

Example:

```text
[STAGING] Pachi ...
```

---

# 75. Development

Local development should use adapters such as:

```text
ConsoleEmailProvider
ConsoleSmsProvider
ConsolePushProvider
```

or provider sandbox/test environments.

Developers should not need production delivery credentials to run Pachi locally.

---

# 76. Notification Testing

Automated tests should verify:

- event creates correct notification intent;
- user preference suppresses optional channel;
- mandatory security channel is not suppressed incorrectly;
- retries occur only for retryable failures;
- duplicate job does not duplicate successful delivery;
- expired OTP is not retried;
- invalid push token is disabled;
- email hard bounce suppresses further optional mail;
- locale selects correct template.

---

# 77. Cameroon Production SMS Test

Before launch, execute an explicit test matrix.

Example:

| Test | Expected |
|---|---|
| Valid `+237` number | Accepted |
| Invalid Cameroon number | Rejected safely |
| English OTP | Delivered promptly |
| French OTP | Delivered promptly |
| Sender ID | Displays as approved |
| Repeated resend | Rate limited |
| Provider outage | Retry/fallback behavior works |
| Delivery report | Parsed correctly |
| Spending limit reached | Alert generated |

Tests should include more than one carrier/network where practical.

---

# 78. Alternatives Considered

## 78.1 Amazon SES

**Selected for transactional email.**

Advantages:

- AWS integration;
- scalable API;
- event publishing;
- domain authentication;
- suppression tools;
- adjustable sending quotas.

Disadvantages:

- initial sandbox/production-access process;
- more template/UI work than developer-focused email SaaS products.

---

## 78.2 SendGrid

### Advantages

- mature transactional email;
- templates;
- analytics;
- broad ecosystem.

### Reasons not selected initially

- another foundational provider;
- SES already fits the proposed AWS platform;
- Pachi does not need advanced marketing-email features at launch.

---

## 78.3 Postmark

### Advantages

- strong transactional-email focus;
- excellent developer experience;
- good delivery tooling.

### Reasons not selected initially

SES is sufficient and keeps transactional delivery closer to the selected infrastructure platform.

Postmark remains a fallback if SES deliverability or operational overhead becomes problematic.

---

## 78.4 Resend

### Advantages

- modern developer experience;
- simple API;
- strong React/TypeScript ecosystem fit.

### Reasons not selected initially

Pachi can achieve the required transactional capabilities with SES while reducing foundational provider count.

---

## 78.5 AWS End User Messaging SMS

**Selected as the initial SMS/OTP provider.**

Advantages:

- supports Cameroon;
- supports sender IDs for Cameroon;
- AWS-native billing/IAM/monitoring;
- SMS Protect controls;
- country allow/block rules;
- spending limits.

Disadvantages:

- production-access process;
- international carrier behavior can vary;
- AWS documentation itself recommends redundant channels for business-critical communication.

---

## 78.6 Africa's Talking

### Advantages

- Africa-focused messaging provider;
- current Cameroon bulk-SMS offering;
- Cameroon sender-ID registration process;
- delivery-report support;
- strong candidate for local-route comparison.

### Reasons not selected as the first provider

Pachi's primary infrastructure is already AWS-based, and AWS End User Messaging currently provides the required Cameroon outbound capabilities.

Africa's Talking should be benchmarked before launch and remains a strong fallback/provider-diversification candidate.

---

## 78.7 Twilio SMS

### Advantages

- mature global API;
- strong developer tooling;
- published Cameroon messaging guidance.

### Reasons not selected initially

- additional vendor;
- Pachi does not currently need Twilio's broader communications platform;
- real Cameroon delivery quality and cost should be benchmarked rather than assumed.

Twilio remains a fallback candidate.

---

## 78.8 SMS as Primary Notification Channel

### Advantages

- works without smartphone app;
- high visibility.

### Reasons not selected

- direct variable cost;
- spam/fraud exposure;
- delivery uncertainty;
- limited content;
- carrier filtering.

SMS is reserved for high-value cases.

---

## 78.9 Expo Push Service

**Selected for initial native push.**

Advantages:

- integrated with Expo;
- unified Android/iOS API;
- routes through FCM/APNs;
- delivery receipts;
- no direct Expo push-send fee currently.

Disadvantages:

- another hop in the delivery path;
- throughput limits;
- fewer provider-specific controls than direct APNs/FCM.

---

## 78.10 Direct FCM + APNs From Launch

### Advantages

- full platform control;
- direct integration;
- no Expo push relay.

### Reasons not selected initially

Expo Push Service is simpler and sufficient for expected launch scale.

Pachi will retain native device tokens where practical so it can migrate later.

---

## 78.11 Firebase Cloud Messaging for Both Android and iOS

### Advantages

- cross-platform service;
- large ecosystem;
- advanced messaging capabilities.

### Reasons not selected initially

It adds additional Firebase coupling without a current need.

Expo Push is adequate for the initial native app.

---

## 78.12 Browser Push at Launch

### Advantages

- re-engages web users;
- low marginal delivery cost.

### Reasons not selected

- added permission/service-worker complexity;
- Expo Push does not provide browser push;
- email and in-app channels are sufficient for initial web users.

---

## 78.13 Synchronous Notification Sending

### Advantages

- simple;
- immediate provider response.

### Reasons not selected

External delivery should not hold open or fail core business transactions.

SQS/outbox processing is more durable.

---

## 78.14 Provider-Specific Calls Inside Domain Modules

### Advantages

- fastest initial coding.

### Reasons not selected

Creates:

- lock-in;
- duplicated retry logic;
- inconsistent preferences;
- difficult testing.

All delivery goes through provider abstractions.

---

# 79. Consequences

## 79.1 Positive

- durable asynchronous notification delivery;
- no critical workflow depends on one external provider;
- strong AWS integration;
- Cameroon SMS support with pre-launch benchmark requirement;
- user-controlled optional notification preferences;
- clear mandatory-security notification boundary;
- portable provider interfaces;
- bilingual template architecture;
- push aligned with Expo;
- central observability and retry behavior;
- SMS abuse/spend controls.

## 79.2 Negative

- notification subsystem adds queues and worker state;
- multiple delivery providers increase integration work;
- provider delivery semantics differ;
- SMS cost varies with volume and encoding;
- Expo push adds an additional intermediary;
- maintaining bilingual templates requires discipline;
- fallback behavior must be carefully designed to avoid duplicate messages.

---

# 80. Risks and Mitigations

## SMS pumping / OTP abuse

Mitigation:

- rate limiting;
- destination allowlist;
- AWS Protect configuration;
- spending thresholds;
- device/IP/phone controls;
- OTP cooldown.

## Cameroon SMS delivery inconsistency

Mitigation:

- pre-launch carrier benchmark;
- provider abstraction;
- fallback provider readiness;
- push/email alternatives.

## Email reputation problems

Mitigation:

- SPF/DKIM/DMARC;
- bounce/complaint processing;
- suppression;
- separate transactional use;
- gradual sending-volume growth.

## Push token churn

Mitigation:

- receipt processing;
- invalidate `DeviceNotRegistered`;
- device registration lifecycle.

## Duplicate delivery

Mitigation:

- delivery idempotency keys;
- channel-specific status;
- no blind retries.

## Provider outage

Mitigation:

- durable queue;
- retries;
- provider health;
- multi-channel delivery;
- controlled fallback.

## Notification privacy leak

Mitigation:

- safe lock-screen text;
- no sensitive payloads;
- deep links authorize after opening.

---

# 81. Open Decisions

### NOTIF-OD-001 — SMS benchmark winner

Does AWS End User Messaging remain the primary provider after real Cameroon testing against Africa's Talking or another provider?

**Current status:** Proposed pending benchmark.

---

### NOTIF-OD-002 — Cameroon SMS sender ID

What exact sender identity will be registered?

**Current recommendation:** `PACHI`.

---

### NOTIF-OD-003 — SMS fallback provider

Which secondary provider should be production-ready?

Candidates:

```text
Africa's Talking
Twilio
another proven Cameroon route provider
```

**Current recommendation:** Benchmark Africa's Talking first.

---

### NOTIF-OD-004 — Viewing reminders

Which reminder schedule should MVP use?

Possible baseline:

```text
24 hours before
2 hours before
```

**Current status:** Product decision.

---

### NOTIF-OD-005 — Browser push

When should web push be introduced?

**Current recommendation:** Post-MVP unless user behavior shows strong need.

---

### NOTIF-OD-006 — Quiet hours

Should configurable quiet hours ship in MVP?

**Current recommendation:** Defer.

---

### NOTIF-OD-007 — Optional email defaults

Should review/listing informational email be enabled by default?

**Current status:** Product/privacy decision.

---

### NOTIF-OD-008 — Expo Push direct-provider migration threshold

What scale or feature requirement would trigger migration to direct APNs/FCM?

**Current recommendation:** Re-evaluate if Expo throughput/features become a measured constraint.

---

# 82. Decisions Established by This ADR

If accepted:

1. Pachi uses a channel-independent notification architecture.
2. Pachi persists in-app notifications independently of external channel delivery.
3. Amazon SES is the initial transactional-email provider.
4. AWS End User Messaging SMS is the proposed initial SMS/OTP provider.
5. The SMS decision remains contingent on Cameroon production testing.
6. Expo Push Service is the initial Android/iOS push provider.
7. Browser push is deferred.
8. Domain modules do not directly call notification providers.
9. Notification delivery uses durable asynchronous queues.
10. Transactional outbox behavior prevents lost domain-triggered notifications.
11. Delivery workers implement idempotency and bounded retries.
12. OTP SMS is short-lived, rate-limited, and not retried after expiry.
13. SMS is reserved for OTP/security and selected high-priority use cases.
14. User preferences may suppress optional channels but not narrowly defined mandatory security communications.
15. English and French notification templates are application-owned and version-controlled.
16. SES bounce/complaint feedback is processed.
17. Push invalid-token receipts disable obsolete device endpoints.
18. Cameroon SMS destinations use normalized E.164 `+237` numbers.
19. Production SMS uses country restrictions and spending controls.
20. At least one alternative SMS provider is benchmarked before launch.

---

# 83. Acceptance Criteria

This ADR may move from **Proposed** to **Accepted** when:

- SES production sending strategy is approved;
- the production email domain is known or the configuration approach is accepted;
- SMS production access requirements are understood;
- Cameroon SMS delivery is tested across representative networks;
- AWS SMS is compared with at least one serious alternative;
- sender-ID registration requirements are confirmed;
- OTP templates are tested in English and French;
- notification preference defaults are approved;
- mandatory notification categories are approved;
- Expo push works in Android and iOS production-like builds;
- retry/DLQ behavior is tested;
- no known privacy/security requirement conflicts with the design.

---

# 84. Follow-Up Work

After acceptance:

1. configure SES domain identity;
2. configure SPF/DKIM/DMARC;
3. request SES production access;
4. configure SES event publishing and suppression behavior;
5. request AWS SMS production access;
6. configure Cameroon SMS sender identity;
7. configure SMS Protect country rules;
8. configure SMS spend limits and alarms;
9. benchmark AWS SMS against Africa's Talking or another provider;
10. implement notification/outbox tables;
11. implement SQS delivery pipeline;
12. implement email provider adapter;
13. implement SMS provider adapter;
14. implement Expo push adapter;
15. implement device push-token registration;
16. implement delivery receipt handling;
17. implement user notification preferences;
18. implement English/French templates;
19. create notification dashboards and alerts;
20. document operational fallback procedures.

---

# 85. References

Implementation should be checked against current official documentation for:

- Amazon SES;
- SES production access and sending quotas;
- SES domain authentication;
- SES configuration sets and event publishing;
- SES bounce/complaint suppression;
- AWS End User Messaging SMS;
- AWS SMS supported countries and Cameroon capabilities;
- AWS SMS sender IDs;
- AWS SMS sandbox and production access;
- AWS SMS Protect configurations;
- AWS SMS spending limits;
- Expo push notifications;
- Expo Push Service receipts and retry guidance;
- FCM and APNs integration through Expo;
- Africa's Talking Cameroon SMS onboarding;
- Twilio Cameroon messaging guidelines.

Messaging coverage, sender-ID requirements, prices, carrier routes, quotas, and provider behavior change frequently and must be rechecked before production launch.
