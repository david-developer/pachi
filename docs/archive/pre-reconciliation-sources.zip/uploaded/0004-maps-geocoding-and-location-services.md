# ADR 0004: Maps, Geocoding, and Location Services

> **Status:** Proposed  
> **Date:** 2026-09-24  
> **Decision Owners:** Pachi Engineering  
> **Scope:** Map rendering, geocoding, place search, address normalization, neighborhood modeling, location privacy, Cameroon coverage, cost controls, and web/mobile integration  
> **Supersedes:** None  
> **Superseded By:** None  
> **Related ADRs:**  
> - `0001-technology-stack.md`
> - `0002-authentication-and-session-strategy.md`
> - `0003-aws-region-and-environment-topology.md`

---

## 1. Context

Location is a core part of Pachi.

The product must support:

- property creation;
- property search;
- map-based discovery;
- proximity filtering;
- city and neighborhood filtering;
- provider-entered location information;
- reliable property coordinates;
- web and mobile map display;
- English and French users;
- incomplete or inconsistent street-address data;
- privacy-sensitive residential locations.

Pachi must not assume that every property in Cameroon has:

- a complete street address;
- a house number;
- a postal code;
- a consistently recognized neighborhood name;
- a geocoder result precise enough to represent the property.

The location system must therefore work even when the strongest available location information is:

```text
city
+ neighborhood
+ landmark
+ manually confirmed map pin
```

Pachi already proposes:

```text
PostgreSQL + PostGIS
```

as its internal geospatial source of truth.

The external map/geocoding provider should enrich this model, not replace it.

---

## 2. Decision Summary

Pachi will initially use **Google Maps Platform** as its primary external mapping and place-search provider.

Initial Google services:

```text
Maps JavaScript API
Maps SDK for Android
Maps SDK for iOS
Places API (New)
Geocoding API
```

Pachi will **not** depend on Google Address Validation API for Cameroon at launch because Cameroon is not currently listed among the supported Address Validation API countries.

Pachi's location architecture will be provider-independent at the domain layer.

The canonical Pachi location model will be based on:

```text
provider-confirmed coordinates
+ Pachi canonical administrative entities
+ Pachi canonical neighborhood
+ user-confirmed display address
+ optional landmark / directions
+ optional external place identifier
```

Google data will assist users with:

- address/place suggestions;
- forward geocoding;
- reverse geocoding;
- map visualization;
- pin placement.

Google will not be treated as the authoritative source for Pachi neighborhood identity.

Pachi will maintain its own:

```text
regions
cities
neighborhoods
neighborhood aliases
optional neighborhood boundaries
```

inside PostgreSQL/PostGIS.

---

## 3. Decision Drivers

### 3.1 Cameroon coverage

The selected provider must have useful coverage in Cameroon for:

- map tiles;
- geocoding;
- driving context;
- walking context;
- named places;
- major roads and landmarks.

Google currently classifies Cameroon as having good availability for core map tiles, geocoding, traffic, driving directions, and walking directions.

Coverage quality must still be tested in Pachi's actual launch cities.

---

### 3.2 Weak or inconsistent formal addressing

Pachi must support location entry even when a user cannot provide a conventional postal address.

The system therefore needs:

- map pin placement;
- reverse geocoding;
- landmarks;
- free-text directions;
- city/neighborhood selection.

---

### 3.3 Search quality

A housing marketplace needs normalized location dimensions such as:

```text
country
region
city
neighborhood
coordinates
```

Search must not depend on matching arbitrary address strings.

---

### 3.4 Geospatial filtering

Pachi needs:

- radius search;
- map viewport search;
- bounding-box queries;
- distance sorting;
- point-in-polygon neighborhood assignment where boundaries exist.

These operations belong in PostGIS.

---

### 3.5 Mobile and web support

The selected approach must work across:

- Next.js web;
- Expo/React Native Android;
- Expo/React Native iOS.

---

### 3.6 Cost predictability

Map and place APIs can generate substantial usage through:

- autocomplete;
- map loads;
- reverse geocoding;
- repeated refreshes;
- poorly implemented map movement listeners.

The architecture must minimize unnecessary external API calls.

---

### 3.7 Vendor portability

Pachi should be able to replace or supplement Google later without redesigning the property data model.

---

### 3.8 Location privacy

Some providers may not want to expose the exact location of a property publicly before a viewing or direct interaction.

Pachi must separate:

```text
stored exact location
```

from:

```text
publicly displayed location
```

---

## 4. Primary Provider

### 4.1 Decision

**Primary provider:** Google Maps Platform

Use Google for:

- interactive basemaps;
- place/address autocomplete;
- place lookup;
- forward geocoding;
- reverse geocoding;
- provider-assisted map pin placement.

---

### 4.2 Why Google

The initial choice is driven by:

- documented Cameroon core-map and geocoding coverage;
- mature Android and iOS map SDKs;
- mature Maps JavaScript API;
- Places API;
- forward and reverse geocoding;
- strong developer ecosystem;
- support for English and French user experiences;
- existing compatibility with Expo through `react-native-maps`.

---

### 4.3 Provider Abstraction

Application domain code must not depend directly on Google response objects.

Define an internal abstraction such as:

```text
LocationProvider
- autocomplete(query, context)
- geocode(input, context)
- reverseGeocode(point, context)
- resolvePlace(externalPlaceId)
```

Provider-specific adapters may include:

```text
GoogleLocationProvider
FutureMapboxLocationProvider
FutureOSMLocationProvider
```

The rest of the application should consume Pachi-normalized results.

---

## 5. Pachi Location Source of Truth

The authoritative property location is stored in Pachi's database.

A property should not depend on an external provider response remaining available.

Canonical example:

```text
PropertyLocation
- id
- property_id
- country_code
- region_id
- city_id
- neighborhood_id
- latitude
- longitude
- location_precision
- public_location_mode
- display_address
- landmark
- directions
- external_provider
- external_place_id
- confirmed_by_user
- confirmed_at
```

Exact database design will be finalized in the database schema.

---

## 6. Country Model

Initial market:

```text
country_code = CM
country_name = Cameroon
```

Use ISO country codes rather than free-text country names for internal filtering.

Pachi's architecture should allow additional countries later.

---

## 7. Administrative Location Model

Pachi should maintain canonical administrative entities.

Conceptually:

```text
Country
   ↓
Region
   ↓
City / Locality
   ↓
Neighborhood
```

Relationships should be explicit rather than inferred repeatedly from geocoding strings.

---

## 8. Cameroon Regions

Cameroon's top-level regional entities should exist as canonical Pachi records.

Use stable internal IDs.

Display names may support:

```text
English
French
aliases
```

Do not make translated display text the database primary key.

---

## 9. Cities and Localities

Pachi should maintain a controlled city/locality table for supported markets.

Examples may include major launch locations such as:

```text
Douala
Yaoundé
Buea
Limbe
Bamenda
Bafoussam
Kribi
Garoua
```

This list is illustrative, not the final launch scope.

New localities can be added without changing property schema.

---

# 10. Neighborhood Model

## 10.1 Neighborhoods are Pachi-owned entities

A neighborhood should have a stable Pachi ID.

Example:

```text
Neighborhood
- id
- city_id
- canonical_name
- normalized_name
- status
- boundary_geometry
- centroid
- created_at
- updated_at
```

---

## 10.2 Neighborhood aliases

Support alternative names and spelling variations.

Example:

```text
NeighborhoodAlias
- id
- neighborhood_id
- alias
- normalized_alias
- language
```

This supports:

- alternative spellings;
- French/English variants;
- local abbreviations;
- informal names.

---

## 10.3 Do not auto-create neighborhoods from geocoder output

External providers may return:

- inconsistent locality labels;
- obsolete labels;
- administrative areas rather than locally understood neighborhoods;
- different names for nearby coordinates.

A geocoder result may suggest a neighborhood.

It must not automatically create a new canonical neighborhood record.

New neighborhoods require:

```text
curation
or
moderation/administrative approval
```

---

## 10.4 Neighborhood boundaries

Where reliable boundary polygons exist, store them in PostGIS.

Then:

```text
property point
    ↓
ST_Contains / ST_Intersects
    ↓
canonical neighborhood
```

Boundary geometry is optional.

Where reliable boundaries do not exist, use:

- curated neighborhood selection;
- centroid;
- aliases;
- approximate boundaries;
- administrative review.

---

## 10.5 Neighborhood search

User-facing neighborhood search should query Pachi's own neighborhood index.

Do not call Google Places every time a seeker filters by a Pachi neighborhood.

---

# 11. Address Model

Pachi must distinguish between:

```text
postal/street address
display address
map location
landmark
directions
administrative location
```

These are related but not identical.

---

## 11.1 Canonical fields

Recommended conceptual model:

```text
country_code
region_id
city_id
neighborhood_id

latitude
longitude

display_address
landmark
directions

location_precision
public_location_mode
```

---

## 11.2 Display address

`display_address` is the human-readable location accepted or entered by the provider.

Examples:

```text
Bonamoussadi, Douala
Molyko, Buea
Near Mile 17, Buea
Bastos, Yaoundé
```

The provider should be able to correct or supplement provider-generated text.

---

## 11.3 Landmark

`landmark` is optional.

Examples:

```text
Near Total Molyko
Opposite the university gate
Behind the market
```

Landmarks are valuable where formal street addressing is weak.

They must not replace coordinates.

---

## 11.4 Directions

`directions` is optional provider-supplied text intended to help a legitimate viewer locate the property.

It may be hidden until an interaction reaches a permitted state if privacy rules require it.

---

# 12. Address Normalization

## 12.1 Do not normalize solely through a third-party address string

Pachi normalization occurs by mapping the user's confirmed location into Pachi fields.

Example:

```text
Input:
"Bonamoussadi, Douala, Cameroon"

External provider:
suggestions + coordinates

Pachi confirmation:
country = CM
region = Littoral
city = Douala
neighborhood = Bonamoussadi
point = confirmed pin
display_address = user-confirmed text
```

---

## 12.2 Normalized text

For search and duplicate detection, Pachi may derive internal normalized versions.

Examples:

```text
lowercase
trim whitespace
Unicode normalization
punctuation normalization
alias resolution
```

Never overwrite the user's intended display value purely because normalization changes it.

---

## 12.3 External address validation

Google Address Validation API is **not** part of the initial Cameroon architecture.

Cameroon is not currently listed among its supported countries.

Pachi must therefore not make listing creation depend on a postal-address validation service that does not officially support the launch country.

---

# 13. Location Precision

Each property should record how precise its stored location is.

Recommended values:

```text
EXACT_PIN
APPROXIMATE_PIN
NEIGHBORHOOD
CITY
```

---

## 13.1 `EXACT_PIN`

Provider explicitly confirmed the property point.

Suitable for:

- distance search;
- map discovery;
- operational directions.

The exact point does not necessarily need to be public.

---

## 13.2 `APPROXIMATE_PIN`

The pin is intentionally approximate.

Useful when:

- provider does not want to expose exact location;
- property entrance is unclear;
- available geocoding is imprecise.

---

## 13.3 `NEIGHBORHOOD`

No trusted property point exists.

Search can use:

- neighborhood relationship;
- neighborhood centroid/boundary.

---

## 13.4 `CITY`

Only city-level location is known.

This should be allowed for drafts but may be insufficient for publishing depending on listing rules.

---

# 14. Location Privacy

## 14.1 Exact location and public location are separate

Recommended `public_location_mode` values:

```text
EXACT
APPROXIMATE
NEIGHBORHOOD_ONLY
HIDDEN
```

---

## 14.2 `EXACT`

Public map uses the confirmed exact point.

Suitable where provider explicitly allows it.

---

## 14.3 `APPROXIMATE`

Pachi publicly renders a deterministic or generated nearby location rather than the exact stored point.

The implementation must not permanently overwrite the real coordinate.

---

## 14.4 `NEIGHBORHOOD_ONLY`

Public UI shows:

- neighborhood;
- city;
- neighborhood map area or centroid.

Exact coordinate remains private.

---

## 14.5 `HIDDEN`

Public listing may show only high-level locality text.

Use only where product rules permit.

---

## 14.6 Default recommendation

Recommended public default for residential listings:

```text
APPROXIMATE
```

or:

```text
NEIGHBORHOOD_ONLY
```

depending on provider preference and property type.

Exact address disclosure can occur later in the interaction lifecycle when appropriate.

---

# 15. Property Creation Location Flow

Recommended provider flow:

```text
1. choose city / locality
2. search for address, place, or landmark
3. receive location suggestions
4. select suggestion
5. map centers on candidate point
6. provider moves pin if necessary
7. provider confirms location
8. choose canonical neighborhood
9. enter optional landmark/directions
10. select public-location privacy mode
11. save Pachi canonical location
```

The pin-confirmation step is important.

The geocoder suggests.

The provider confirms.

---

# 16. Map Pin Placement

Providers must be able to place or adjust a map pin manually.

This is a first-class location input method, not merely a fallback error flow.

Manual pin placement is especially important when:

- street address is missing;
- search returns the wrong property;
- multiple properties share a location label;
- new roads/developments are not yet represented accurately.

---

# 17. Reverse Geocoding

Reverse geocoding may assist when a provider drops a pin.

Flow:

```text
provider moves pin
     ↓
coordinates
     ↓
reverse geocode
     ↓
suggested locality/address
     ↓
provider confirms/corrects
```

Do not reverse-geocode continuously while the map camera moves.

Trigger only after:

- pin drop;
- drag end;
- explicit confirmation.

This reduces cost and unnecessary traffic.

---

# 18. Forward Geocoding and Autocomplete

Autocomplete should search primarily within Cameroon for the launch market.

Recommended request context:

```text
country restriction/bias = CM
language = user's UI language
location bias = selected city or current map viewport where useful
```

Pachi should prefer:

```text
Places Autocomplete
```

for interactive address/place search rather than firing generic geocoding requests on each keystroke.

---

# 19. Google Data-Licensing Boundary

Google Maps Platform content has provider-specific storage and display restrictions.

Pachi must not assume that all Google-returned address components may be copied permanently into its database.

Architecture rule:

```text
Google result
     ↓
user selects / confirms / edits location
     ↓
Pachi stores its own canonical property-location data
```

Store external identifiers only where provider policy permits.

Google Place IDs may be retained according to Google's Place ID policies.

Implementation must be reviewed against the current Google Maps Platform Terms and API-specific policies before launch.

---

# 20. External Place ID

Optional field:

```text
external_provider = GOOGLE
external_place_id = ...
```

Purposes:

- re-resolve a provider place;
- correlate a selected landmark/place;
- refresh provider-derived context where needed.

Pachi must not depend on `external_place_id` for core property identity.

---

# 21. Pachi Search Geography

Property discovery should query Pachi data, not third-party place APIs.

Example:

```text
Seeker selects:
Douala → Bonamoussadi
        ↓
Pachi neighborhood_id
        ↓
PostgreSQL/PostGIS query
        ↓
Pachi listings
```

External APIs should not be called for every marketplace search result.

---

# 22. PostGIS Usage

PostGIS is responsible for application-owned geospatial queries.

Expected uses:

- point storage;
- spatial indexes;
- radius queries;
- bounding-box filtering;
- distance sorting;
- neighborhood polygon assignment;
- map viewport search.

Recommended coordinate system for standard map points:

```text
WGS 84 / EPSG:4326
```

Exact `geometry` versus `geography` types and indexes belong in the database design.

---

# 23. Map View Search

A map-discovery flow should send Pachi's backend:

```text
north
south
east
west
filters
```

or an equivalent viewport polygon.

Backend:

```text
viewport
    ↓
PostGIS spatial query
    ↓
matching Pachi listings
```

Do not query Google Places for housing inventory.

Google provides the basemap.

Pachi provides the listings.

---

# 24. Marker Density

Large result sets should not render thousands of individual markers.

Use techniques such as:

- server-side result limits;
- viewport loading;
- marker clustering;
- zoom-dependent result density.

Exact clustering library is an implementation detail.

---

# 25. Web Integration

## 25.1 Map Rendering

Next.js web will use:

```text
Google Maps JavaScript API
```

for interactive maps.

---

## 25.2 Lazy Loading

Do not initialize an interactive map on every listing/search page by default.

Load maps only when:

- a map view is visible;
- a property detail map enters the intended experience;
- the user explicitly opens map search.

This controls:

- billing;
- JavaScript payload;
- page performance.

---

## 25.3 Web API Key

Browser map keys must be restricted by:

- approved HTTP referrers;
- required APIs only;
- environment.

Use separate keys for:

```text
staging web
production web
```

Do not use unrestricted Google API keys.

---

# 26. Mobile Integration

## 26.1 Map Library

Initial mobile mapping:

```text
react-native-maps
```

through Expo.

Configure Google as the provider on both:

```text
Android
iOS
```

This provides a more consistent basemap/provider behavior across mobile platforms.

---

## 26.2 Why Not `expo-maps` Initially

`expo-maps` is currently alpha and uses:

```text
Google Maps on Android
Apple Maps on iOS
```

Pachi prefers one map provider across Android/iOS for the initial implementation.

`react-native-maps` currently supports Google Maps on both platforms through Expo configuration.

---

## 26.3 Android Key Restrictions

Android Maps key should be restricted by:

- Android application package;
- signing certificate fingerprint;
- Maps SDK for Android API scope.

Use separate development/staging/production configurations where appropriate.

---

## 26.4 iOS Key Restrictions

iOS Maps key should be restricted by:

- bundle identifier;
- Maps SDK for iOS API scope.

---

# 27. Server-Side Location API

Pachi backend should expose normalized application endpoints.

Possible examples:

```text
GET  /api/v1/locations/autocomplete
POST /api/v1/locations/geocode
POST /api/v1/locations/reverse-geocode

GET  /api/v1/locations/regions
GET  /api/v1/locations/cities
GET  /api/v1/locations/neighborhoods
```

Clients should not need to understand raw Google response schemas.

---

# 28. Client vs Server Provider Calls

## 28.1 Map rendering

Direct client SDK calls are appropriate for map tiles/rendering.

---

## 28.2 Pachi inventory search

Always through the Pachi API.

---

## 28.3 Canonical neighborhood search

Always through Pachi data.

---

## 28.4 Geocoding and place search

Prefer a Pachi-controlled backend/service layer where practical so Pachi can centralize:

- country restrictions;
- response normalization;
- cost controls;
- rate limiting;
- logging;
- provider replacement.

Where native/client APIs provide a better supported UX, the client may call approved Google SDKs directly using properly restricted keys.

The returned result still passes through Pachi confirmation/normalization before persistence.

---

# 29. Cost Controls

## 29.1 Separate Google Cloud projects or keys by environment

At minimum distinguish:

```text
development
staging
production
```

Production usage must be measurable independently.

---

## 29.2 Restrict every API key

Use:

- HTTP referrer restrictions for web;
- Android package + certificate restrictions;
- iOS bundle restrictions;
- server-side IP/service restrictions where feasible;
- API-level restrictions.

---

## 29.3 Quotas

Set explicit quotas for billable APIs.

Examples:

- autocomplete;
- geocoding;
- reverse geocoding;
- Places details;
- web map loads where applicable.

Quotas should prevent runaway usage from becoming an unlimited billing event.

---

## 29.4 Budget alerts

Configure Google Cloud billing budgets and alerts.

Recommended thresholds may include:

```text
50%
75%
90%
100%
```

of expected monthly spend.

Billing alerts are notifications, not a replacement for API quotas.

---

## 29.5 Autocomplete sessions

Use provider-supported autocomplete session tokens correctly.

Do not issue unrelated autocomplete calls without appropriate session handling.

---

## 29.6 Field masks

For Places API requests, request only the fields Pachi actually needs.

Avoid expensive details fields when only:

```text
place ID
name
address candidate
coordinates
```

are required.

---

## 29.7 Debouncing

Autocomplete input should be debounced.

Do not send a provider request on every raw keyboard event.

---

## 29.8 Minimum query length

Require a reasonable minimum query length before calling external autocomplete.

Example:

```text
3 characters
```

Exact UX can be tuned later.

---

## 29.9 Search locally first

Canonical Pachi neighborhoods and cities should be searched locally.

Google calls are for external address/place assistance, not every location filter.

---

## 29.10 No map-camera geocoding loops

Never call reverse geocoding continuously during map movement.

Only call on meaningful user actions.

---

## 29.11 No repeated display geocoding

Once a property has a confirmed Pachi location, displaying that property must not require another geocoding request.

---

# 30. Monitoring

Track external map/location usage.

Metrics should include:

```text
autocomplete requests
geocoding requests
reverse geocoding requests
provider errors
provider latency
zero-result rate
requests per property created
monthly API cost
cost per successfully published property
```

This allows Pachi to detect both product-quality and billing problems.

---

# 31. Cameroon Quality Validation

Before public launch, build a test dataset across initial target cities.

Include examples such as:

- formal street addresses;
- neighborhoods;
- popular landmarks;
- newly developed areas;
- informal/local place names;
- English queries;
- French queries;
- map-pin reverse geocoding.

Evaluate:

```text
result found?
correct city?
correct neighborhood?
coordinate accuracy?
local name quality?
language quality?
```

---

## 31.1 Benchmark Dataset

Maintain a non-sensitive test suite of representative Cameroon queries.

Example structure:

```text
LocationTestCase
- query
- language
- expected_city
- expected_neighborhood
- expected_area
- notes
```

This dataset can be reused when evaluating another provider.

---

# 32. Bilingual Location Handling

Pachi should support:

```text
English
French
```

for application-owned region/city/neighborhood display names where appropriate.

Canonical location entities should support translations/aliases independently from Google.

External-provider queries should pass the relevant language context where supported.

---

# 33. User-Generated Corrections

Providers should be able to correct:

- map pin;
- display address;
- neighborhood selection;
- landmark;
- directions.

Pachi should record enough provenance to distinguish:

```text
provider selected
provider manually corrected
automatically assigned
moderator corrected
```

---

# 34. Moderation and Location Changes

Material location changes on a published listing may require:

- validation;
- audit event;
- listing re-review;
- fraud checks.

Examples:

- moving property to another city;
- moving property a large distance;
- changing neighborhood after reviews/interactions exist.

Exact thresholds belong in listing/fraud rules.

---

# 35. Duplicate Property Detection

Location may contribute to duplicate detection.

Possible signals:

```text
near-identical coordinates
same building / landmark
same normalized provider address
same photos
same provider
same property attributes
```

Coordinates alone must not prove duplication because many legitimate properties exist in the same building or compound.

---

# 36. Search Radius

Distance search should be implemented in PostGIS.

Example conceptual request:

```text
center_latitude
center_longitude
radius_km
```

The backend returns matching Pachi listings.

External maps APIs should not be used to calculate simple straight-line property radius filtering.

---

# 37. Directions and Routing

Turn-by-turn navigation is not part of the initial Pachi scope.

For initial property viewing navigation, Pachi may:

- display location on map;
- provide an "Open in Maps" action;
- hand off to an installed mapping application.

A future Routes API integration should require a separate decision if Pachi needs:

- travel-time search;
- commute filters;
- route matrices;
- in-app routing.

---

# 38. Current-Location Permission

Pachi may request device location for features such as:

- "properties near me";
- centering a map;
- distance sorting.

The application should request location permission only when the user invokes a feature that needs it.

The marketplace must remain usable without granting continuous background location access.

Background location tracking is not part of the initial design.

---

# 39. Privacy Requirements

Pachi must not collect more location data than required.

Do not:

- continuously track seeker movement;
- store location history without a product requirement;
- include exact property coordinates in logs unnecessarily;
- expose private provider directions publicly.

Exact property coordinates may be sensitive even when they are not classified as authentication secrets.

---

# 40. API Logging

Location API logs should avoid unnecessary full-address retention.

Log operational metadata such as:

```text
request_id
provider
operation
country
latency
result_count
error_code
billing category where available
```

Do not log full private property directions or sensitive residential details unless needed for a controlled diagnostic process.

---

# 41. Failure Behavior

External provider failure must not make existing Pachi listings disappear.

Existing listings continue using Pachi's stored:

- coordinates;
- city;
- neighborhood;
- display text.

If Google is temporarily unavailable:

- map rendering may degrade;
- new external place suggestions may fail;
- manual Pachi city/neighborhood selection should remain available;
- property drafts should remain recoverable.

---

# 42. Provider Fallback Strategy

The domain model must permit a future second provider.

Possible fallback candidates:

```text
Mapbox
HERE
commercial OpenStreetMap-based provider
self-hosted OSM components
```

A fallback provider should be evaluated using the Cameroon location benchmark before activation.

---

# 43. Alternatives Considered

## 43.1 Mapbox

### Advantages

- strong web and native map SDKs;
- global geocoding;
- highly customizable vector maps;
- clear usage-based pricing;
- temporary and permanent geocoding products;
- permanent geocoding explicitly supports persistent business storage use cases under its applicable terms.

### Reasons not selected as primary

- Pachi currently has stronger documented country-specific confidence in Google's Cameroon core-map/geocoding coverage;
- Google provides a very mature combined map/place ecosystem;
- Expo's `react-native-maps` path supports Google on both Android and iOS.

Mapbox remains the strongest initial fallback candidate and should be tested against Pachi's Cameroon benchmark if Google quality or cost becomes problematic.

---

## 43.2 HERE

### Advantages

- mature commercial mapping platform;
- geocoding and routing;
- enterprise location services.

### Reasons not selected

Pachi does not currently have evidence that HERE provides a stronger combination of:

- Cameroon place quality;
- Expo integration;
- product familiarity;
- pricing;

than Google for the initial launch.

It remains a valid future evaluation candidate.

---

## 43.3 OpenStreetMap Data + MapLibre

### Advantages

- open mapping ecosystem;
- strong control over rendering;
- reduced dependency on one commercial map vendor;
- good ability to use community data.

### Reasons not selected as the complete initial stack

Using OSM data at production quality would still require decisions for:

- tile hosting;
- geocoding;
- place search;
- data updates;
- operational capacity;
- support.

MapLibre remains attractive if Pachi later wants greater map-rendering independence.

---

## 43.4 Public OpenStreetMap Nominatim

### Advantages

- no commercial geocoder contract;
- OSM-based search.

### Reasons not selected

The public Nominatim service is not appropriate as Pachi's production autocomplete/geocoding backend.

Its public usage policy:

- limits heavy use;
- sets an absolute maximum of one request per second;
- prohibits client-side autocomplete use;
- requires applications to be capable of switching services;
- discourages commercial applications from depending on the shared public service.

Pachi may use OSM data through a commercial provider or self-hosted infrastructure in the future.

---

## 43.5 Self-Hosted Nominatim

### Advantages

- control over geocoding;
- OSM data;
- no per-request commercial API pricing.

### Reasons not selected initially

It introduces:

- infrastructure;
- OSM imports;
- update pipelines;
- storage requirements;
- search tuning;
- operational maintenance.

This is not justified before Pachi demonstrates enough map/geocoding volume to warrant it.

---

## 43.6 Google Address Validation API

### Advantages

- structured postal-address validation;
- deliverability-related signals in supported countries.

### Reasons not selected

Cameroon is not currently listed as a supported country.

Pachi's location UX therefore cannot depend on it.

---

## 43.7 Apple Maps on iOS and Google Maps on Android

### Advantages

- natural platform-native default;
- `expo-maps` offers this pattern.

### Reasons not selected initially

Pachi prefers consistent:

- visual behavior;
- place/provider semantics;
- debugging;
- map capabilities;

across both mobile platforms.

`expo-maps` is also currently alpha.

---

## 43.8 External Provider as the Pachi Location Database

### Advantages

- less internal location modeling.

### Reasons not selected

Provider taxonomies and neighborhood naming can change.

Pachi needs stable IDs for:

- filters;
- URLs;
- analytics;
- listing relationships;
- SEO;
- moderation.

Canonical Pachi geography therefore belongs in Pachi's database.

---

# 44. Consequences

## 44.1 Positive

- strong documented Cameroon core-map/geocoding coverage;
- one primary map provider across web, Android, and iOS;
- provider-assisted addresses without requiring formal street addresses;
- PostGIS remains authoritative for housing inventory geography;
- neighborhoods have stable Pachi IDs;
- exact property locations can remain private;
- lower external API usage for normal listing search;
- provider abstraction preserves future portability;
- bilingual locality handling can evolve independently of Google.

---

## 44.2 Negative

- Google introduces another major platform/billing dependency;
- Google content policies require careful implementation;
- persistent canonical location data requires separation from raw provider response data;
- neighborhood curation requires operational work;
- Google API keys require platform-specific configuration;
- exact Cameroon neighborhood quality still needs real-world validation;
- web map loads and place/geocoding requests can create variable cost.

---

# 45. Risks and Mitigations

## Risk: poor geocoding in informal areas

Mitigation:

- manual pin placement;
- landmarks;
- provider correction;
- canonical neighborhoods;
- test real launch areas.

---

## Risk: unexpected Google Maps cost

Mitigation:

- quotas;
- billing alerts;
- debouncing;
- session tokens;
- field masks;
- lazy map loading;
- no reverse-geocode-on-camera-move;
- local Pachi neighborhood search;
- provider usage dashboards.

---

## Risk: provider lock-in

Mitigation:

- internal provider abstraction;
- Pachi canonical location model;
- PostGIS for internal search;
- external IDs optional;
- Cameroon benchmark reusable against alternatives.

---

## Risk: exact property exposure

Mitigation:

- separate private and public location;
- approximate public pins;
- neighborhood-only mode;
- permission-based disclosure.

---

## Risk: incorrect neighborhood assignment

Mitigation:

- canonical neighborhood IDs;
- aliases;
- optional polygon assignment;
- provider confirmation;
- moderation correction;
- no automatic neighborhood creation from provider output.

---

## Risk: API key theft

Mitigation:

- platform restrictions;
- API restrictions;
- separate keys by environment;
- server-side calls for sensitive/provider-heavy operations;
- quotas and monitoring.

---

# 46. Open Decisions

### MAP-OD-001 — Launch-city benchmark

Which Cameroon cities are included in the first formal geocoding quality benchmark?

**Current status:** Product launch-scope decision.

---

### MAP-OD-002 — Public location default

Should residential listings default to:

- `APPROXIMATE`; or
- `NEIGHBORHOOD_ONLY`?

**Current recommendation:** `APPROXIMATE`, with provider ability to choose more restrictive display where listing rules permit.

---

### MAP-OD-003 — Exact-location publication

Which property categories may show `EXACT` publicly by default?

**Current status:** Product/privacy decision.

---

### MAP-OD-004 — Neighborhood source dataset

What authoritative/open dataset will seed Pachi's initial regions, cities, and neighborhood catalog?

**Current status:** Data-engineering decision.

---

### MAP-OD-005 — Google provider calls

Which autocomplete/geocoding operations should occur directly from clients versus through the Pachi backend?

**Current recommendation:** Map rendering stays client-side; canonical place/geocoding workflows should prefer the backend/provider abstraction when practical.

---

### MAP-OD-006 — Mapbox benchmark

Should Mapbox be benchmarked against Google before launch rather than only as a fallback?

**Current recommendation:** Yes, run a small comparison using the same Cameroon test dataset before locking the provider contract.

---

### MAP-OD-007 — Google Maps subscription vs pay-as-you-go

Should Pachi begin with pay-as-you-go billing or a Maps Platform subscription?

**Current recommendation:** Start with pay-as-you-go and strict quotas until real usage is measurable.

---

# 47. Decisions Established by This ADR

If accepted, this ADR establishes that:

1. Google Maps Platform is Pachi's initial primary external map/location provider.
2. Pachi uses Google Maps JavaScript API on web.
3. Pachi uses Google Maps through `react-native-maps` on Android and iOS.
4. Pachi uses Places API and Geocoding API for location assistance.
5. Pachi does not depend on Address Validation API for Cameroon.
6. Pachi's own PostgreSQL/PostGIS data is authoritative for property geography.
7. Property coordinates are confirmed by the provider before becoming canonical.
8. Manual pin placement is a first-class location input method.
9. Pachi maintains canonical region, city, and neighborhood entities.
10. External geocoder neighborhood labels do not automatically become canonical Pachi neighborhoods.
11. Pachi property search runs against PostGIS rather than an external places API.
12. Exact stored property location is separate from public displayed location.
13. Public location privacy supports exact, approximate, neighborhood-only, or hidden modes.
14. Google API usage is protected by platform restrictions, quotas, cost monitoring, and rate controls.
15. Raw external provider data is not assumed to be freely persistable; implementation must follow current provider storage policies.
16. The architecture supports replacing or supplementing Google later.

---

# 48. Acceptance Criteria

This ADR may move from **Proposed** to **Accepted** when:

- Google coverage is tested in actual Pachi launch areas;
- the same Cameroon dataset is tested with at least one serious alternative such as Mapbox;
- provider licensing/storage rules are reviewed for Pachi's intended use;
- initial neighborhood seed data is selected;
- public location privacy default is approved;
- Google Cloud billing model is reviewed;
- API quotas and alert thresholds are defined;
- mobile Google Maps integration is validated in an Expo development build on Android and iOS;
- web map integration is validated in Next.js;
- no known product requirement conflicts with the proposed location model.

---

# 49. Follow-Up Work

After acceptance:

1. create Google Cloud projects/credentials for development, staging, and production;
2. enable only required Google Maps Platform APIs;
3. create restricted web, Android, iOS, and server keys;
4. configure billing budgets and API quotas;
5. build the Cameroon location quality benchmark;
6. compare Google and Mapbox on the benchmark;
7. create Pachi region/city/neighborhood seed data;
8. create PostGIS location schema;
9. implement provider map-pin confirmation;
10. implement location privacy modes;
11. implement Pachi neighborhood search;
12. implement external autocomplete/geocoding adapter;
13. implement map viewport listing search;
14. document provider data-retention rules in engineering/security documentation.

---

# 50. References

Implementation should be checked against current official documentation for:

- Google Maps Platform coverage;
- Maps JavaScript API;
- Maps SDK for Android;
- Maps SDK for iOS;
- Places API (New);
- Geocoding API;
- Google Maps Platform pricing and quotas;
- Google Maps Platform API security best practices;
- Google Geocoding API policies;
- Google Place ID policies;
- Expo `react-native-maps`;
- Expo Maps;
- Mapbox Geocoding and pricing;
- OpenStreetMap Foundation Nominatim usage policy.

Provider coverage, prices, licensing terms, SDK behavior, and API limits can change and must be rechecked before production launch.
