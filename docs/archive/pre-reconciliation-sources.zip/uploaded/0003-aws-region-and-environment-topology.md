# ADR 0003: AWS Region and Environment Topology

> **Status:** Proposed  
> **Date:** 2026-09-24  
> **Decision Owners:** Pachi Engineering  
> **Scope:** AWS region selection, account boundaries, staging and production environments, network topology, database placement, backup strategy, disaster recovery, and backend deployment topology  
> **Supersedes:** None  
> **Superseded By:** None  
> **Related ADRs:**  
> - `0001-technology-stack.md`
> - `0002-authentication-and-session-strategy.md`

---

## 1. Context

Pachi's proposed production platform uses AWS services including:

- Amazon ECS on AWS Fargate;
- Amazon RDS for PostgreSQL;
- Amazon S3;
- Amazon CloudFront;
- Amazon SQS;
- Amazon ECR;
- Amazon Cognito;
- AWS Secrets Manager;
- Amazon CloudWatch;
- AWS X-Ray;
- AWS Backup;
- AWS KMS.

The initial user base is expected to be primarily in Cameroon.

The infrastructure must balance:

- latency for users in Cameroon;
- AWS service availability;
- reliability;
- operational simplicity;
- environment isolation;
- database durability;
- disaster recovery;
- cost;
- security;
- future scaling;
- production supportability.

Pachi does not initially require active-active multi-region application deployment, Kubernetes, database sharding, globally distributed transactional storage, or multiple active production regions.

---

## 2. Decision Summary

Pachi will initially use:

```text
Primary Region:
eu-west-1 — Europe (Ireland)

Disaster-Recovery / Backup Region:
eu-west-3 — Europe (Paris)
```

`eu-west-1` is the **proposed primary region**, pending a final latency validation from Cameroon before this ADR becomes `Accepted`.

The backend will use a:

```text
single-region
multi-Availability-Zone
container-based
managed-database
private-network
architecture
```

Proposed AWS account structure:

```text
AWS Organization
│
├── Management Account
├── Staging Account
├── Production Account
└── Backup / Security Account
```

The initial production topology will use:

- one VPC per AWS environment;
- at least two Availability Zones;
- public subnets only for approved ingress/egress infrastructure;
- private application subnets for ECS Fargate;
- isolated database subnets for RDS;
- Amazon RDS PostgreSQL with PostGIS;
- Single-AZ RDS for staging by default;
- Multi-AZ RDS for production before public launch;
- encrypted automated RDS backups;
- point-in-time recovery;
- cross-region backup replication/copies;
- cross-account backup copies for critical production recovery points;
- versioning and encryption for critical S3 data;
- GitHub Actions using AWS OIDC federation;
- no long-lived AWS deployment access keys in GitHub.

The second region is for recovery, not hot failover.

---

## 3. Decision Drivers

### 3.1 Latency for users in Cameroon

The primary region must provide acceptable real-world latency for users in Cameroon.

Candidate regions to benchmark:

```text
eu-west-1     Europe (Ireland)
eu-west-3     Europe (Paris)
eu-central-1  Europe (Frankfurt)
af-south-1    Africa (Cape Town)
```

Measurements should include:

- DNS lookup time;
- TCP/TLS connection time;
- HTTP round-trip latency;
- repeated API requests;
- consistency across times of day;
- packet loss where practical.

The final region should be selected using stable application response time, not geographic distance alone.

### 3.2 AWS service maturity

The primary region must support Pachi's required services:

- ECS/Fargate;
- RDS PostgreSQL;
- S3;
- CloudFront;
- SQS;
- ECR;
- Cognito;
- CloudWatch;
- Secrets Manager;
- KMS;
- AWS Backup.

### 3.3 Failure isolation

Staging failures must not affect production.

Production credentials must not provide unnecessary staging access, and vice versa.

### 3.4 Database durability

The database is authoritative for Pachi's marketplace state and requires stronger protection than replaceable compute resources.

### 3.5 Small operational footprint

The topology should provide production reliability without introducing Kubernetes, self-managed database replication, or self-managed servers.

### 3.6 Cost control

Pachi should avoid paying for fully active secondary infrastructure before the business requires it.

### 3.7 Recoverability

Multi-AZ availability does not protect against accidental deletion, bad migrations, or account compromise.

The backup design must cover both infrastructure failure and logical data failure.

---

## 4. Region Decision

### 4.1 Proposed primary region

**Decision:** `eu-west-1` — Europe (Ireland)

Reasons:

- mature AWS region;
- broad AWS service coverage;
- multiple Availability Zones;
- established support for Pachi's selected core services;
- strong infrastructure maturity;
- good long-term platform flexibility.

### 4.2 Proposed backup region

**Decision:** `eu-west-3` — Europe (Paris)

Reasons:

- independent AWS region;
- geographic separation from Ireland;
- core service availability;
- suitable destination for cross-region backups and disaster-recovery artifacts.

### 4.3 Region validation gate

This ADR must not move to `Accepted` until Pachi performs a basic Cameroon network benchmark.

If Paris, Frankfurt, or Cape Town materially outperforms Ireland without unacceptable service or cost tradeoffs, update this ADR before production infrastructure is created.

---

## 5. Why Geography Alone Is Not Enough

`af-south-1` is physically in Africa, but Cameroon traffic may route internationally in ways that make a European region faster or more stable.

Therefore:

```text
geographic proximity ≠ guaranteed lower application latency
```

The final decision is benchmark-driven.

---

## 6. AWS Organization and Account Structure

### 6.1 Management Account

Purpose:

- AWS Organizations ownership;
- account creation;
- organization-level policy;
- consolidated billing.

The management account must not host normal application workloads.

### 6.2 Staging Account

Purpose:

- production-like integration testing;
- deployment verification;
- migration rehearsal;
- infrastructure testing;
- authentication and external-service testing.

Staging must not contain production credentials or real production data except explicitly anonymized test data.

### 6.3 Production Account

Purpose:

- live API;
- production database;
- production queues;
- object storage;
- Cognito;
- production secrets;
- monitoring.

### 6.4 Backup / Security Account

Purpose:

- protected backup vaults;
- cross-account recovery points;
- future centralized security/logging resources.

The production application must not have permission to delete protected recovery points in this account.

---

## 7. Environment Strategy

Pachi will initially maintain:

```text
local
staging
production
```

### 7.1 Local

Runs primarily in:

```text
Windows + WSL2 + Docker Desktop
```

Expected local services include:

- API;
- web;
- mobile development client;
- PostgreSQL + PostGIS.

### 7.2 Staging

Staging should use the same service families as production:

- ECS Fargate;
- RDS PostgreSQL/PostGIS;
- S3;
- SQS;
- Cognito;
- Secrets Manager;
- CloudWatch.

It may use smaller sizes and lower availability.

### 7.3 Production

Production must prioritize:

- availability;
- secure networking;
- backups;
- least privilege;
- controlled deployments;
- monitoring;
- recovery procedures.

Production must not share databases, Cognito pools, secrets, queues, buckets, or KMS keys with staging.

---

## 8. VPC Design

Each AWS environment gets its own VPC.

Example CIDRs:

```text
staging:
10.20.0.0/16

production:
10.30.0.0/16
```

The ranges should not overlap.

---

## 9. Availability Zones

### 9.1 Staging

Use at least two Availability Zones in the network layout.

Staging may run fewer tasks and Single-AZ RDS.

### 9.2 Production

Production application services should span at least two Availability Zones.

RDS must use Multi-AZ deployment before public launch.

---

## 10. Subnet Classes

Each VPC should define:

```text
VPC
│
├── Public Subnets
├── Private Application Subnets
└── Isolated Database Subnets
```

### 10.1 Public Subnets

Used for:

- Application Load Balancer;
- NAT gateways where used.

ECS application containers should not normally run directly in public subnets.

### 10.2 Private Application Subnets

Used for:

- ECS API tasks;
- ECS worker tasks;
- future internal application components.

### 10.3 Isolated Database Subnets

Used for:

- RDS PostgreSQL.

Database subnets should not have direct internet routes.

Production RDS must not have a public endpoint.

---

## 11. Ingress Topology

```text
Internet
   │
   ▼
DNS
   │
   ▼
HTTPS
   │
   ▼
Application Load Balancer
   │
   ▼
ECS Fargate API Tasks
```

The ECS security group should accept application traffic only from the load-balancer security group.

---

## 12. Application Load Balancer

The production API will use an Application Load Balancer for:

- TLS termination;
- health checks;
- request routing;
- distribution across ECS tasks.

TLS certificates should use AWS Certificate Manager.

---

## 13. Application Compute

### 13.1 API Service

Run the NestJS API as an ECS Fargate service.

Before public launch, production should run at least:

```text
2 API tasks
```

distributed across Availability Zones.

### 13.2 Worker Service

Background processing may initially run inside the API or as a separate worker.

Create a separate ECS worker service when asynchronous workload needs independent scaling or failure isolation.

### 13.3 Immutable Deployments

Production container images should be deployed by immutable tag or image digest and tied to a Git revision.

---

## 14. Egress Strategy

Private ECS tasks may need outbound access for:

- Cognito;
- external identity providers;
- SMS/email services;
- maps/geocoding;
- verification vendors;
- other APIs.

Initial model:

```text
private application subnet
        ↓
NAT gateway
        ↓
internet
```

Production should use one NAT gateway per active Availability Zone when budget and availability justify it.

Staging may use a single NAT gateway.

Add VPC endpoints where they improve security, availability, or NAT cost.

Candidates include:

- S3;
- ECR;
- CloudWatch Logs;
- Secrets Manager.

---

## 15. Database Placement

### 15.1 Engine

Use:

```text
Amazon RDS for PostgreSQL
+ PostGIS
```

### 15.2 Network Placement

RDS must run in isolated database subnets.

Its security group should allow PostgreSQL traffic only from approved application security groups.

### 15.3 Staging Database

Default:

```text
Single-AZ RDS PostgreSQL
```

This reduces cost.

### 15.4 Production Database

Before public launch:

```text
RDS PostgreSQL Multi-AZ
```

Initial preference:

```text
Multi-AZ DB instance deployment
```

rather than a larger Multi-AZ DB cluster unless read scaling or failover requirements justify the added cost.

---

## 16. Database Connection Management

Use application-level connection pooling with conservative per-task limits.

Consider RDS Proxy later if:

- ECS task count grows;
- connection storms become a risk;
- scaling creates connection pressure.

RDS Proxy is not mandatory initially.

---

## 17. Database Encryption

Production database storage must use encryption at rest.

Database connections must use TLS.

Use environment-specific KMS keys where practical.

---

## 18. Database Backup Strategy

Production database protection uses multiple layers.

### 18.1 Automated RDS Backups

Enable automated backups with proposed retention:

```text
35 days
```

Enable point-in-time recovery.

This is the primary recovery mechanism for:

- accidental deletion;
- bad application writes;
- faulty migrations;
- corruption discovered within retention.

### 18.2 Pre-Deployment Recovery Points

For high-risk database migrations, create an explicit recovery point before deployment when warranted.

### 18.3 Cross-Region Backup Replication

Enable RDS cross-region automated backup replication to:

```text
eu-west-3
```

where supported by the selected RDS configuration.

### 18.4 Cross-Account Backup

Use AWS Backup to copy critical production recovery points into the Backup / Security account.

### 18.5 Long-Term Recovery Points

Proposed initial retention:

```text
daily backups:   35 days
monthly backups: 12 months
```

Longer retention should depend on legal, privacy, operational, and cost requirements.

---

## 19. S3 Backup and Durability

### 19.1 Public Marketplace Media

Examples:

- property photos;
- avatars;
- organization logos.

Use:

- S3 versioning;
- encryption;
- lifecycle policies;
- CloudFront delivery.

### 19.2 Private Verification Evidence

Examples:

- identity documents;
- organization verification files;
- property-authority evidence.

Use:

- private S3 buckets;
- encryption;
- versioning;
- tightly scoped IAM;
- access auditing;
- retention rules;
- protected recovery copies.

Critical private evidence should be eligible for cross-region and cross-account backup.

---

## 20. Backup Protection

Backup resources must not rely only on the same credentials that operate production.

Controls should include:

- separate backup account;
- restricted deletion permissions;
- backup vault policies;
- AWS Backup Vault Lock or equivalent immutability controls when operationally ready.

---

## 21. Restore Testing

Backups must be tested.

Minimum production expectation:

```text
quarterly database restore test
```

A restore test should verify:

- recovery point availability;
- successful restore;
- application connectivity;
- schema validity;
- core data readability;
- runbook accuracy.

---

## 22. Recovery Objectives

These are initial engineering targets, not contractual guarantees.

### 22.1 Availability Zone Failure

Target:

```text
RPO: near zero for committed database transactions
RTO: minutes
```

Provided through Multi-AZ RDS and multi-AZ ECS deployment.

### 22.2 Accidental Database Change

Target:

```text
RPO: within RDS point-in-time recovery capability
RTO: under 2 hours
```

Actual recovery depends on database size and incident complexity.

### 22.3 Primary Region Failure

Initial target:

```text
RPO: based on latest replicated recovery point
RTO: under 8 hours
```

This is a cold/warm DR posture, not automatic regional failover.

These targets must be revised after real restore drills.

---

## 23. Regional Disaster Recovery

Pachi will not initially run a permanent duplicate backend in `eu-west-3`.

If `eu-west-1` experiences a prolonged regional outage:

```text
1. declare regional disaster
2. restore database in eu-west-3
3. deploy application infrastructure in eu-west-3
4. restore required object data
5. switch API DNS
6. validate authentication and integrations
7. resume service
```

Infrastructure as code should make this reproducible.

---

## 24. Cognito Regional Strategy

The initial Cognito User Pool should live in:

```text
eu-west-1
```

AWS supports multi-region user-pool replication for eligible Cognito configurations and plans.

Initial proposal:

- do not enable paid multi-region Cognito replication unless availability requirements justify it;
- keep the architecture compatible with a replica in `eu-west-3`;
- re-evaluate before Pachi requires regional authentication failover.

Potential future layout:

```text
primary:   eu-west-1
secondary: eu-west-3
```

---

## 25. Queue Placement

Production SQS queues live in the primary region.

Queues are operational messaging infrastructure, not the long-term source of truth.

Critical job effects must be idempotent.

---

## 26. ECR Strategy

Production images live in Amazon ECR.

Image policy:

- immutable release tags where practical;
- retain recent production releases;
- associate image with Git commit SHA.

Cross-region ECR replication is optional initially.

---

## 27. Secrets

Production secrets belong in:

- AWS Secrets Manager;
- AWS Systems Manager Parameter Store where appropriate.

Examples:

- database credentials;
- OAuth secrets;
- third-party API credentials.

Production secrets must not be copied into staging.

---

## 28. KMS Strategy

Use environment-specific KMS keys where practical.

Potential protected resources include:

- RDS;
- private S3 evidence;
- backups;
- secrets;
- Cognito multi-region encryption if later enabled.

---

## 29. DNS

Proposed logical DNS structure:

```text
www.<domain>      → Vercel web
api.<domain>      → AWS API ingress
media.<domain>    → CloudFront
auth.<domain>     → Cognito custom domain if configured
```

Exact domain names will be decided later.

---

## 30. TLS

All production public traffic must use HTTPS.

AWS-managed certificates should use AWS Certificate Manager where applicable.

---

## 31. Deployment Topology

### 31.1 Backend

```text
GitHub
   │
   ▼
GitHub Actions
   │
   ├── test
   ├── lint
   ├── type-check
   ├── build
   └── migration/security checks
   │
   ▼
Assume AWS role via OIDC
   │
   ▼
Build container
   │
   ▼
Amazon ECR
   │
   ▼
ECS deployment
   │
   ▼
ALB health checks
   │
   ▼
Production traffic
```

### 31.2 GitHub Authentication to AWS

GitHub Actions must use OpenID Connect federation to obtain short-lived AWS credentials.

Do not store permanent AWS access keys in GitHub.

Use separate deployment roles for:

```text
staging
production
```

### 31.3 Production Approval

Production deployment should use a protected GitHub environment or equivalent approval control.

---

## 32. Database Migration Deployment

Recommended sequence:

```text
CI passes
   ↓
container image built
   ↓
migration compatibility check
   ↓
approved migration task
   ↓
application deployment
```

Prefer backward-compatible expand/contract migrations.

---

## 33. Rollback

Application deployments should support rollback to a known-good container image.

Database rollback must not assume every migration is safely reversible.

Destructive schema changes should be delayed until old application versions no longer depend on them.

---

## 34. Staging Deployment

Staging should deploy automatically or near-automatically after approved changes.

Use staging for:

- integration testing;
- migration rehearsal;
- authentication testing;
- infrastructure testing;
- operational verification.

Staging is not a production backup environment.

---

## 35. Production Deployment

Production deployments must be:

- tied to a Git revision;
- observable;
- auditable;
- health-checked;
- reversible at the application layer.

Initial deployment style may use ECS rolling deployments.

Blue/green deployment is deferred until risk or traffic justifies the added complexity.

---

## 36. Observability

Production monitoring should include:

- ALB health;
- ECS desired vs running tasks;
- ECS CPU/memory;
- API 5xx rate;
- API latency;
- RDS CPU/storage/connections;
- RDS failover events;
- SQS depth and message age;
- backup failures;
- deployment failures.

Critical alerts should reach an external notification destination.

---

## 37. Security Boundaries

### Internet boundary

Only explicitly public endpoints receive internet traffic.

### Application boundary

ECS tasks remain private behind approved ingress.

### Database boundary

RDS remains isolated and reachable only from approved application resources.

### Environment boundary

Staging and production are separate AWS accounts.

### Backup boundary

Protected backup copies exist outside the production account.

### Deployment boundary

CI uses temporary OIDC credentials and environment-specific IAM roles.

---

## 38. Production Access

Normal development should not require direct production database access.

Exceptional access must:

- use an approved secure path;
- require MFA;
- apply least privilege;
- be logged;
- avoid public RDS exposure.

Do not deploy a bastion host merely for convenience.

---

## 39. Data Residency

Primary application data is proposed to reside in:

```text
eu-west-1
```

with DR copies in:

```text
eu-west-3
```

Before launch, confirm that this placement is compatible with applicable legal and contractual requirements.

This ADR does not make a legal determination.

---

## 40. Cost Controls

Use:

- AWS Budgets;
- billing alerts;
- resource tags;
- smaller staging resources;
- Single-AZ staging RDS;
- reduced staging NAT topology;
- no always-on DR compute;
- log retention policies;
- backup lifecycle policies;
- transfer monitoring.

Cost optimization must not remove required durability or security controls.

---

## 41. Resource Tagging

Baseline tags:

```text
Application=Pachi
Environment=staging|production
ManagedBy=CDK
Owner=Pachi
CostCenter=Pachi
```

---

## 42. Infrastructure as Code

All normal AWS infrastructure should be managed through AWS CDK as established in ADR 0001.

Emergency manual changes must be reconciled into CDK afterward.

---

## 43. Alternatives Considered

### 43.1 `af-south-1` as primary

**Advantages**

- located in Africa;
- potentially lower latency for some African networks;
- African data location.

**Reasons not selected provisionally**

- Cameroon routing must be measured;
- geography does not guarantee lower latency;
- `eu-west-1` has a very mature service footprint.

Cape Town remains a serious candidate until benchmarking is complete.

### 43.2 `eu-west-3` Paris as primary

**Advantages**

- geographically closer to Cameroon than Ireland;
- broad AWS availability;
- European connectivity.

**Reasons not selected provisionally**

Ireland is preferred for platform maturity unless latency testing shows Paris is materially better.

### 43.3 `eu-central-1` Frankfurt as primary

**Advantages**

- mature region;
- broad service catalog;
- strong connectivity.

**Reasons not selected provisionally**

No current evidence shows a clear overall advantage over Ireland.

### 43.4 One AWS account for staging and production

**Advantages**

- simpler setup;
- simpler billing.

**Reasons not selected**

- weaker blast-radius isolation;
- IAM mistakes can cross environments;
- harder backup protection;
- higher risk of accidental production access.

### 43.5 Separate VPCs in one account only

**Advantages**

- network isolation.

**Reasons not selected as the only boundary**

VPCs do not isolate IAM, service control planes, backup deletion authority, or account credentials.

### 43.6 Active-active multi-region production

**Advantages**

- higher regional resilience;
- faster failover.

**Reasons not selected**

- higher cost;
- database consistency complexity;
- authentication complexity;
- routing complexity;
- unjustified at current scale.

### 43.7 Hot standby region

**Advantages**

- faster DR.

**Reasons not selected initially**

The cost is not justified before Pachi has an RTO requiring it.

### 43.8 Public ECS tasks

**Advantages**

- simpler networking;
- lower cost.

**Reasons not selected for production**

- larger public attack surface;
- weaker network boundaries.

### 43.9 Public RDS endpoint

**Advantages**

- easier administration.

**Reasons not selected**

Production database convenience does not justify public exposure.

### 43.10 Single-AZ production RDS

**Advantages**

- cheaper.

**Reasons not selected**

An Availability Zone database failure would cause unnecessary production downtime.

### 43.11 Multi-AZ DB cluster from day one

**Advantages**

- writer plus readable standby instances;
- more read capacity;
- strong availability.

**Reasons not selected initially**

Higher cost is not justified until Pachi requires the additional performance or failover characteristics.

### 43.12 Aurora PostgreSQL

**Advantages**

- advanced scaling;
- strong availability;
- read scaling.

**Reasons not selected initially**

RDS PostgreSQL is simpler and sufficient for the expected initial workload.

### 43.13 Kubernetes / EKS

**Advantages**

- powerful orchestration.

**Reasons not selected**

ECS/Fargate satisfies the current requirements with much lower operational complexity.

### 43.14 EC2-based backend

**Advantages**

- maximum control;
- potentially lower cost at sustained high utilization.

**Reasons not selected**

Requires server patching, fleet management, and host security.

### 43.15 No cross-account backups

**Advantages**

- simpler;
- cheaper.

**Reasons not selected**

A production account compromise could also threaten same-account backups.

---

## 44. Consequences

### 44.1 Positive

- strong staging/production isolation;
- no public production database;
- managed multi-AZ database availability;
- point-in-time recovery;
- regional disaster-recovery path;
- backup copies protected outside production;
- no host/server management;
- no permanent AWS deployment credentials in GitHub;
- future path to stronger multi-region capabilities.

### 44.2 Negative

- more AWS accounts to configure;
- NAT gateways add cost;
- Multi-AZ RDS costs more;
- backup copies add storage and transfer cost;
- regional recovery is not automatic;
- restore procedures require regular testing;
- networking is more complex than a simple PaaS.

---

## 45. Risks and Mitigations

### Wrong primary region

Mitigation:

- complete Cameroon latency testing before acceptance.

### Regional outage

Mitigation:

- cross-region backups;
- infrastructure as code;
- documented DR procedure;
- future Cognito multi-region support;
- future hot standby if required.

### Production account compromise

Mitigation:

- separate accounts;
- MFA;
- least privilege;
- protected backup account;
- short-lived CI credentials.

### Bad database migration

Mitigation:

- staging rehearsal;
- PITR;
- explicit recovery points for high-risk changes;
- expand/contract migrations.

### NAT cost

Mitigation:

- single NAT in staging;
- VPC endpoints;
- cost monitoring;
- production per-AZ NAT only when justified.

### Staging drift

Mitigation:

- shared CDK architecture;
- environment configuration rather than hand-built infrastructure.

---

## 46. Open Decisions

### AWS-OD-001 — Final primary region

Is `eu-west-1` confirmed after Cameroon network measurements?

**Current status:** Proposed pending benchmark.

### AWS-OD-002 — Production NAT topology

Should public launch use one NAT gateway total or one per Availability Zone?

**Current recommendation:** One per production AZ if budget permits; one for staging.

### AWS-OD-003 — Cognito multi-region replication

When should Pachi enable Cognito multi-region replication?

**Current recommendation:** Defer until authentication availability requirements justify the additional cost.

### AWS-OD-004 — Cross-region RDS backup replication

Enable from first production launch?

**Current recommendation:** Yes, before accepting real production data.

### AWS-OD-005 — Backup immutability

When should Vault Lock or equivalent controls become mandatory?

**Current recommendation:** Before public production launch if operationally manageable.

### AWS-OD-006 — Production Multi-AZ type

Should production begin with a Multi-AZ DB instance or Multi-AZ DB cluster?

**Current recommendation:** Multi-AZ DB instance.

### AWS-OD-007 — Disaster-recovery RTO

Is an initial target of under 8 hours acceptable for regional disaster recovery?

**Current status:** Product/business continuity decision.

---

## 47. Decisions Established by This ADR

If accepted:

1. `eu-west-1` is Pachi's initial primary AWS region.
2. `eu-west-3` is Pachi's backup/DR region.
3. Final region acceptance requires Cameroon latency validation.
4. Staging and production run in separate AWS accounts.
5. Critical production backups are copied outside the production account.
6. Production ECS tasks run in private subnets.
7. Production RDS runs in isolated subnets with no public endpoint.
8. Production uses Multi-AZ RDS before public launch.
9. Staging may use Single-AZ RDS.
10. Production RDS automated backups and PITR are mandatory.
11. Production database backups are replicated/copied cross-region.
12. GitHub Actions deploys through AWS OIDC federation.
13. No long-lived AWS access keys are stored in GitHub.
14. Production is single-region/multi-AZ, not active-active multi-region.
15. Regional DR initially uses restore-and-redeploy.
16. Infrastructure is managed through AWS CDK.

---

## 48. Acceptance Criteria

This ADR may move from **Proposed** to **Accepted** when:

- Cameroon latency testing is complete;
- `eu-west-1` remains acceptable relative to Paris, Frankfurt, and Cape Town;
- expected staging/production cost is reviewed;
- account structure is accepted;
- Multi-AZ RDS cost is accepted;
- backup retention is accepted;
- cross-region backup configuration is confirmed;
- DR RPO/RTO targets are acceptable;
- production NAT topology is decided;
- no known security or data-residency requirement conflicts with the proposed regions.

---

## 49. Follow-Up Work

After acceptance:

1. create AWS Organization accounts;
2. enable MFA and root-account protections;
3. create staging and production CDK stacks;
4. create VPCs and subnet groups;
5. create security groups;
6. deploy staging RDS PostgreSQL/PostGIS;
7. deploy ECS cluster and staging service;
8. configure GitHub OIDC roles;
9. configure backup vaults;
10. configure cross-account backup policies;
11. configure cross-region database backup replication;
12. configure monitoring and budget alerts;
13. write the disaster-recovery runbook;
14. perform the first restore test before public launch.

---

## 50. References

Implementation should be checked against current official documentation for:

- AWS Regions and Availability Zones;
- Amazon ECS on AWS Fargate regional availability;
- Amazon RDS Multi-AZ deployments;
- Amazon RDS PostgreSQL;
- RDS point-in-time recovery;
- RDS cross-region automated backup replication;
- AWS Backup cross-account copies;
- AWS Backup cross-region copies;
- AWS Backup Vault Lock;
- Amazon Cognito regional and multi-region behavior;
- GitHub Actions OpenID Connect with AWS;
- Amazon VPC security practices.

AWS service availability, pricing, and regional capabilities change over time and must be rechecked before production deployment.
