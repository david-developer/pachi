# ADR 0005: Media Processing and Storage Policy

> **Status:** Proposed  
> **Date:** 2026-09-24  
> **Decision Owners:** Pachi Engineering  
> **Scope:** Listing photos, user/provider media, verification documents, upload flows, image processing, metadata stripping, moderation scanning, S3 separation, signed access, retention, and deletion behavior  
> **Supersedes:** None  
> **Superseded By:** None  
> **Related ADRs:**  
> - `0001-technology-stack.md`
> - `0002-authentication-and-session-strategy.md`
> - `0003-aws-region-and-environment-topology.md`
> - `0004-maps-geocoding-and-location-services.md`

---

## 1. Context

Pachi will handle several classes of user-supplied media.

Examples include:

### Public or semi-public marketplace media

- listing photos;
- property photos;
- user avatars;
- provider profile images;
- organization logos;
- approved public attachments.

### Private verification evidence

- identity documents;
- organization registration documents;
- property-authority documents;
- representation agreements;
- verification evidence images;
- other sensitive trust documents.

These media classes have very different:

- confidentiality requirements;
- retention requirements;
- access patterns;
- processing needs;
- moderation requirements;
- deletion behavior.

A single shared bucket or common public-media pipeline would create unacceptable risk.

Pachi must therefore treat media as a security-sensitive subsystem rather than as arbitrary file uploads.

---

## 2. Decision Summary

Pachi will use **Amazon S3** as the authoritative object store.

Media will be split into at least two logically and physically separate storage classes:

```text
Public Marketplace Media
        ↓
private S3 origin
        ↓
CloudFront
        ↓
public/semi-public delivery

Private Verification Evidence
        ↓
private S3 bucket
        ↓
short-lived signed access only
        ↓
authorized reviewers / applicant workflows
```

Core decisions:

- no S3 bucket used by Pachi will rely on broad public bucket access;
- public marketplace media will be delivered through CloudFront;
- verification evidence will never use the public media delivery path;
- uploads will use short-lived pre-signed upload URLs or equivalent controlled upload mechanisms;
- uploaded images will enter a **quarantine / pending-processing state** before becoming usable;
- image files will be decoded and re-encoded before publication;
- EXIF and other unnecessary metadata will be stripped from public images;
- image derivatives will be created for consistent delivery sizes;
- listing images will be compressed to efficient web/mobile formats;
- malware and file validation will occur before files are accepted as trusted;
- moderation scanning may use automated detection and human review where needed;
- original verification evidence may be preserved when required for review/audit;
- deletions will use explicit lifecycle and retention rules rather than immediate blind physical deletion;
- all sensitive-media access will be authorized and auditable.

---

## 3. Decision Drivers

### 3.1 Sensitive verification evidence

Verification documents may contain:

- legal names;
- identity numbers;
- signatures;
- addresses;
- photographs;
- organization registration details;
- property ownership or authority evidence.

These documents require stronger controls than public marketplace images.

---

### 3.2 Mobile-first image upload

Many users will upload photos from phones.

The system must handle:

- large camera images;
- HEIC/HEIF where supported by clients;
- JPEG;
- PNG;
- inconsistent orientations;
- slow mobile connections;
- intermittent uploads.

---

### 3.3 Performance

Property discovery requires fast image rendering across:

- mobile networks;
- web;
- native apps;
- low-bandwidth conditions.

Serving original multi-megabyte uploads directly would create poor performance and unnecessary bandwidth cost.

---

### 3.4 Privacy

Camera images may contain metadata such as:

- GPS coordinates;
- device model;
- capture timestamp;
- software metadata.

Public delivery should not accidentally expose sensitive metadata.

---

### 3.5 Trust and moderation

Pachi must reduce abuse involving:

- malicious files;
- unsupported files;
- misleading listing images;
- prohibited content;
- manipulated verification evidence.

---

### 3.6 Cost control

Media can become one of the largest sources of:

- storage cost;
- bandwidth cost;
- processing cost;
- CDN cost.

The architecture must control:

- derivative count;
- upload size;
- duplicate processing;
- retention;
- cache behavior.

---

### 3.7 Auditability

Pachi must be able to determine:

- who uploaded a file;
- when;
- what entity it belongs to;
- whether processing succeeded;
- whether moderation flagged it;
- who accessed sensitive evidence;
- when it was deleted or expired.

---

## 4. Media Classification

Every stored file must have a media classification.

Initial categories:

```text
LISTING_IMAGE
PROPERTY_IMAGE
USER_AVATAR
PROVIDER_IMAGE
ORGANIZATION_LOGO
VERIFICATION_EVIDENCE
MODERATION_EVIDENCE
INTERNAL_ATTACHMENT
```

Each class must define:

- bucket;
- visibility;
- maximum size;
- allowed MIME types;
- processing rules;
- retention;
- access rules.

---

## 5. Storage Separation

Pachi should use separate S3 buckets or equivalent hard boundaries for public-delivery media and sensitive evidence.

Recommended logical structure:

```text
pachi-public-media-<env>
pachi-private-verification-<env>
pachi-private-moderation-<env>
```

At minimum:

```text
public marketplace media
≠
private verification evidence
```

The exact number of buckets may evolve, but public and private security domains must remain separate.

---

## 6. Public Marketplace Media Bucket

The public-media bucket stores approved marketplace assets such as:

- listing images;
- provider profile photos;
- avatars;
- organization logos.

The bucket remains private at the S3 layer.

Public delivery occurs through CloudFront.

---

## 7. Private Verification Bucket

The verification bucket stores:

- personal identity evidence;
- organization evidence;
- property-authority evidence;
- related verification attachments.

Required properties:

- S3 Block Public Access enabled;
- no public bucket policy;
- no public CloudFront behavior;
- encryption at rest;
- tightly scoped IAM;
- access auditability;
- signed access only where required;
- explicit retention policy.

---

## 8. Environment Separation

Staging and production must not share media buckets.

Example:

```text
staging:
pachi-public-media-staging
pachi-private-verification-staging

production:
pachi-public-media-production
pachi-private-verification-production
```

Production verification evidence must never be copied into staging for normal testing.

---

## 9. Object Key Strategy

Object keys should not expose sensitive user data.

Avoid:

```text
/users/david@example.com/passport.jpg
```

Prefer opaque identifiers:

```text
listing-images/<media-id>/original
verification/<case-id>/<evidence-id>/original
```

Do not place:

- email;
- phone number;
- identity number;
- user-entered document name;

in object keys.

---

## 10. Media Database Record

Files should have an application record in PostgreSQL.

Conceptually:

```text
MediaAsset
- id
- owner_type
- owner_id
- classification
- storage_bucket
- storage_key
- original_filename
- detected_mime_type
- original_size_bytes
- width
- height
- processing_state
- moderation_state
- visibility
- checksum
- uploaded_by
- created_at
- processed_at
- deleted_at
```

Sensitive classes may use a specialized evidence entity rather than the general media table.

---

## 11. Upload Flow

Clients should not upload large files through the NestJS API process.

Preferred flow:

```text
Client
  │
  │ request upload authorization
  ▼
Pachi API
  │
  ├── validates actor
  ├── validates intended media class
  ├── creates pending media record
  └── returns short-lived upload authorization
  │
  ▼
Client uploads directly to S3
  │
  ▼
S3 object-created event
  │
  ▼
processing workflow
  │
  ▼
validated / processed / moderated
  │
  ▼
asset becomes usable
```

This avoids routing large media bodies through the API container.

---

## 12. Pre-Signed Upload URLs

Initial decision:

Use short-lived S3 pre-signed upload URLs for approved object keys.

The API must determine:

- destination bucket;
- destination key;
- maximum permitted size;
- expected content type;
- owner/entity relationship.

The client must not choose an arbitrary bucket or arbitrary storage key.

---

## 13. Upload Authorization

Before issuing an upload URL, the API must verify:

```text
authenticated actor
AND actor may modify target entity
AND entity state permits media upload
AND media classification is allowed
AND upload quota has not been exceeded
```

Examples:

- a provider may upload images only for a property they control;
- a verification applicant may upload evidence only to their active verification case;
- an unrelated user may not upload into another listing's media namespace.

---

## 14. Upload Expiration

Pre-signed upload authorization should be short-lived.

Recommended initial duration:

```text
5–15 minutes
```

The exact value may vary for slow mobile uploads.

---

## 15. Upload State Machine

Recommended media processing states:

```text
PENDING_UPLOAD
UPLOADED
QUARANTINED
PROCESSING
READY
REJECTED
DELETED
```

Moderation state is separate:

```text
NOT_REQUIRED
PENDING
APPROVED
FLAGGED
REJECTED
```

Storage/processing state and moderation state must not be conflated.

---

## 16. Quarantine

New uploads must not become publicly visible immediately.

After upload:

```text
UPLOADED
   ↓
QUARANTINED
   ↓
validation / malware / decode checks
   ↓
PROCESSING
```

Only a successfully processed and approved file may become `READY`.

---

## 17. File Type Validation

Never trust:

- file extension;
- browser-provided MIME type;
- mobile client metadata.

Validate using server-side inspection.

Checks should include:

- file signature / magic bytes;
- actual decoder compatibility;
- allowed format;
- maximum file size;
- maximum image dimensions;
- decompression safety.

Reject mismatches such as:

```text
image.jpg
but actual content = executable/archive
```

---

## 18. Initial Allowed Image Formats

Public listing/media uploads should initially support:

```text
JPEG
PNG
WebP where client/provider workflow supports it
HEIC/HEIF only if the processing pipeline can reliably decode it
```

Do not accept SVG from untrusted users for general marketplace imagery because it can contain active content and complicate sanitization.

Animated image support is deferred.

---

## 19. Initial Upload Limits

Proposed baseline:

### Listing / property image

```text
max original file size: 20 MB
max pixel dimension: configurable, e.g. 12,000 px
```

### Avatar / logo

```text
max original file size: 10 MB
```

### Verification evidence

```text
max file size: 20 MB per item initially
```

Document/PDF limits should be finalized when verification document handling is implemented.

Limits should be configuration, not scattered hard-coded constants.

---

## 20. Public Image Processing

Every public marketplace image should be decoded and re-encoded.

Benefits:

- strips most metadata;
- normalizes orientation;
- eliminates malformed source structure;
- creates controlled derivatives;
- improves compression.

The original may be retained privately for a limited period if required for moderation or reprocessing.

---

## 21. EXIF and Metadata Stripping

Public media derivatives must remove unnecessary metadata.

Strip:

- GPS EXIF;
- camera serial/device metadata;
- capture timestamp where not needed;
- embedded thumbnails;
- proprietary metadata;
- comments;
- ICC/metadata not needed for correct rendering.

Preserve only metadata needed for:

- correct image orientation;
- correct color rendering where required.

Orientation should be applied to pixels before removing the orientation metadata.

---

## 22. Verification Document Metadata

Verification evidence requires different treatment.

Do not automatically strip metadata if that metadata may be relevant to fraud/security review.

Recommended model:

```text
original evidence
→ preserved privately
→ security scanned
→ reviewer derivative generated if needed
```

Public-media privacy rules must not destroy potentially relevant verification evidence.

---

## 23. Image Resizing

Pachi should generate a controlled derivative set.

Initial proposed listing sizes:

```text
thumbnail: 320 px wide
small:     640 px wide
medium:    1280 px wide
large:     1920 px wide
```

Only create a derivative larger than the source when explicitly needed.

The exact widths may be tuned after UI implementation.

---

## 24. Image Aspect Ratio

Do not force all original listing images into one crop.

Preserve original aspect ratio for primary derivatives.

UI surfaces may request cropped thumbnails for cards.

Possible future derivative:

```text
card crop:
4:3
```

Cropping should not overwrite the uncropped processed image.

---

## 25. Image Format Strategy

Preferred delivery formats:

```text
WebP
JPEG fallback where required
```

AVIF may be introduced later where processing cost and client support justify it.

The system should not generate every possible format/size combination without evidence of need.

---

## 26. Image Compression

Use quality settings optimized for property photography.

Initial target ranges may be approximately:

```text
WebP quality: 75–85
JPEG quality: 80–88
```

Final values should be validated visually.

Avoid compression settings that hide property defects or materially distort listing content.

---

## 27. Processing Service

Initial image processing may run as:

```text
S3 event
   ↓
SQS
   ↓
Pachi media worker
   ↓
image processor
   ↓
processed S3 objects
```

The worker may use a production-grade image library such as:

```text
Sharp / libvips
```

within a containerized worker.

---

## 28. Why Not Process Images Synchronously

Image processing should not occur inside the user-facing upload HTTP request.

Reasons:

- large images are CPU/memory intensive;
- mobile requests may disconnect;
- transformations take variable time;
- async retry is easier;
- workers can scale independently.

---

## 29. Processing Idempotency

Processing must be idempotent.

Repeated events for the same upload must not create uncontrolled duplicate derivatives.

Use:

- stable media ID;
- versioned derivative paths;
- processing-state checks;
- deterministic derivative names.

---

## 30. Checksums

Compute a cryptographic checksum for uploaded objects.

Potential uses:

- integrity validation;
- duplicate detection;
- idempotent processing;
- moderation investigations.

Do not use checksum equality alone to declare two listings fraudulent.

---

## 31. Malware Scanning

Files that may contain arbitrary binary content must be scanned before trusted use.

Initial strategy:

```text
upload
→ quarantine
→ malware scan
→ file validation
→ process
```

Verification documents receive stricter scanning than ordinary decoded/re-encoded photos.

A malware scanning implementation may use:

- managed cloud scanning capability;
- containerized antivirus engine;
- third-party scanning service.

The provider choice is an implementation decision.

---

## 32. Decompression and Parser Safety

Protect processing workers against hostile files.

Controls should include:

- maximum dimensions;
- maximum decoded pixel count;
- memory limits;
- CPU timeout;
- file-size limits;
- sandbox/container isolation;
- patched image/PDF libraries.

---

## 33. Public Media Moderation

Listing images may require automated or human moderation.

Potential checks:

- prohibited sexual content;
- graphic violence;
- unrelated spam imagery;
- contact-information overlays where prohibited;
- fraudulent screenshots;
- duplicate/stolen imagery signals;
- watermarks where business rules restrict them.

Automated detection must not be treated as infallible.

Flagged content may require human moderation.

---

## 34. Moderation States

Possible media moderation flow:

```text
NOT_REQUIRED
      or
PENDING
   ↓
APPROVED
   │
   └── later report → FLAGGED
                       ↓
                APPROVED / REJECTED
```

A media asset rejected by moderation must not appear on the public listing.

---

## 35. Human Moderation

Moderators should review a controlled derivative where possible rather than unrestricted original files.

Private verification originals should be shown only to staff whose role permits evidence access.

---

## 36. Verification Evidence Processing

Verification uploads may include:

- images;
- PDF documents;
- future supported document formats.

The evidence pipeline should:

1. validate file type;
2. scan for malware;
3. retain the original privately;
4. generate safe viewer derivatives when needed;
5. record checksum and metadata;
6. attach evidence to the verification case;
7. audit access.

Do not publish verification evidence.

---

## 37. PDF Handling

PDF evidence should not be rendered directly from untrusted content in unsafe contexts.

Recommended approach:

- scan;
- validate PDF;
- generate controlled preview images/PDF derivative where necessary;
- disable or avoid active content;
- open only through approved viewer surfaces.

Implementation details belong in the verification engineering design.

---

## 38. S3 Encryption

All media buckets must use encryption at rest.

For public marketplace media:

```text
SSE-S3
or
SSE-KMS
```

may be used according to operational requirements.

For private verification evidence:

```text
SSE-KMS
```

with dedicated environment-specific keys is preferred.

---

## 39. S3 Block Public Access

Enable S3 Block Public Access for all Pachi buckets.

Public listing images are delivered through CloudFront, not through public bucket ACLs.

ACL-based public access should not be used.

---

## 40. CloudFront Delivery

Public marketplace derivatives will be delivered through CloudFront.

Benefits:

- caching;
- lower origin load;
- faster global delivery;
- controlled origin access;
- TLS;
- cache policies.

Use Origin Access Control or current AWS-recommended private-origin access mechanisms.

---

## 41. Public Asset URLs

Application records should store asset identity, not a hard-coded full CDN URL where avoidable.

Example:

```text
media_asset_id
```

or:

```text
storage key + derivative key
```

The API/client layer constructs or returns the current delivery URL.

This allows CDN/domain changes later.

---

## 42. Cache Strategy

Processed public listing media can use long-lived caching when object keys are immutable/versioned.

Preferred approach:

```text
new media version
→ new object key
```

rather than overwriting an existing object and trying to invalidate caches repeatedly.

---

## 43. Private Evidence Access

Verification evidence must use short-lived signed access.

Flow:

```text
authorized user/reviewer
     ↓
Pachi API authorization
     ↓
short-lived signed URL
     ↓
private S3 object
```

Do not issue a permanent public URL.

---

## 44. Signed URL Duration

Recommended starting durations:

### Verification reviewer access

```text
5 minutes
```

### Applicant access to own evidence

```text
5–10 minutes
```

The exact duration should be configurable.

---

## 45. Signed URL Scope

A signed URL must grant access to one specific object or tightly bounded operation.

Do not create broad signed access to an entire bucket or user directory.

---

## 46. Upload URL vs Download URL

Treat upload and download authorization separately.

An upload URL must not automatically imply read access.

A read URL must not imply write access.

---

## 47. Access Auditing

For sensitive evidence, record at minimum:

```text
evidence_id
verification_case_id
actor_id
actor_role
action
timestamp
request_id
```

Actions include:

```text
VIEW_REQUESTED
SIGNED_URL_ISSUED
DOWNLOADED where detectable
REPLACED
DELETED
```

---

## 48. Listing Image Ordering

Listing image order belongs in the database, not S3 object names.

Conceptually:

```text
ListingMedia
- listing_id
- media_asset_id
- sort_order
- is_cover
```

This allows reordering without copying objects.

---

## 49. Image Count Limits

Listing rules should define maximum image counts.

Proposed starting point:

```text
minimum for published listing: 1
recommended: 5+
maximum: 30
```

The exact maximum is a product decision.

The media architecture must support configuration rather than hard-coded assumptions.

---

## 50. Image Ownership

A file must belong to an explicit Pachi entity.

Possible ownership:

```text
property
listing
user
provider
organization
verification_case
moderation_case
```

Orphaned uploads should be cleaned up after a configured period.

---

## 51. Orphan Upload Cleanup

If a pre-signed upload is created but never attached to a valid entity, the object should not remain indefinitely.

Recommended cleanup:

```text
PENDING_UPLOAD / QUARANTINED orphan
older than 24–72 hours
→ delete
```

Exact duration should be configurable.

---

## 52. Replacement Behavior

Replacing a listing image should create a new media asset/version.

Do not overwrite the underlying object silently.

This preserves:

- audit history;
- moderation context;
- CDN correctness.

---

## 53. Deletion Model

Pachi distinguishes between:

```text
logical deletion
physical deletion
```

---

## 54. Logical Deletion

When a user removes media from an active entity:

```text
asset no longer visible
asset no longer linked publicly
deleted_at recorded
```

Physical object deletion may occur later according to retention policy.

---

## 55. Immediate Physical Deletion

Immediate physical deletion is appropriate for:

- failed/quarantined malicious uploads;
- orphan temporary uploads;
- duplicate processing artifacts;
- files uploaded accidentally and never used, when policy permits.

---

## 56. Delayed Physical Deletion

Delayed deletion is appropriate when media may be required for:

- dispute handling;
- moderation;
- fraud investigation;
- audit;
- backup recovery.

---

## 57. Listing Media Retention

Proposed baseline:

### Active listing

Retain all active media.

### Closed/archived listing

Retain linked media while the listing remains within Pachi's operational retention period.

### User deletes listing image

Hide immediately, then retain privately for:

```text
30 days
```

before physical deletion unless:

- a dispute;
- report;
- moderation case;
- legal hold;
- fraud investigation;

requires longer retention.

---

## 58. Verification Evidence Retention

Verification evidence requires a separate retention policy.

The retention period should be based on:

- verification validity;
- fraud prevention;
- disputes;
- legal/privacy obligations;
- data minimization.

Proposed baseline behavior:

```text
verification active
→ retain required evidence

verification closed/expired/revoked
→ retain for defined post-decision period

retention expires
→ securely delete unless hold applies
```

The exact retention duration must be approved before production collection of identity documents.

---

## 59. Moderation Hold

Any media involved in an active:

- dispute;
- moderation case;
- fraud investigation;
- legal hold;

must be exempt from ordinary deletion until the hold is released.

---

## 60. Account Deletion

Deleting a user account must not blindly delete all associated media immediately.

Process each asset according to its role.

Examples:

### Avatar

Can normally be removed from public delivery and deleted according to account-deletion retention.

### Listing images

May remain associated with historical marketplace records for a limited retention period.

### Verification evidence

Must follow verification/legal retention policy.

### Moderation evidence

May require longer retention.

Account deletion must be coordinated with the privacy/data-retention policy.

---

## 61. Backup Deletion

Deleting a live object does not immediately remove every copy from backups.

Pachi should document:

- live deletion date;
- backup retention window;
- eventual backup expiry.

Privacy-facing deletion language must reflect actual backup behavior.

---

## 62. S3 Versioning

Enable versioning for critical buckets.

Advantages:

- accidental overwrite recovery;
- deletion recovery;
- audit support.

Lifecycle rules must prevent unlimited version growth.

---

## 63. S3 Lifecycle Policies

Use lifecycle policies for:

- orphan cleanup;
- old object versions;
- expired processing artifacts;
- temporary files;
- archival classes where appropriate;
- final deletion after approved retention.

Lifecycle policies must not delete objects under legal/moderation hold.

---

## 64. Storage Classes

Initial decision:

Use standard S3 storage for active media.

Transition older eligible private/archive objects to lower-cost storage only when:

- access patterns are understood;
- retrieval delay is acceptable;
- retention rules are stable.

Do not introduce complex storage-tiering prematurely.

---

## 65. Duplicate Media Detection

Pachi may use:

- checksum;
- perceptual hash;
- image similarity;

as trust or cost signals.

Possible uses:

- detect accidental duplicate uploads;
- identify suspicious repeated listing photos;
- reduce redundant processing.

Do not automatically delete assets solely because their hash matches another user's asset.

---

## 66. Perceptual Hashing

A perceptual hash may be created for public listing photos.

Potential uses:

- duplicate-property investigation;
- stolen-listing detection;
- moderation assistance.

Hash-based similarity is evidence, not proof of fraud.

---

## 67. Watermarks

Pachi will not add destructive watermarks to original images.

A future Pachi-branded delivery derivative may be considered if required.

Watermark policy should not:

- hide property details;
- prevent legitimate provider reuse;
- permanently alter stored originals.

---

## 68. Image Authenticity

Pachi should not claim that an image is authentic merely because it passed file validation.

Possible future fraud checks may include:

- duplicate-photo matching;
- reverse-image investigation;
- EXIF review on original uploads;
- AI-generated/manipulated image signals.

These are moderation signals, not deterministic proof.

---

## 69. Content Scanning

Automated media safety checks may be introduced for public media.

The scanning system should output:

```text
allowed
flagged
blocked
```

with confidence/reason metadata.

Borderline results should route to human review.

---

## 70. Verification Evidence Moderation

Verification documents should not be sent indiscriminately to third-party image moderation services.

Before using any external processor for sensitive evidence, verify:

- data-processing terms;
- data location;
- retention;
- model-training policy;
- security controls.

Default preference:

```text
minimum necessary third-party exposure
```

---

## 71. Virus/Malware Scan Failure

If scanning is unavailable:

- do not automatically trust high-risk files;
- retry asynchronously;
- keep object quarantined;
- alert if backlog grows.

Public image processing may continue only if the image was safely decoded/re-encoded according to the approved pipeline and the risk model permits it.

---

## 72. Processing Failure

If processing fails:

```text
PROCESSING
→ REJECTED
```

or:

```text
PROCESSING
→ retry
```

depending on error type.

The user should receive a clear upload failure state.

Do not silently publish the unprocessed original.

---

## 73. Retry Policy

Processing workers should use bounded retries.

Example:

```text
attempt 1
attempt 2
attempt 3
→ dead-letter queue
```

Permanent failures should become operationally visible.

---

## 74. Dead-Letter Queue

Media-processing failures should use an SQS dead-letter queue.

Monitor:

- DLQ depth;
- oldest message age;
- repeated processor errors.

---

## 75. Security Boundaries

### Client

May upload only using server-authorized short-lived credentials.

### API

Controls ownership and upload authorization.

### Processing worker

Has access only to required source/destination prefixes.

### CloudFront

Reads approved public derivatives only.

### Reviewer

Gets short-lived access to explicitly authorized private evidence.

### Moderator

Gets only media access allowed by moderation role.

---

## 76. IAM Principle

IAM roles should be narrow.

Examples:

### API role

May:

- create upload authorizations;
- read media metadata;
- create signed access.

Should not have broad delete access to every bucket.

### Media worker role

May:

- read quarantine objects;
- write processed derivatives;
- update processing metadata.

### Verification reviewer service

May create narrowly scoped access for private evidence.

---

## 77. CloudFront Origin Separation

Public-media CloudFront must not have access to verification buckets.

Do not create one broad distribution/origin policy that accidentally reaches all media.

---

## 78. Domain Names

Possible delivery domain:

```text
media.<pachi-domain>
```

Private verification evidence should not use a publicly browsable CDN hostname.

---

## 79. URL Guessing

Public media object identifiers should be opaque enough to avoid leaking internal sequence IDs.

However, public media security must not depend on URL secrecy.

Private evidence security must depend on authorization, not unguessable names alone.

---

## 80. Mobile Upload Experience

The mobile app should:

- optionally resize very large photos before upload;
- preserve sufficient quality;
- show upload progress;
- retry recoverable failures;
- allow cancellation;
- persist draft attachment state.

Client resizing is an optimization.

Server processing remains authoritative.

---

## 81. Web Upload Experience

The web app should:

- validate obvious size/type errors before upload;
- show progress;
- support retry;
- not assume client validation is sufficient.

---

## 82. Client-Side Compression

Client-side compression may reduce upload time and bandwidth.

It must not be the only processing layer.

Verification evidence should not be aggressively compressed if compression could reduce document legibility.

---

## 83. Accessibility

Images used in public listings should support accessible UI.

Where appropriate, Pachi should allow or derive:

- alt text;
- descriptive labels.

Accessibility metadata belongs in the application database, not EXIF.

---

## 84. Image Moderation Appeals

If public media is rejected:

- provider should receive an understandable status;
- provider may replace the image;
- appeal workflow may be added where moderation policy supports it.

Original rejected content should not remain publicly accessible.

---

## 85. Cost Controls

Media costs should be actively managed.

Track:

```text
S3 storage
CloudFront transfer
CloudFront requests
image processing CPU
SQS usage
malware scanning cost
moderation scanning cost
average media per listing
average bytes per listing
```

---

## 86. Processing Limits

Guardrails should prevent abusive resource consumption.

Examples:

- per-user concurrent upload limit;
- per-listing media count;
- daily upload-volume limits where needed;
- processing queue backpressure;
- max decoded pixels.

---

## 87. CDN Cache Invalidation

Prefer immutable versioned URLs.

Avoid frequent CloudFront invalidations.

Example:

```text
/media/<asset-id>/<version>/medium.webp
```

A replacement creates:

```text
version = 2
```

instead of overwriting version 1.

---

## 88. Original Public-Image Retention

Recommended baseline:

Retain original uploaded public images privately for:

```text
30–90 days
```

after successful processing.

Then delete originals unless:

- moderation;
- dispute;
- reprocessing requirement;
- fraud investigation;

requires longer retention.

Processed derivatives remain the delivery source.

Exact duration should be selected before launch.

---

## 89. Original Verification Evidence

Verification originals should remain available for authorized review for the duration of the approved verification retention policy.

Do not rely only on compressed preview derivatives for verification decisions.

---

## 90. Data Residency

Production media should reside in the AWS region strategy established by ADR 0003.

Primary:

```text
eu-west-1
```

Backup/DR:

```text
eu-west-3
```

Sensitive-evidence replication must follow applicable privacy/legal requirements.

---

## 91. Disaster Recovery

Public listing media should be recoverable through:

- S3 durability;
- versioning;
- backups/replication where required;
- application metadata restoration.

Private verification evidence requires stronger recovery guarantees because lost evidence may invalidate verification/audit workflows.

Critical private evidence should be covered by the backup policy established in ADR 0003.

---

## 92. Observability

Track at minimum:

```text
upload requests
successful uploads
failed uploads
processing latency
processing failures
malware detections
moderation flags
DLQ depth
signed private-access requests
S3 storage growth
CloudFront transfer
media cost per active listing
```

---

## 93. Alerting

Alert on:

- processing queue backlog;
- repeated processor crash;
- malware scanner failure;
- DLQ growth;
- S3 access-policy changes;
- CloudFront origin errors;
- unusual signed-access volume;
- unexpected storage growth.

---

## 94. Audit Requirements

Public media events requiring audit or durable history:

- upload authorized;
- upload completed;
- asset processed;
- asset attached to entity;
- asset reordered;
- asset hidden;
- asset removed;
- moderation action;
- deletion scheduled;
- physical deletion completed where tracked.

Private verification media additionally requires:

- evidence uploaded;
- evidence replaced;
- evidence accessed;
- signed access issued;
- evidence placed on hold;
- hold released;
- evidence deleted.

---

## 95. Alternatives Considered

### 95.1 Store files directly in PostgreSQL

**Advantages**

- one data system;
- transactional association.

**Reasons not selected**

- poor fit for large binary objects;
- database growth;
- backup cost;
- performance impact;
- inefficient CDN integration.

PostgreSQL stores metadata and ownership, not large binary media.

---

### 95.2 Public S3 buckets for listing images

**Advantages**

- simple delivery;
- no CDN origin configuration.

**Reasons not selected**

- weaker control;
- harder future access changes;
- easy misconfiguration;
- no need when CloudFront can serve private origins.

---

### 95.3 One S3 bucket for all Pachi media

**Advantages**

- simpler resource count;
- simpler initial setup.

**Reasons not selected**

Public listing photos and identity documents belong to different security domains.

Separate storage boundaries reduce the risk of policy mistakes.

---

### 95.4 Upload through NestJS API

**Advantages**

- centralized validation;
- simpler mental model.

**Reasons not selected**

- unnecessary API bandwidth;
- larger container memory pressure;
- slower uploads;
- poorer mobile reliability;
- less scalable.

---

### 95.5 Serve original images directly

**Advantages**

- no processing pipeline;
- simplest implementation.

**Reasons not selected**

- large downloads;
- privacy metadata leakage;
- inconsistent orientation;
- high bandwidth cost;
- no standardized image sizes.

---

### 95.6 Client-side-only image processing

**Advantages**

- lower server CPU cost;
- faster pre-upload compression.

**Reasons not selected**

Clients are untrusted and inconsistent.

Server processing remains authoritative.

---

### 95.7 Lambda for all image processing

**Advantages**

- serverless scaling;
- no worker service management.

**Reasons not selected as the architectural requirement**

Large image/PDF processing may need:

- more predictable memory;
- native dependencies;
- longer execution;
- consistent container environment.

A Lambda implementation remains possible for suitable workloads, but the architecture should work with ECS workers.

---

### 95.8 CloudFront signed URLs for verification evidence

**Advantages**

- CDN delivery;
- signed access.

**Reasons not selected initially**

Verification evidence is low-volume and highly sensitive.

Direct short-lived S3 signed access through Pachi authorization is simpler and reduces accidental public-delivery overlap.

---

### 95.9 Keep EXIF on public listing images

**Advantages**

- preserves original metadata.

**Reasons not selected**

GPS/device metadata can create unnecessary privacy exposure.

---

### 95.10 Strip all metadata from verification documents

**Advantages**

- privacy;
- simplified storage.

**Reasons not selected**

Metadata may have evidentiary value in fraud/security review.

Public-media and verification-media policies must differ.

---

### 95.11 Immediate hard-delete on user removal

**Advantages**

- simple privacy semantics;
- lower storage.

**Reasons not selected**

Media may be needed for:

- disputes;
- fraud review;
- moderation;
- audit;
- restore windows.

Use staged deletion with retention and holds.

---

### 95.12 Third-party image CDN/storage platform

Examples:

```text
Cloudinary
Imgix
Uploadcare
```

**Advantages**

- excellent transformations;
- delivery;
- upload tooling;
- automatic optimization.

**Reasons not selected initially**

Pachi already proposes:

- S3;
- CloudFront;
- AWS infrastructure;
- worker processing.

Keeping media storage in Pachi-controlled S3 reduces foundational vendor count and provides clearer security separation for verification evidence.

A specialized image CDN may be reconsidered if transformation complexity or performance requirements justify it.

---

## 96. Consequences

### 96.1 Positive

- strong separation between public and sensitive media;
- direct-to-S3 upload scalability;
- reduced API bandwidth;
- faster public images;
- EXIF privacy protection;
- auditable sensitive evidence;
- controlled moderation pipeline;
- immutable CDN-friendly derivatives;
- predictable deletion behavior;
- future flexibility in image-processing implementation.

### 96.2 Negative

- asynchronous media state is more complex;
- processing workers require monitoring;
- multiple buckets and IAM policies increase infrastructure configuration;
- verification retention requires policy discipline;
- CDN + S3 + processing adds more components than direct file serving;
- moderation and malware scanning add cost.

---

## 97. Risks and Mitigations

### Sensitive evidence accidentally exposed

Mitigation:

- separate bucket;
- Block Public Access;
- no public CloudFront origin;
- short-lived signed access;
- strict IAM;
- access audits.

### Malicious upload

Mitigation:

- quarantine;
- type inspection;
- malware scan;
- decode/re-encode;
- resource limits.

### EXIF location leak

Mitigation:

- strip metadata from all public derivatives.

### Image-processing denial of service

Mitigation:

- file-size limits;
- decoded-pixel limits;
- queue isolation;
- worker memory limits;
- bounded retries.

### Unbounded media cost

Mitigation:

- size/count limits;
- derivative limits;
- lifecycle cleanup;
- CloudFront caching;
- cost metrics.

### Accidental permanent deletion

Mitigation:

- logical deletion;
- versioning;
- retention window;
- backups where appropriate.

### Verification evidence retained too long

Mitigation:

- explicit retention schedule;
- lifecycle policy;
- deletion jobs;
- privacy review.

---

## 98. Open Decisions

### MEDIA-OD-001 — Maximum listing images

What is the final maximum image count per listing?

**Current recommendation:** 30.

---

### MEDIA-OD-002 — Original public-image retention

How long should successfully processed originals remain before deletion?

**Current recommendation:** 60 days unless a hold applies.

---

### MEDIA-OD-003 — Verification evidence retention

What exact post-decision retention period applies to identity, organization, and property-authority evidence?

**Current status:** Must be resolved before production verification collection.

---

### MEDIA-OD-004 — Malware scanning implementation

Should Pachi use:

- managed AWS/security service;
- ClamAV-based worker;
- third-party scanning provider?

**Current status:** Engineering/vendor decision.

---

### MEDIA-OD-005 — Automated image moderation provider

Which service, if any, should perform automated safety/moderation scanning?

**Current status:** Separate evaluation required.

---

### MEDIA-OD-006 — HEIC support

Should HEIC/HEIF uploads be supported at launch?

**Current recommendation:** Yes if the production processing pipeline decodes them reliably; otherwise convert client-side on supported mobile clients and document the limitation.

---

### MEDIA-OD-007 — Private evidence preview

Should verification reviewers view:

- original file directly;
- sanitized preview derivative by default with original available on demand?

**Current recommendation:** Sanitized preview by default, original available only when required.

---

## 99. Decisions Established by This ADR

If accepted:

1. Amazon S3 is Pachi's authoritative media object store.
2. Public marketplace media and private verification evidence use separate storage security domains.
3. No Pachi S3 bucket relies on broad public access.
4. Public marketplace media is delivered through CloudFront.
5. Verification evidence uses short-lived authorized private access.
6. Clients upload using server-authorized short-lived pre-signed uploads.
7. Uploaded files enter quarantine before becoming trusted.
8. File extension and client MIME type are not trusted.
9. Public images are decoded, normalized, re-encoded, resized, and compressed.
10. EXIF/GPS metadata is stripped from public image derivatives.
11. Verification originals are preserved privately according to evidence policy.
12. Malware/file validation occurs before high-risk files are trusted.
13. Media moderation state is separate from processing state.
14. Listing image order is stored in PostgreSQL, not object keys.
15. Public derivatives use versioned/immutable cache-friendly paths.
16. Media deletion is generally logical first and physical after retention.
17. Active moderation, dispute, fraud, or legal holds override ordinary deletion.
18. Sensitive evidence access is auditable.
19. Pachi does not store large binary media directly in PostgreSQL.
20. Production media follows the regional/backup strategy established by ADR 0003.

---

## 100. Acceptance Criteria

This ADR may move from **Proposed** to **Accepted** when:

- public/private bucket separation is approved;
- upload limits are approved;
- listing image count is approved;
- initial derivative sizes are validated against mobile/web UI;
- public-original retention is decided;
- verification evidence retention is decided;
- malware scanning implementation is selected;
- automated moderation requirements are defined;
- CloudFront/S3 IAM design is reviewed;
- private evidence signed-access flow is security-reviewed;
- mobile HEIC behavior is tested;
- no known privacy or verification requirement conflicts with the design.

---

## 101. Follow-Up Work

After acceptance:

1. create environment-specific public and private S3 buckets;
2. enable Block Public Access;
3. configure encryption and KMS where required;
4. create CloudFront distribution for public derivatives;
5. configure Origin Access Control;
6. implement media metadata schema;
7. implement upload authorization endpoint;
8. implement direct-to-S3 upload flow;
9. create SQS media-processing queue and DLQ;
10. implement image worker;
11. implement EXIF stripping and resizing;
12. implement malware/file validation;
13. implement public-media moderation integration;
14. implement signed private-evidence access;
15. implement orphan cleanup;
16. implement lifecycle and deletion jobs;
17. configure backup/replication policies for private evidence;
18. create media cost/health dashboards;
19. document verification-evidence retention before collecting production identity documents.

---

## 102. References

Implementation should be checked against current official documentation for:

- Amazon S3 security and Block Public Access;
- S3 pre-signed URLs;
- S3 versioning;
- S3 lifecycle policies;
- S3 server-side encryption;
- AWS KMS;
- Amazon CloudFront private S3 origins / Origin Access Control;
- Amazon SQS and dead-letter queues;
- AWS Backup;
- AWS malware/security scanning options selected during implementation;
- Sharp/libvips or the selected image-processing library;
- Expo image/file upload behavior;
- browser upload APIs.

AWS services, security guidance, media-format support, and provider capabilities change over time and must be rechecked before production deployment.
